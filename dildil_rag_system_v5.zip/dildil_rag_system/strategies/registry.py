"""
strategies/registry.py — Auto-discovery and registration of RAG strategies.

Scans every sub-folder of strategies/ for a strategy.py file that
contains a class inheriting from BaseStrategy. No manual registration needed.

Usage:
    from strategies.registry import get_strategy, list_strategies

    strategy = get_strategy("naive_rag")
    print(list_strategies())        # [{"name": ..., "description": ...}]
"""
from __future__ import annotations

import importlib
import inspect
import logging
from pathlib import Path
from typing import Dict, List, Optional, Type

from strategies.base import BaseStrategy

logger = logging.getLogger(__name__)

# ─── Discovery ────────────────────────────────────────────────────────────────

def _discover() -> Dict[str, Type[BaseStrategy]]:
    """
    Walk strategies/ sub-folders, import strategy.py from each one,
    find all BaseStrategy subclasses, and return a name → class mapping.
    """
    registry: Dict[str, Type[BaseStrategy]] = {}
    strategies_dir = Path(__file__).parent

    for subfolder in sorted(strategies_dir.iterdir()):
        if not subfolder.is_dir():
            continue
        strategy_file = subfolder / "strategy.py"
        if not strategy_file.exists():
            continue

        module_path = f"strategies.{subfolder.name}.strategy"
        try:
            module = importlib.import_module(module_path)
        except Exception as e:
            logger.warning(f"[Registry] Failed to import '{module_path}': {e}")
            continue

        for _, cls in inspect.getmembers(module, inspect.isclass):
            if (
                issubclass(cls, BaseStrategy)
                and cls is not BaseStrategy
                and cls.NAME != "unnamed"
            ):
                if cls.NAME in registry:
                    logger.warning(
                        f"[Registry] Duplicate strategy name '{cls.NAME}' "
                        f"in {module_path} — skipping"
                    )
                    continue
                registry[cls.NAME] = cls
                logger.debug(f"[Registry] Registered '{cls.NAME}' from {module_path}")

    return registry


# ─── Lazy singleton ───────────────────────────────────────────────────────────

_REGISTRY: Optional[Dict[str, Type[BaseStrategy]]] = None


def _get_registry() -> Dict[str, Type[BaseStrategy]]:
    global _REGISTRY
    if _REGISTRY is None:
        _REGISTRY = _discover()
        logger.info(
            f"[Registry] Loaded {len(_REGISTRY)} strategy(ies): "
            f"{list(_REGISTRY.keys())}"
        )
    return _REGISTRY


# ─── Public API ───────────────────────────────────────────────────────────────

def get_strategy(name: str) -> BaseStrategy:
    """
    Return an instantiated strategy by name.

    Raises:
        ValueError if the strategy is not found.
    """
    registry = _get_registry()
    if name not in registry:
        available = ", ".join(sorted(registry.keys())) or "(none)"
        raise ValueError(
            f"Strategy '{name}' not found. Available: {available}"
        )
    return registry[name]()


def list_strategies() -> List[Dict]:
    """
    Return a list of dicts describing all available strategies.
    [{"name": "naive_rag", "description": "..."}, ...]
    """
    return [
        {"name": name, "description": cls.DESCRIPTION}
        for name, cls in sorted(_get_registry().items())
    ]


def all_strategy_names() -> List[str]:
    return sorted(_get_registry().keys())
