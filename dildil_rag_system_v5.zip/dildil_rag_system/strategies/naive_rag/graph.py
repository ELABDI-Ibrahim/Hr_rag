"""
strategies/naive_rag/graph.py — LangGraph for the naive RAG strategy.

Graph:
    START → similarity_search → verdict → END

State fields:
    Inputs  : exigence, rep_tag, rep_comments, proof_refs
    Outputs : retrieved_pages (node 1), verdict (node 2)

The vectorstore (ChromaDB) is injected at graph-build time via a closure
so it doesn't appear in the serialisable state dict. setup() on the
strategy instance calls build_graph(vectorstore) once before run().
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List

from langgraph.graph import END, StateGraph
from typing_extensions import TypedDict

from config import SEMANTIC_TOP_M
from pipeline.verdict import run_document_verdict, LABEL_NON

logger = logging.getLogger(__name__)


# ─── State ────────────────────────────────────────────────────────────────────

class NaiveRAGState(TypedDict):
    # Inputs (set before invoking)
    exigence:     str
    rep_tag:      str
    rep_comments: str
    proof_refs:   List[str]
    # Node 1 output
    retrieved_pages: List[Dict]
    # Node 2 output
    verdict: Dict


# ─── Graph builder ────────────────────────────────────────────────────────────

def build_graph(vectorstore):
    """
    Build and compile the naive RAG graph.

    The vectorstore is captured by closure in the node functions — it is
    NOT stored in the state (ChromaDB objects are not serialisable).

    Args:
        vectorstore: A ready-to-query langchain_chroma.Chroma instance.

    Returns:
        Compiled LangGraph runnable.
    """

    # ── Node 1: similarity search ────────────────────────────────────────────
    def similarity_search_node(state: NaiveRAGState) -> Dict[str, Any]:
        """Pure cosine similarity search — no pre-filtering."""
        logger.info(f"[NaiveRAG/Node1] Searching: '{state['exigence'][:70]}'")

        docs = vectorstore.similarity_search(state["exigence"], k=SEMANTIC_TOP_M)
        pages = [
            {
                "text":        doc.page_content,
                "source_file": doc.metadata.get("source_file", ""),
                "file_path":   doc.metadata.get("file_path", ""),
                "page_num":    doc.metadata.get("page_num", 0),
                "file_ext":    doc.metadata.get("file_ext", ""),
            }
            for doc in docs
        ]
        logger.info(f"[NaiveRAG/Node1] Retrieved {len(pages)} page(s)")
        return {"retrieved_pages": pages}

    # ── Node 2: LLM verdict ───────────────────────────────────────────────────
    def verdict_node(state: NaiveRAGState) -> Dict[str, Any]:
        """Call the shared document verdict LLM chain."""
        logger.info(
            f"[NaiveRAG/Node2] Verdict for '{state['exigence'][:60]}' "
            f"({len(state['retrieved_pages'])} page(s))"
        )
        try:
            verdict = run_document_verdict(
                exigence        = state["exigence"],
                rep_tag         = state.get("rep_tag", ""),
                rep_comments    = state.get("rep_comments", ""),
                proof_refs      = state.get("proof_refs", []),
                retrieved_pages = state["retrieved_pages"],
                french_keywords = [],
            )
        except Exception as e:
            logger.error(f"[NaiveRAG/Node2] Verdict failed: {e}")
            verdict = {
                "compliance":         LABEL_NON,
                "justification_type": "inferred",
                "evidence":           f"Erreur: {e}",
                "confidence":         0.0,
                "reasoning":          f"Verdict non déterminé: {e}",
                "source_files":       [],
            }
        logger.info(
            f"[NaiveRAG/Node2] → {verdict.get('compliance')} "
            f"[conf={verdict.get('confidence', 0):.2f}]"
        )
        return {"verdict": verdict}

    # ── Wire graph ────────────────────────────────────────────────────────────
    graph = StateGraph(NaiveRAGState)
    graph.add_node("similarity_search", similarity_search_node)
    graph.add_node("verdict",           verdict_node)

    graph.set_entry_point("similarity_search")
    graph.add_edge("similarity_search", "verdict")
    graph.add_edge("verdict", END)

    return graph.compile()
