"""
strategies/bm25_hybrid/strategy.py — BM25 hybrid strategy.

All logic lives in graph.py. This file:
  1. Compiles the LangGraph once (setup)
  2. Invokes it once per exigence row
  3. Wraps results in StrategyResult
"""
from __future__ import annotations

import logging
import time
from typing import Dict, List

import mlflow

from strategies.base import BaseStrategy, StrategyResult
from strategies.bm25_hybrid.graph import build_graph

logger = logging.getLogger(__name__)


class BM25HybridStrategy(BaseStrategy):
    """
    Full hybrid pipeline with LangGraph conditional routing:
      evidence_mining → keyword_suggestion → BM25 → semantic search → verdict
      OR (for oral requirements) → oral verdict (skips retrieval entirely).
    """

    NAME        = "bm25_hybrid"
    DESCRIPTION = (
        "Full pipeline: evidence mining → BM25 triage → semantic search → "
        "conditional verdict (document or oral path)."
    )

    def __init__(self) -> None:
        self._graph = None

    def setup(self, file_corpus: List[Dict]) -> None:
        logger.info("[BM25Hybrid] Compiling LangGraph...")
        self._graph = build_graph()
        logger.info("[BM25Hybrid] Graph compiled — ready")

    def run(self, checklist: List[Dict], file_corpus: List[Dict]) -> List[StrategyResult]:
        if self._graph is None:
            self.setup(file_corpus)

        results = []
        for row in checklist:
            with mlflow.start_run(
                run_name=f"[bm25_hybrid] {row['exigence'][:50]}",
                nested=True,
            ):
                final = self._graph.invoke({
                    "exigence":           row["exigence"],
                    "rep_tag":            row.get("rep_tag", ""),
                    "rep_comments":       row.get("rep_comments", ""),
                    "proof_refs":         row.get("proof_refs", []),
                    "file_corpus":        file_corpus,
                    "evidence_type":      "",
                    "evidence_rationale": "",
                    "french_keywords":    [],
                    "candidate_pages":    [],
                    "retrieved_pages":    [],
                    "verdict":            {},
                })

            results.append(StrategyResult(
                exigence        = row["exigence"],
                row_index       = row["row_index"],
                rep_tag         = row["rep_tag"],
                human_label     = row.get("human_label"),
                human_notes     = row.get("human_notes", ""),
                verdict         = final["verdict"],
                evidence_type   = final.get("evidence_type", "ambiguous"),
                retrieved_pages = final.get("retrieved_pages", []),
            ))
        return results

    def execute(self, checklist: List[Dict], file_corpus: List[Dict]):
        self.setup(file_corpus)
        results = []
        for row in checklist:
            t0 = time.perf_counter()
            r  = self.run([row], file_corpus)[0]
            r.strategy_name = self.NAME
            r.latency_ms    = round((time.perf_counter() - t0) * 1000, 1)
            results.append(r)
        return results
