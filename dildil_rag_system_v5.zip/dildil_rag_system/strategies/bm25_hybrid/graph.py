"""
strategies/bm25_hybrid/graph.py — LangGraph for the BM25 hybrid strategy.

Graph:
    START → evidence_mining → [conditional route]
                ├─ document_required / ambiguous
                │       → keyword_suggestion → bm25_triage → semantic_search → document_verdict
                └─ oral_implicit
                        → oral_verdict
              END

State fields:
    Inputs  : exigence, rep_tag, rep_comments, proof_refs, file_corpus
    Node 1  : evidence_type, evidence_rationale
    Node 2  : french_keywords
    Node 3  : candidate_pages
    Node 4  : retrieved_pages
    Node 5  : verdict
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List

from langgraph.graph import END, StateGraph
from typing_extensions import TypedDict

from config import (
    BM25_TOP_K,
    CHROMA_COLLECTION_NAME,
    EVIDENCE_AMBIGUOUS,
    EVIDENCE_DOCUMENT,
    EVIDENCE_ORAL,
    SEMANTIC_TOP_M,
)
from pipeline.retrieval import bm25_page_triage, index_pages, semantic_search
from pipeline.verdict import (
    classify_evidence_requirement,
    generate_french_keywords,
    run_document_verdict,
    run_oral_verdict,
    LABEL_NON,
)

logger = logging.getLogger(__name__)

COLLECTION = CHROMA_COLLECTION_NAME   # "dildil_pages" from config


# ─── State ────────────────────────────────────────────────────────────────────

class BM25HybridState(TypedDict):
    # Inputs
    exigence:     str
    rep_tag:      str
    rep_comments: str
    proof_refs:   List[str]
    file_corpus:  List[Dict]
    # Node 1
    evidence_type:      str
    evidence_rationale: str
    # Node 2
    french_keywords: List[str]
    # Node 3
    candidate_pages: List[Dict]
    # Node 4
    retrieved_pages: List[Dict]
    # Node 5
    verdict: Dict


# ─── Nodes ────────────────────────────────────────────────────────────────────

def evidence_mining_node(state: BM25HybridState) -> Dict[str, Any]:
    """Node 1 — classify whether this exigence requires a document or is declarative."""
    logger.info(f"[BM25H/Node1] Evidence mining: '{state['exigence'][:70]}'")
    result = classify_evidence_requirement(state["exigence"])
    logger.info(f"[BM25H/Node1] → {result['evidence_type']} | {result['rationale']}")
    return {
        "evidence_type":      result["evidence_type"],
        "evidence_rationale": result["rationale"],
    }


def keyword_suggestion_node(state: BM25HybridState) -> Dict[str, Any]:
    """Node 2 — LLM generates French BM25 keywords for this exigence."""
    logger.info(f"[BM25H/Node2] Expanding keywords for: '{state['exigence'][:60]}'")
    keywords = generate_french_keywords(state["exigence"])
    logger.info(f"[BM25H/Node2] {len(keywords)} keywords generated")
    return {"french_keywords": keywords}


def bm25_triage_node(state: BM25HybridState) -> Dict[str, Any]:
    """Node 3 — BM25 page triage across the full proof corpus."""
    keywords   = state.get("french_keywords", [])
    proof_hint = state.get("proof_refs", [])   # file name hints boost recall
    extra      = keywords + proof_hint

    logger.info(
        f"[BM25H/Node3] BM25 triage — "
        f"{len(keywords)} keywords + {len(proof_hint)} proof hints"
    )
    candidates = bm25_page_triage(
        query       = state["exigence"],
        file_corpus = state["file_corpus"],
        extra_terms = extra if extra else None,
        top_k       = BM25_TOP_K,
    )
    if not candidates:
        logger.warning("[BM25H/Node3] BM25 returned no candidates")
    return {"candidate_pages": candidates}


def semantic_search_node(state: BM25HybridState) -> Dict[str, Any]:
    """Node 4 — embed BM25 candidates, restricted similarity search."""
    candidates = state.get("candidate_pages", [])
    logger.info(f"[BM25H/Node4] Semantic search over {len(candidates)} BM25 candidates")

    if not candidates:
        return {"retrieved_pages": []}

    # Index only the BM25-shortlisted pages (dedup applies)
    candidate_ids = index_pages(candidates, COLLECTION)

    pages = semantic_search(
        query           = state["exigence"],
        collection_name = COLLECTION,
        top_k           = SEMANTIC_TOP_M,
        restrict_to_ids = candidate_ids,
    )
    return {"retrieved_pages": pages}


def document_verdict_node(state: BM25HybridState) -> Dict[str, Any]:
    """Node 5a — LLM verdict using retrieved document context."""
    n = len(state.get("retrieved_pages", []))
    logger.info(f"[BM25H/Node5a] Document verdict — {n} page(s) retrieved")
    try:
        verdict = run_document_verdict(
            exigence        = state["exigence"],
            rep_tag         = state.get("rep_tag", ""),
            rep_comments    = state.get("rep_comments", ""),
            proof_refs      = state.get("proof_refs", []),
            retrieved_pages = state.get("retrieved_pages", []),
            french_keywords = state.get("french_keywords", []),
        )
    except Exception as e:
        logger.error(f"[BM25H/Node5a] Verdict failed: {e}")
        verdict = _error_verdict(e)
    _log_verdict(verdict)
    return {"verdict": verdict}


def oral_verdict_node(state: BM25HybridState) -> Dict[str, Any]:
    """Node 5b — LLM verdict based on rep's declaration only (no retrieval)."""
    logger.info(f"[BM25H/Node5b] Oral verdict — declarative path, no retrieval")
    try:
        verdict = run_oral_verdict(
            exigence     = state["exigence"],
            rep_tag      = state.get("rep_tag", ""),
            rep_comments = state.get("rep_comments", ""),
            proof_refs   = state.get("proof_refs", []),
        )
    except Exception as e:
        logger.error(f"[BM25H/Node5b] Verdict failed: {e}")
        verdict = _error_verdict(e)
    _log_verdict(verdict)
    return {"verdict": verdict}


# ─── Routing ──────────────────────────────────────────────────────────────────

def route_after_evidence_mining(state: BM25HybridState) -> str:
    ev = state.get("evidence_type", EVIDENCE_AMBIGUOUS)
    if ev == EVIDENCE_ORAL:
        logger.info("[BM25H/Router] oral_implicit → oral_verdict (skip retrieval)")
        return "oral_verdict"
    logger.info(f"[BM25H/Router] {ev} → keyword_suggestion → BM25 → semantic → verdict")
    return "keyword_suggestion"


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _log_verdict(v: Dict) -> None:
    icons = {"compliant": "✅", "partially_compliant": "⚠️", "non_compliant": "❌"}
    icon  = icons.get(v.get("compliance", ""), "?")
    logger.info(
        f"  {icon} {v.get('compliance','').upper()} "
        f"[conf={v.get('confidence',0):.2f}] [{v.get('justification_type','')}]"
    )


def _error_verdict(e: Exception) -> Dict:
    return {
        "compliance":         LABEL_NON,
        "justification_type": "inferred",
        "evidence":           f"Erreur: {e}",
        "confidence":         0.0,
        "reasoning":          f"Verdict non déterminé: {e}",
        "source_files":       [],
    }


# ─── Graph builder ────────────────────────────────────────────────────────────

def build_graph():
    """Build and compile the BM25 hybrid LangGraph."""
    graph = StateGraph(BM25HybridState)

    graph.add_node("evidence_mining",    evidence_mining_node)
    graph.add_node("keyword_suggestion", keyword_suggestion_node)
    graph.add_node("bm25_triage",        bm25_triage_node)
    graph.add_node("semantic_search",    semantic_search_node)
    graph.add_node("document_verdict",   document_verdict_node)
    graph.add_node("oral_verdict",       oral_verdict_node)

    graph.set_entry_point("evidence_mining")
    graph.add_conditional_edges(
        "evidence_mining",
        route_after_evidence_mining,
        {
            "keyword_suggestion": "keyword_suggestion",
            "oral_verdict":       "oral_verdict",
        },
    )
    graph.add_edge("keyword_suggestion", "bm25_triage")
    graph.add_edge("bm25_triage",        "semantic_search")
    graph.add_edge("semantic_search",    "document_verdict")
    graph.add_edge("document_verdict",   END)
    graph.add_edge("oral_verdict",       END)

    return graph.compile()
