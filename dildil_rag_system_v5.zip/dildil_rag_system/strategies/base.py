"""
strategies/base.py — The shared contract for all RAG strategies.

Every strategy in the strategies/ folder must:
  1. Be a class that inherits from BaseStrategy
  2. Implement run(checklist, file_corpus) → List[StrategyResult]
  3. Set a unique NAME class attribute

StrategyResult is the fixed output schema. The evaluation layer,
the runner, and the comparison report only ever touch StrategyResult —
they are completely strategy-agnostic.

Adding a new strategy:
  1. Create strategies/my_strategy/strategy.py
  2. Define class MyStrategy(BaseStrategy)
  3. Set NAME = "my_strategy"
  4. Implement run()
  → The registry auto-discovers it. No other file needs editing.
"""
from __future__ import annotations

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, List, Optional


# ─── Output Schema ────────────────────────────────────────────────────────────

@dataclass
class StrategyResult:
    """
    Fixed output schema for every RAG strategy.

    The evaluation layer, runner, and comparison report
    consume ONLY this dataclass — they never import strategy internals.

    Fields populated by the strategy:
        exigence        — original requirement text (from checklist)
        row_index       — Excel row number for write-back
        rep_tag         — representative's normalised tag (compliant/partial/non)
        human_label     — expert ground-truth label (optional, for eval)
        human_notes     — expert notes (used for soft-match metrics)
        verdict         — LLM output dict (see below)
        evidence_type   — document_required | oral_implicit | ambiguous
                          (strategies that don't do evidence mining can default to "ambiguous")
        retrieved_pages — list of {text, source_file, page_num} dicts retrieved
                          (empty list for oral/no-retrieval paths)
        strategy_name   — populated automatically from BaseStrategy.NAME
        latency_ms      — wall-clock time for this single row (ms)

    verdict dict keys (all required):
        compliance        : "compliant" | "partially_compliant" | "non_compliant"
        justification_type: "document" | "oral" | "inferred"
        evidence          : str   what was found / what supports the verdict
        confidence        : float 0.0–1.0
        reasoning         : str   2-4 sentence explanation (French)
        source_files      : List[str]  file names cited
    """
    exigence:        str
    row_index:       int
    rep_tag:         str
    human_label:     Optional[str]
    human_notes:     str
    verdict:         Dict
    evidence_type:   str               = "ambiguous"
    retrieved_pages: List[Dict]        = field(default_factory=list)
    strategy_name:   str               = ""
    latency_ms:      float             = 0.0

    # ── Convenience accessors ─────────────────────────────────────────────────
    @property
    def compliance(self) -> str:
        return self.verdict.get("compliance", "non_compliant")

    @property
    def confidence(self) -> float:
        return self.verdict.get("confidence", 0.0)

    def to_dict(self) -> Dict:
        """Serialise to a plain dict (for the runner results list)."""
        return {
            "exigence":        self.exigence,
            "row_index":       self.row_index,
            "rep_tag":         self.rep_tag,
            "human_label":     self.human_label,
            "human_notes":     self.human_notes,
            "verdict":         self.verdict,
            "evidence_type":   self.evidence_type,
            "retrieved_pages": self.retrieved_pages,
            "strategy_name":   self.strategy_name,
            "latency_ms":      self.latency_ms,
        }


# ─── Abstract Base ────────────────────────────────────────────────────────────

class BaseStrategy(ABC):
    """
    Abstract base class for all AI4DueDil RAG strategies.

    Class attributes:
        NAME        — unique slug (used as CLI arg and output file prefix)
        DESCRIPTION — one-line description shown in --list and comparison reports

    Subclasses only need to implement run().
    The runner wraps it in timing and injects strategy_name automatically.
    """

    NAME:        str = "unnamed"
    DESCRIPTION: str = "No description provided."

    # ── Public entry point (called by runner) ─────────────────────────────────

    def execute(
        self,
        checklist:   List[Dict],
        file_corpus: List[Dict],
    ) -> List[StrategyResult]:
        """
        Called by the runner. Wraps run() with timing and strategy_name injection.
        Do not override this method — override run() instead.
        """
        results = []
        for row in checklist:
            t0 = time.perf_counter()
            result = self._run_single(row, file_corpus)
            latency = (time.perf_counter() - t0) * 1000

            result.strategy_name = self.NAME
            result.latency_ms    = round(latency, 1)
            results.append(result)
        return results

    def _run_single(self, row: Dict, file_corpus: List[Dict]) -> StrategyResult:
        """
        Default per-row dispatch. Strategies that want to process rows differently
        (e.g. batch embedding upfront) should override execute() instead and call
        run() once for all rows — see the naive_rag strategy for the pattern.
        """
        return self.run([row], file_corpus)[0]

    # ── Abstract method (implement this) ──────────────────────────────────────

    @abstractmethod
    def run(
        self,
        checklist:   List[Dict],
        file_corpus: List[Dict],
    ) -> List[StrategyResult]:
        """
        Process all checklist rows and return one StrategyResult per row.

        Args:
            checklist   : Output of utils.excel_handler.read_compliance_checklist()
                          Each dict has: exigence, rep_tag, rep_comments,
                          proof_refs, human_label, human_notes, row_index
            file_corpus : Output of pipeline.ingestion.load_proof_folder()
                          Each dict has: file_path, file_name, pages, full_text

        Returns:
            List[StrategyResult], one per checklist row, in the same order.
        """
        ...

    # ── Optional lifecycle hooks ───────────────────────────────────────────────

    def setup(self, file_corpus: List[Dict]) -> None:
        """
        Optional hook called once before execute() — use for expensive
        one-time setup like bulk embedding of all documents.
        Override in strategies that need it (e.g. naive_rag).
        """
        pass

    def teardown(self) -> None:
        """Optional hook called after execute() — for cleanup."""
        pass
