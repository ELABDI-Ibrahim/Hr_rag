"""
strategies/hyde/graph.py — LangGraph for the HyDE strategy.

Hypothetical Document Embeddings (Gao et al., 2022):
Instead of embedding the question, generate a hypothetical answer/proof
document and embed that. The hypothesis lives in the same embedding region
as real documents, so similarity search is more precise.

Graph:
    START → generate_hypothesis → hyde_search → verdict → END

State fields:
    Inputs      : exigence, rep_tag, rep_comments, proof_refs
    Node 1 out  : hypothesis (the generated fake proof document)
    Node 2 out  : retrieved_pages
    Node 3 out  : verdict

The vectorstore is injected at build time via a closure.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List

from langchain_core.prompts import ChatPromptTemplate
from langchain_groq import ChatGroq
from langgraph.graph import END, StateGraph
from typing_extensions import TypedDict

from config import GROQ_API_KEY, GROQ_MODEL, SEMANTIC_TOP_M
from pipeline.verdict import run_document_verdict, LABEL_NON

logger = logging.getLogger(__name__)

# ── Hypothesis generation prompt ──────────────────────────────────────────────
_HYPOTHESIS_PROMPT = ChatPromptTemplate.from_messages([
    (
        "system",
        "Tu es un expert en conformité et due diligence prestataires. "
        "Génère un extrait de document de preuve réaliste qui satisferait "
        "pleinement l'exigence donnée. "
        "Le document doit ressembler à un vrai document officiel : "
        "certificat, attestation, rapport d'audit, politique interne, etc. "
        "Inclure : dates plausibles, noms d'organismes, numéros de référence "
        "fictifs, formulations typiques du type de document. "
        "IMPORTANT : génère UNIQUEMENT le texte du document — pas d'explication, "
        "pas de préambule, pas de titres de section. 150-250 mots maximum.",
    ),
    (
        "human",
        "Exigence de conformité : {exigence}\n\n"
        "Commentaire du prestataire : {rep_comments}\n\n"
        "Génère un extrait de document qui prouverait que cette exigence est satisfaite.",
    ),
])


# ─── State ────────────────────────────────────────────────────────────────────

class HyDEState(TypedDict):
    # Inputs
    exigence:     str
    rep_tag:      str
    rep_comments: str
    proof_refs:   List[str]
    # Node 1
    hypothesis: str
    # Node 2
    retrieved_pages: List[Dict]
    # Node 3
    verdict: Dict


# ─── Graph builder ────────────────────────────────────────────────────────────

def build_graph(vectorstore):
    """
    Build and compile the HyDE LangGraph.

    Args:
        vectorstore: A ready-to-query langchain_chroma.Chroma instance.

    Note: The LLM chain is instantiated lazily inside the node function
    (not at build_graph() call time) so the graph compiles even when
    GROQ_API_KEY is not set — the key is only needed when the graph runs.
    """

    # ── Node 1: Generate hypothetical proof document ──────────────────────────
    def generate_hypothesis_node(state: HyDEState) -> Dict[str, Any]:
        """
        Ask the LLM to hallucinate a plausible proof document for this exigence.
        If generation fails, fall back to the raw exigence text — this degrades
        to naive_rag behaviour rather than crashing.
        """
        logger.info(f"[HyDE/Node1] Generating hypothesis for: '{state['exigence'][:70]}'")
        try:
            llm   = ChatGroq(api_key=GROQ_API_KEY, model=GROQ_MODEL, temperature=0.3)
            chain = _HYPOTHESIS_PROMPT | llm
            response   = chain.invoke({
                "exigence":     state["exigence"],
                "rep_comments": state.get("rep_comments") or "(aucun commentaire)",
            })
            hypothesis = response.content.strip()
            if len(hypothesis) < 30:
                raise ValueError(f"Hypothesis too short ({len(hypothesis)} chars)")
            logger.info(f"[HyDE/Node1] Generated ({len(hypothesis)} chars): '{hypothesis[:80]}…'")
        except Exception as e:
            logger.warning(
                f"[HyDE/Node1] Hypothesis generation failed: {e} "
                f"— falling back to raw exigence"
            )
            hypothesis = state["exigence"]   # graceful degradation
        return {"hypothesis": hypothesis}

    # ── Node 2: Embed hypothesis and search ───────────────────────────────────
    def hyde_search_node(state: HyDEState) -> Dict[str, Any]:
        """
        Embed the HYPOTHESIS (not the exigence) and run similarity search.
        The hypothesis is never stored in ChromaDB — it's only the query vector.
        """
        hypothesis = state.get("hypothesis", state["exigence"])
        logger.info(f"[HyDE/Node2] Searching with hypothesis embedding ({len(hypothesis)} chars)")

        docs = vectorstore.similarity_search(hypothesis, k=SEMANTIC_TOP_M)
        pages = [
            {
                "text":        doc.page_content,
                "source_file": doc.metadata.get("source_file", ""),
                "file_path":   doc.metadata.get("file_path", ""),
                "page_num":    doc.metadata.get("page_num", 0),
                "file_ext":    doc.metadata.get("file_ext", ""),
            }
            for doc in docs
        ]
        logger.info(f"[HyDE/Node2] Retrieved {len(pages)} page(s)")
        return {"retrieved_pages": pages}

    # ── Node 3: LLM verdict on REAL retrieved pages ───────────────────────────
    def verdict_node(state: HyDEState) -> Dict[str, Any]:
        """
        Verdict uses the REAL retrieved pages — the hypothesis was only used
        as a query vector. The LLM never sees the hypothetical document.
        """
        n = len(state.get("retrieved_pages", []))
        logger.info(f"[HyDE/Node3] Verdict — {n} real page(s) retrieved")
        try:
            verdict = run_document_verdict(
                exigence        = state["exigence"],
                rep_tag         = state.get("rep_tag", ""),
                rep_comments    = state.get("rep_comments", ""),
                proof_refs      = state.get("proof_refs", []),
                retrieved_pages = state.get("retrieved_pages", []),
                french_keywords = [],
            )
        except Exception as e:
            logger.error(f"[HyDE/Node3] Verdict failed: {e}")
            verdict = {
                "compliance":         LABEL_NON,
                "justification_type": "inferred",
                "evidence":           f"Erreur: {e}",
                "confidence":         0.0,
                "reasoning":          f"Verdict non déterminé: {e}",
                "source_files":       [],
            }
        logger.info(
            f"[HyDE/Node3] → {verdict.get('compliance')} "
            f"[conf={verdict.get('confidence', 0):.2f}]"
        )
        return {"verdict": verdict}

    # ── Wire graph ────────────────────────────────────────────────────────────
    graph = StateGraph(HyDEState)
    graph.add_node("generate_hypothesis", generate_hypothesis_node)
    graph.add_node("hyde_search",         hyde_search_node)
    graph.add_node("verdict",             verdict_node)

    graph.set_entry_point("generate_hypothesis")
    graph.add_edge("generate_hypothesis", "hyde_search")
    graph.add_edge("hyde_search",         "verdict")
    graph.add_edge("verdict",             END)

    return graph.compile()
