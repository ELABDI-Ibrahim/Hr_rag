"""
strategies/hyde/strategy.py — HyDE strategy.

All logic lives in graph.py. This file:
  1. Embeds proof corpus into its own ChromaDB collection (setup)
  2. Builds the LangGraph via graph.build_graph(vectorstore)
  3. Invokes it once per exigence row
  4. Wraps results in StrategyResult
"""
from __future__ import annotations

import logging
import time
from typing import Dict, List

from langchain_chroma import Chroma

from pipeline.retrieval import get_chroma_client, get_embeddings, index_pages
from strategies.base import BaseStrategy, StrategyResult
from strategies.hyde.graph import build_graph

logger = logging.getLogger(__name__)

COLLECTION = "hyde_pages"


class HyDEStrategy(BaseStrategy):
    """
    Hypothetical Document Embeddings (Gao et al., 2022).

    Instead of embedding the exigence text directly, the LLM first generates
    a plausible hypothetical proof document, then that document is embedded
    as the query vector. Real proof pages are retrieved using this vector,
    and the LLM verdict is run on the real pages (not the hypothesis).
    """

    NAME        = "hyde"
    DESCRIPTION = (
        "HyDE: LLM generates a hypothetical proof document, embeds it as the "
        "query vector → similarity search → LLM verdict on real pages."
    )

    def __init__(self) -> None:
        self._graph = None

    def setup(self, file_corpus: List[Dict]) -> None:
        logger.info(f"[HyDE] Indexing corpus into '{COLLECTION}'")
        all_pages = [
            {"text": p["text"].strip(), "source_file": d["file_name"],
             "file_path": d["file_path"], "page_num": p["page_num"]}
            for d in file_corpus for p in d["pages"] if p["text"].strip()
        ]
        index_pages(all_pages, COLLECTION)
        vectorstore = Chroma(
            collection_name=COLLECTION,
            embedding_function=get_embeddings(),
            client=get_chroma_client(),
        )
        self._graph = build_graph(vectorstore)
        logger.info("[HyDE] Graph compiled — ready")

    def run(self, checklist: List[Dict], file_corpus: List[Dict]) -> List[StrategyResult]:
        if self._graph is None:
            self.setup(file_corpus)

        results = []
        for row in checklist:
            final = self._graph.invoke({
                "exigence":        row["exigence"],
                "rep_tag":         row.get("rep_tag", ""),
                "rep_comments":    row.get("rep_comments", ""),
                "proof_refs":      row.get("proof_refs", []),
                "hypothesis":      "",
                "retrieved_pages": [],
                "verdict":         {},
            })
            results.append(StrategyResult(
                exigence        = row["exigence"],
                row_index       = row["row_index"],
                rep_tag         = row["rep_tag"],
                human_label     = row.get("human_label"),
                human_notes     = row.get("human_notes", ""),
                verdict         = final["verdict"],
                evidence_type   = "ambiguous",
                retrieved_pages = final["retrieved_pages"],
            ))
        return results

    def execute(self, checklist: List[Dict], file_corpus: List[Dict]):
        self.setup(file_corpus)
        results = []
        for row in checklist:
            t0 = time.perf_counter()
            r  = self.run([row], file_corpus)[0]
            r.strategy_name = self.NAME
            r.latency_ms    = round((time.perf_counter() - t0) * 1000, 1)
            results.append(r)
        return results
