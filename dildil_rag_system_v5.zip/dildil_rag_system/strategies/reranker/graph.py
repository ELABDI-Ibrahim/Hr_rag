"""
strategies/reranker/graph.py — LangGraph for the cross-encoder reranker strategy.

Graph:
    START → bm25_recall → cross_encode → verdict → END

State fields:
    Inputs      : exigence, rep_tag, rep_comments, proof_refs, file_corpus
    Node 1 out  : bm25_candidates
    Node 2 out  : retrieved_pages (reranked top-k)
    Node 3 out  : verdict

The cross-encoder model is injected at graph-build time via a closure
so it doesn't appear in the serialisable state dict.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List

from langgraph.graph import END, StateGraph
from typing_extensions import TypedDict

from config import BM25_TOP_K
from pipeline.retrieval import bm25_page_triage
from pipeline.verdict import run_document_verdict, LABEL_NON

logger = logging.getLogger(__name__)

BM25_RECALL_K = 20   # broad first pass
RERANK_KEEP   = 4    # final top-k after cross-encoder


# ─── State ────────────────────────────────────────────────────────────────────

class RerankerState(TypedDict):
    # Inputs
    exigence:     str
    rep_tag:      str
    rep_comments: str
    proof_refs:   List[str]
    file_corpus:  List[Dict]
    # Node 1
    bm25_candidates: List[Dict]
    # Node 2
    retrieved_pages: List[Dict]
    # Node 3
    verdict: Dict


# ─── Graph builder ────────────────────────────────────────────────────────────

def build_graph(cross_encoder, corpus_pages: List[Dict]):
    """
    Build and compile the reranker LangGraph.

    Both the cross-encoder model and the flattened corpus pages are injected
    at build time via closures — neither appears in the serialisable state.

    Args:
        cross_encoder: A ready sentence_transformers.CrossEncoder instance.
        corpus_pages:  Flattened list of {text, source_file, file_path, page_num}
                       dicts from the full proof corpus.
    """

    # ── Node 1: BM25 broad recall ─────────────────────────────────────────────
    def bm25_recall_node(state: RerankerState) -> Dict[str, Any]:
        """
        BM25 first pass: enrich query with rep comments + proof refs for
        better recall, then return top-BM25_RECALL_K pages.
        """
        extra = []
        if state.get("rep_comments"):
            extra.append(state["rep_comments"])
        extra.extend(state.get("proof_refs", []))

        logger.info(
            f"[Reranker/Node1] BM25 recall — "
            f"query: '{state['exigence'][:60]}' + {len(extra)} extra terms"
        )
        candidates = bm25_page_triage(
            query       = state["exigence"],
            file_corpus = state["file_corpus"],
            extra_terms = extra if extra else None,
            top_k       = BM25_RECALL_K,
        )
        logger.info(f"[Reranker/Node1] {len(candidates)} BM25 candidates")
        return {"bm25_candidates": candidates}

    # ── Node 2: Cross-encoder reranking ───────────────────────────────────────
    def cross_encode_node(state: RerankerState) -> Dict[str, Any]:
        """
        Score every (exigence, page) pair with the cross-encoder.
        Cross-encoders read both texts jointly — they catch paraphrase and
        semantic nuance that cosine similarity misses.
        Keep top-RERANK_KEEP pages.
        """
        candidates = state.get("bm25_candidates", [])
        if not candidates:
            logger.warning("[Reranker/Node2] No BM25 candidates to rerank")
            return {"retrieved_pages": []}

        pairs = [[state["exigence"], p["text"]] for p in candidates]
        logger.info(f"[Reranker/Node2] Scoring {len(pairs)} pairs with cross-encoder")

        try:
            scores = cross_encoder.predict(pairs)
            scored = sorted(zip(scores, candidates), key=lambda x: x[0], reverse=True)
            top    = [page for _, page in scored[:RERANK_KEEP]]
            logger.info(
                f"[Reranker/Node2] Top-{RERANK_KEEP} scores: "
                f"{[round(float(s), 3) for s, _ in scored[:RERANK_KEEP]]}"
            )
        except Exception as e:
            logger.warning(f"[Reranker/Node2] Cross-encoder failed: {e} — using BM25 order")
            top = candidates[:RERANK_KEEP]

        return {"retrieved_pages": top}

    # ── Node 3: LLM verdict ───────────────────────────────────────────────────
    def verdict_node(state: RerankerState) -> Dict[str, Any]:
        n = len(state.get("retrieved_pages", []))
        logger.info(f"[Reranker/Node3] Verdict — {n} reranked page(s)")
        try:
            verdict = run_document_verdict(
                exigence        = state["exigence"],
                rep_tag         = state.get("rep_tag", ""),
                rep_comments    = state.get("rep_comments", ""),
                proof_refs      = state.get("proof_refs", []),
                retrieved_pages = state.get("retrieved_pages", []),
                french_keywords = [],
            )
        except Exception as e:
            logger.error(f"[Reranker/Node3] Verdict failed: {e}")
            verdict = {
                "compliance":         LABEL_NON,
                "justification_type": "inferred",
                "evidence":           f"Erreur: {e}",
                "confidence":         0.0,
                "reasoning":          f"Verdict non déterminé: {e}",
                "source_files":       [],
            }
        logger.info(
            f"[Reranker/Node3] → {verdict.get('compliance')} "
            f"[conf={verdict.get('confidence', 0):.2f}]"
        )
        return {"verdict": verdict}

    # ── Wire graph ────────────────────────────────────────────────────────────
    graph = StateGraph(RerankerState)
    graph.add_node("bm25_recall",   bm25_recall_node)
    graph.add_node("cross_encode",  cross_encode_node)
    graph.add_node("verdict",       verdict_node)

    graph.set_entry_point("bm25_recall")
    graph.add_edge("bm25_recall",  "cross_encode")
    graph.add_edge("cross_encode", "verdict")
    graph.add_edge("verdict",      END)

    return graph.compile()
