"""
strategies/reranker/strategy.py — Cross-encoder reranker strategy.

All logic lives in graph.py. This file:
  1. Loads the cross-encoder model and flattens the corpus (setup)
  2. Builds the LangGraph via graph.build_graph(cross_encoder, corpus_pages)
  3. Invokes it once per exigence row
  4. Wraps results in StrategyResult
"""
from __future__ import annotations

import logging
import time
from typing import Dict, List, Optional

from strategies.base import BaseStrategy, StrategyResult
from strategies.reranker.graph import build_graph

logger = logging.getLogger(__name__)

CROSS_ENC_MODEL = "cross-encoder/ms-marco-MiniLM-L-6-v2"


class RerankerStrategy(BaseStrategy):
    """
    Two-stage retrieval: BM25 broad recall (top-20) → cross-encoder reranking (top-4).

    Cross-encoders read query and document jointly — they catch semantic nuance
    that cosine similarity misses because bi-encoders encode each side separately.
    No vector DB needed: cross-encoder scores pairs directly in memory.
    """

    NAME        = "reranker"
    DESCRIPTION = (
        "BM25 broad recall (top-20) → cross-encoder reranking → top-4 to LLM. "
        "No vector DB — cross-encoder scores (query, passage) pairs directly."
    )

    def __init__(self) -> None:
        self._graph = None

    def setup(self, file_corpus: List[Dict]) -> None:
        logger.info(f"[Reranker] Loading cross-encoder: {CROSS_ENC_MODEL}")
        try:
            from sentence_transformers import CrossEncoder
            cross_encoder = CrossEncoder(CROSS_ENC_MODEL)
        except ImportError:
            raise ImportError(
                "sentence-transformers is required for the reranker strategy. "
                "Install with: pip install sentence-transformers"
            )

        # Flatten corpus into a page list — passed to the graph via closure
        # so BM25 can score all pages without it being part of the state
        corpus_pages = [
            {"text": p["text"].strip(), "source_file": d["file_name"],
             "file_path": d["file_path"], "page_num": p["page_num"]}
            for d in file_corpus for p in d["pages"] if p["text"].strip()
        ]
        logger.info(
            f"[Reranker] {len(corpus_pages)} pages, "
            f"cross-encoder loaded — compiling graph"
        )
        self._graph = build_graph(cross_encoder, corpus_pages)
        logger.info("[Reranker] Graph compiled — ready")

    def run(self, checklist: List[Dict], file_corpus: List[Dict]) -> List[StrategyResult]:
        if self._graph is None:
            self.setup(file_corpus)

        results = []
        for row in checklist:
            final = self._graph.invoke({
                "exigence":        row["exigence"],
                "rep_tag":         row.get("rep_tag", ""),
                "rep_comments":    row.get("rep_comments", ""),
                "proof_refs":      row.get("proof_refs", []),
                "file_corpus":     file_corpus,
                "bm25_candidates": [],
                "retrieved_pages": [],
                "verdict":         {},
            })
            results.append(StrategyResult(
                exigence        = row["exigence"],
                row_index       = row["row_index"],
                rep_tag         = row["rep_tag"],
                human_label     = row.get("human_label"),
                human_notes     = row.get("human_notes", ""),
                verdict         = final["verdict"],
                evidence_type   = "ambiguous",
                retrieved_pages = final["retrieved_pages"],
            ))
        return results

    def execute(self, checklist: List[Dict], file_corpus: List[Dict]):
        self.setup(file_corpus)
        results = []
        for row in checklist:
            t0 = time.perf_counter()
            r  = self.run([row], file_corpus)[0]
            r.strategy_name = self.NAME
            r.latency_ms    = round((time.perf_counter() - t0) * 1000, 1)
            results.append(r)
        return results
