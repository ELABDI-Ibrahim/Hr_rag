"""
strategies/TEMPLATE/strategy.py — Strategy wrapper for YOUR_STRATEGY_NAME.

This file is intentionally short. All the interesting logic lives in graph.py.

Steps to create a new strategy:
  1.  cp -r strategies/TEMPLATE strategies/my_strategy
  2.  In graph.py:
        - Rename MyStrategyState  →  MyStrategyState
        - Edit build_graph() arguments and node logic
        - Wire nodes in the correct order
  3.  In strategy.py (this file):
        - Set NAME = "my_strategy"
        - Set DESCRIPTION = "..."
        - In setup(): load models/indexes, call build_graph(...)
        - In run(): build initial state, invoke graph, wrap in StrategyResult
  4.  python runner.py --strategy my_strategy

The runner, evaluator, and comparison report all work automatically.
No other file needs editing.
"""
from __future__ import annotations

import logging
import time
from typing import Dict, List

from strategies.base import BaseStrategy, StrategyResult
from strategies.TEMPLATE.graph import build_graph   # ← update module path

logger = logging.getLogger(__name__)

COLLECTION = "template_pages"   # ← rename to "my_strategy_pages"


class TemplateStrategy(BaseStrategy):   # ← rename class
    """Replace with a description of what makes this strategy interesting."""

    NAME        = "template"                          # ← unique slug, no spaces
    DESCRIPTION = "Template strategy. Replace with your description."

    def __init__(self) -> None:
        self._graph = None

    def setup(self, file_corpus: List[Dict]) -> None:
        """
        Called once before run().
        Load/build expensive resources here: embedding models, CrossEncoders,
        vectorstores, LLM chains, etc.
        Then compile the LangGraph by calling build_graph() with those objects.
        """
        logger.info("[Template] Setting up...")

        # Example: build a vectorstore and pass it to the graph
        # from pipeline import get_embeddings, get_chroma_client, index_pages
        # from langchain_chroma import Chroma
        # all_pages = [...]
        # index_pages(all_pages, COLLECTION)
        # vectorstore = Chroma(collection_name=COLLECTION, ...)
        # self._graph = build_graph(vectorstore)

        self._graph = build_graph()   # ← update signature to match graph.py
        logger.info("[Template] Graph compiled — ready")

    def run(
        self,
        checklist:   List[Dict],
        file_corpus: List[Dict],
    ) -> List[StrategyResult]:
        if self._graph is None:
            self.setup(file_corpus)

        results = []
        for row in checklist:
            final = self._graph.invoke({
                # ── Inputs — map row fields to your state schema ──────────
                "exigence":        row["exigence"],
                "rep_tag":         row.get("rep_tag", ""),
                "rep_comments":    row.get("rep_comments", ""),
                "proof_refs":      row.get("proof_refs", []),
                # ── Output fields — initialise empty ──────────────────────
                "retrieved_pages": [],
                "verdict":         {},
                # TODO: add any other state fields from MyStrategyState
            })

            results.append(StrategyResult(
                exigence        = row["exigence"],
                row_index       = row["row_index"],
                rep_tag         = row["rep_tag"],
                human_label     = row.get("human_label"),
                human_notes     = row.get("human_notes", ""),
                verdict         = final["verdict"],
                evidence_type   = "ambiguous",        # ← set if your graph classifies it
                retrieved_pages = final.get("retrieved_pages", []),
            ))
        return results

    def execute(self, checklist: List[Dict], file_corpus: List[Dict]):
        """Called by runner.py. Handles setup() + per-row timing."""
        self.setup(file_corpus)
        results = []
        for row in checklist:
            t0 = time.perf_counter()
            r  = self.run([row], file_corpus)[0]
            r.strategy_name = self.NAME
            r.latency_ms    = round((time.perf_counter() - t0) * 1000, 1)
            results.append(r)
        return results
