"""
strategies/TEMPLATE/graph.py — LangGraph definition for YOUR_STRATEGY_NAME.

This file owns:
  - The TypedDict state schema
  - All node functions
  - The routing logic (if conditional edges are needed)
  - build_graph() — called once by strategy.py's setup()

External objects that are NOT serialisable (vectorstores, ML models, etc.)
are injected into build_graph() as arguments and captured by the node
closures. They never appear in the state dict.

─────────────────────────────────────────────────────────────────────────────

QUICK REFERENCE — available pipeline primitives:

    from pipeline import (
        # Retrieval
        bm25_page_triage,        # BM25 over the full corpus
        index_pages,             # embed pages into a named ChromaDB collection
        semantic_search,         # similarity search inside a named collection
        get_embeddings,          # singleton HuggingFaceEmbeddings
        get_chroma_client,       # singleton ChromaDB client

        # Verdict LLM chains
        run_document_verdict,    # verdict using retrieved doc context
        run_oral_verdict,        # verdict from rep's declaration only
        classify_evidence_requirement,   # document_required / oral_implicit / ambiguous
        generate_french_keywords,        # BM25 query expansion

        # Label constants
        LABEL_COMPLIANT, LABEL_PARTIAL, LABEL_NON,
    )

ChromaDB collection naming: use a unique name per strategy so indexes
never collide. Convention: "{strategy_name}_pages", e.g. "my_strategy_pages".
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List

from langgraph.graph import END, StateGraph
from typing_extensions import TypedDict

# Import only what your graph actually uses
from pipeline import (
    run_document_verdict,
    LABEL_NON,
)

logger = logging.getLogger(__name__)


# ─── State ─────────────────────────────────────────────────────────────────────
# Define every field your nodes read or write.
# Keep state serialisable: plain dicts, lists, strings, floats.
# Inject heavy objects (vectorstores, ML models) via build_graph() closures.

class MyStrategyState(TypedDict):           # ← rename this
    # Inputs — always present, set by strategy.py before invoking
    exigence:     str
    rep_tag:      str
    rep_comments: str
    proof_refs:   List[str]

    # TODO: add output fields for each node
    retrieved_pages: List[Dict]
    verdict:         Dict


# ─── Nodes ─────────────────────────────────────────────────────────────────────
# Nodes are plain functions: (state) -> dict of partial state updates.
# They are defined INSIDE build_graph() so they can close over injected objects.


# ─── Graph builder ─────────────────────────────────────────────────────────────

def build_graph():   # ← add your injected objects here, e.g. build_graph(vectorstore, cross_encoder)
    """
    Build and compile the LangGraph for this strategy.

    Args:
        injected_object_1: e.g. a Chroma vectorstore, a CrossEncoder, an LLM chain…
        (add more as needed)

    Returns:
        Compiled LangGraph runnable.
    """

    # ── Node 1 ───────────────────────────────────────────────────────────────
    def retrieval_node(state: MyStrategyState) -> Dict[str, Any]:
        """TODO: retrieve relevant pages from the proof corpus."""
        logger.info(f"[MyStrategy/Node1] '{state['exigence'][:70]}'")

        # Example: pure similarity search
        # docs = injected_object_1.similarity_search(state["exigence"], k=4)
        # pages = [{...} for doc in docs]
        pages: List[Dict] = []

        return {"retrieved_pages": pages}

    # ── Node 2 ───────────────────────────────────────────────────────────────
    def verdict_node(state: MyStrategyState) -> Dict[str, Any]:
        """Call the shared LLM verdict chain."""
        logger.info(
            f"[MyStrategy/Node2] Verdict — "
            f"{len(state.get('retrieved_pages', []))} page(s)"
        )
        try:
            verdict = run_document_verdict(
                exigence        = state["exigence"],
                rep_tag         = state.get("rep_tag", ""),
                rep_comments    = state.get("rep_comments", ""),
                proof_refs      = state.get("proof_refs", []),
                retrieved_pages = state.get("retrieved_pages", []),
                french_keywords = [],
            )
        except Exception as e:
            logger.error(f"[MyStrategy/Node2] Verdict failed: {e}")
            verdict = {
                "compliance":         LABEL_NON,
                "justification_type": "inferred",
                "evidence":           f"Erreur: {e}",
                "confidence":         0.0,
                "reasoning":          f"Verdict non déterminé: {e}",
                "source_files":       [],
            }
        return {"verdict": verdict}

    # ── Wire the graph ────────────────────────────────────────────────────────
    graph = StateGraph(MyStrategyState)

    graph.add_node("retrieval", retrieval_node)
    graph.add_node("verdict",   verdict_node)

    graph.set_entry_point("retrieval")
    graph.add_edge("retrieval", "verdict")
    graph.add_edge("verdict",   END)

    # For conditional routing, replace the last edge with:
    #   graph.add_conditional_edges("node_name", routing_fn, {"branch_a": "node_a", ...})

    return graph.compile()
