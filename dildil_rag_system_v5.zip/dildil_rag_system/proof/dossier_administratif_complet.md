# DOSSIER ADMINISTRATIF COMPLET PRESTATAIRE — TECHSOL GROUP SAS

*Ce document regroupe l'ensemble des pièces administratives du prestataire.*
*Il est transmis en réponse à la demande de due diligence AXA France.*

---

## SECTION 1 — INFORMATIONS LÉGALES ET ADMINISTRATIVES

### Extrait Kbis
Numéro RCS : Nanterre B 812 345 678
Date d'immatriculation : 14 mars 2015
Forme juridique : Société par Actions Simplifiée (SAS)
Capital social : 150 000 €
Siège social : 15 avenue de l'Innovation, 92100 Boulogne-Billancourt
Code APE : 6201Z — Programmation informatique

### Dirigeants
- Président : M. Alexandre NGUYEN
- Directeur Général Délégué : Mme Sophie MARTIN
- Directeur SSI (RSSI) : M. Karim BENCHEIKH

--- End of Page 1 ---

## SECTION 2 — ASSURANCES

### Attestation d'assurance Responsabilité Civile Professionnelle

**Compagnie :** AXA Entreprises
**Numéro de police :** FR-RCP-2024-00156892
**Souscripteur :** TECHSOL GROUP SAS

**Garanties souscrites :**
- Responsabilité Civile Professionnelle : **1 500 000 € par sinistre**
- Responsabilité Civile Exploitation : 500 000 €
- Cyber Responsabilité : 2 000 000 €
- Protection juridique : incluse

**Période de garantie :** 1er janvier 2024 au 31 décembre 2024

*⚠️ Cette attestation sera renouvelée avec augmentation du plafond RCP à 2 000 000 € à compter du 1er avril 2025, suite à la demande formulée par TECHSOL GROUP.*

**Attestation émise par :** AXA Entreprises — Service Souscription PME/ETI
**Date d'émission :** 02 janvier 2024

--- End of Page 2 ---

## SECTION 3 — SITUATION FISCALE ET SOCIALE

### Attestation de régularité fiscale
Délivrée par la Direction Générale des Finances Publiques
Date : 15 novembre 2024
TECHSOL GROUP SAS est à jour de ses obligations fiscales.
Référence : DGFIP-2024-11-812345678

### Attestation URSSAF
TECHSOL GROUP SAS est à jour de ses cotisations sociales.
Période vérifiée : T3 2024
Référence : URF-IDF-2024-T3-812345678

--- End of Page 3 ---

## SECTION 4 — REFERENCES CLIENTS SECTEUR FINANCIER

### Lettre de référence — Société Générale
*Boulogne-Billancourt, le 15 octobre 2024*

Nous, soussignés, Société Générale SA, certifions avoir fait appel aux services de TECHSOL GROUP SAS dans le cadre du projet de refonte de notre portail de gestion des contrats d'épargne (2021-2024).

TECHSOL GROUP a démontré une expertise solide en développement Java/Spring et en sécurisation des accès (OAuth2, MFA). Le prestataire a respecté l'ensemble de nos exigences SSI et RGPD.

**Signataire :** Direction des Achats Informatiques, Société Générale

--- End of Page 4 ---

## SECTION 5 — LISTE DES SOUS-TRAITANTS CRITIQUES

Conformément à l'exigence de transparence sur la chaîne de sous-traitance :

| Prestataire | Rôle | Localisation données | Certifications |
|-------------|------|---------------------|----------------|
| Amazon Web Services (AWS) | Hébergement cloud (IaaS) | eu-west-1 (Irlande), eu-central-1 (Francfort) | ISO 27001, SOC 2 Type II, PCI-DSS |
| Datadog Inc. | Monitoring et observabilité | Serveurs US + EU (contrat Data Processing Agreement signé) | SOC 2 Type II |
| GitLab Inc. | Gestion du code source (SaaS) | Hébergement EU (option activée) | ISO 27001 |

*Note : AWS et Datadog traitent des méta-données d'infrastructure uniquement. Aucune donnée personnelle d'utilisateurs finaux AXA n'est transmise à ces sous-traitants.*

--- End of Page 5 ---

## SECTION 6 — RECETTES DE CUISINE DE L'ÉQUIPE (HORS SCOPE)

*Cette section a été ajoutée par erreur dans la compilation du dossier. Elle ne contient pas d'information pertinente pour la due diligence.*

Tarte aux pommes :
- 3 pommes golden
- 1 pâte brisée
- 50g de sucre
...

--- End of Page 6 ---

## SECTION 7 — POLITIQUE DE GESTION DES VULNÉRABILITÉS

### Objet et périmètre
Cette politique définit les règles et procédures de gestion des vulnérabilités de sécurité applicables à l'ensemble des systèmes d'information de TECHSOL GROUP SAS.

### Niveaux de criticité et SLA de remédiation

| Criticité | Définition (CVSS) | SLA de correction |
|-----------|-------------------|-------------------|
| Critique  | CVSS ≥ 9.0        | **24 heures**     |
| Haute     | CVSS 7.0-8.9      | **5 jours ouvrés** |
| Moyenne   | CVSS 4.0-6.9      | 30 jours          |
| Faible    | CVSS < 4.0        | Prochaine release |

### Processus de détection
- Scans automatisés hebdomadaires (Qualys)
- Veille CVE quotidienne (flux NVD + CERT-FR)
- Pentests annuels par prestataire externe certifié

### Suivi et reporting
Toutes les vulnérabilités sont tracées dans Jira Security avec :
- Propriétaire de la remédiation
- Date de découverte
- Date de remédiation cible et effective
- Preuves de correction

--- End of Page 7 ---

## SECTION 8 — ARCHITECTURE D'HÉBERGEMENT

### Infrastructure cloud

TECHSOL GROUP héberge l'intégralité de ses services sur Amazon Web Services (AWS) dans les régions européennes suivantes :
- **eu-west-1** (Irlande) — Production principale
- **eu-central-1** (Francfort) — Disaster Recovery

**Garantie de localisation des données :**
Conformément à notre politique RGPD et aux exigences de nos clients du secteur financier, nous garantissons qu'aucune donnée client ne quitte l'Espace Économique Européen (EEE) sur l'infrastructure AWS.

**Datadog (monitoring) :**
Datadog est configuré pour envoyer les métriques vers ses serveurs EU (eu1.datadoghq.com). Un Data Processing Agreement (DPA) conforme au RGPD est en place. Les données de monitoring transmises sont des métriques d'infrastructure (CPU, mémoire, latences) sans données personnelles d'utilisateurs finaux.

--- End of Page 8 ---

## SECTION 9 — FORMATION CYBERSÉCURITÉ 2024

### Attestation collective de formation

**Organisme de formation :** CyberEdu (certifié Qualiopi)
**Programme :** Sensibilisation à la cybersécurité pour collaborateurs non-techniques
**Date de réalisation :** 14-15 octobre 2024
**Format :** E-learning + session live (2h)

**Collaborateurs formés :** 45 collaborateurs sur 47 (96%)
*Les 2 collaborateurs non formés étaient en arrêt maladie. Formation prévue à leur retour.*

**Contenu couvert :**
- Phishing et ingénierie sociale (détection, signalement)
- Hygiène des mots de passe et gestionnaire de mots de passe
- RGPD : données personnelles, droits des personnes, obligations
- Gestion des appareils mobiles et télétravail sécurisé
- Procédure de signalement des incidents

**Résultats :** Score moyen au quiz de validation : 82% (seuil requis : 70%)

--- End of Page 9 ---
