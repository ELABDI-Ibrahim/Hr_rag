# CERTIFICAT DE CONFORMITÉ ISO/IEC 27001:2022

**Bureau Veritas Certification France**

## CERTIFICAT N° FR-2025-ISO27001-00847

Ce certificat atteste que le Système de Management de la Sécurité de l'Information (SMSI) de :

**Prestataire : TECHSOL GROUP SAS**
Siège social : 15 avenue de l'Innovation, 92100 Boulogne-Billancourt
SIREN : 812 345 678

**est conforme aux exigences de la norme :**
**ISO/IEC 27001:2022**

### Périmètre de certification
Fourniture de services d'hébergement, de traitement de données et de développement logiciel pour clients du secteur financier et assurantiel, incluant :
- Infrastructures cloud (AWS eu-west-1, eu-central-1)
- Services de développement applicatif
- Assistance à maîtrise d'ouvrage SSI

### Dates de validité
- **Date de première certification :** 15 janvier 2022
- **Date de renouvellement :** 15 janvier 2025
- **Date d'expiration :** 14 janvier 2026

### Décision de certification
Suite à l'audit de renouvellement réalisé les 10-12 décembre 2024 par l'équipe d'auditeurs Bureau Veritas, aucune non-conformité majeure n'a été détectée. 3 points d'amélioration ont été identifiés et un plan de correction a été validé.

**Auditeur principal :** M. Jean-Pierre MARTIN, Lead Auditor ISO 27001
**Décision :** CERTIFICATION ACCORDÉE

---
*Signé électroniquement par Bureau Veritas Certification France*
*Certificat vérifiable sur : www.bureauveritas.fr/certification/verification*
*Réf. audit : BV-2024-1210-A847*

--- End of Page 1 ---

## ANNEXE TECHNIQUE — Contrôles ISO 27001 vérifiés

### Clauses auditées (ISO 27001:2022)
- Clause 5 : Leadership et engagement de la direction ✅
- Clause 6 : Planification des risques SSI ✅
- Clause 7 : Support (ressources, compétences, sensibilisation) ✅
- Clause 8 : Réalisation des opérations ✅
- Clause 9 : Évaluation des performances ✅
- Clause 10 : Amélioration continue ✅

### Annexe A — Contrôles (sélection)
- A.5 Politiques de sécurité de l'information : CONFORME
- A.6 Organisation de la sécurité : CONFORME
- A.8 Gestion des actifs : CONFORME
- A.9 Contrôle d'accès : CONFORME — MFA déployé sur 100% des accès critiques
- A.10 Cryptographie : CONFORME
- A.12 Sécurité liée à l'exploitation : CONFORME
- A.13 Sécurité des communications : CONFORME
- A.14 Acquisition, développement et maintenance des SI : CONFORME
- A.16 Gestion des incidents : CONFORME — procédure de notification 72h documentée
- A.17 Continuité de l'activité : POINT D'AMÉLIORATION — PCA à retester avant juin 2025
- A.18 Conformité : CONFORME

--- End of Page 2 ---
