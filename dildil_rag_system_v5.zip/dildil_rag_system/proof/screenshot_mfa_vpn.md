# PREUVE MFA VPN — TECHSOL GROUP SAS

## Capture d'écran : Authentification Multi-Facteurs VPN

**Date de capture :** 12 mars 2025
**Système :** Cisco AnyConnect VPN + Duo Security MFA

### Description de la capture
La capture d'écran ci-jointe (non reproductible en format texte) montre :
1. L'interface de connexion VPN Cisco AnyConnect
2. La demande de validation Duo Security (push notification)
3. Le tableau de bord Duo Admin montrant : 47/47 utilisateurs actifs avec MFA obligatoire
4. Politique "No MFA bypass allowed" activée

### Politique MFA en vigueur
- MFA obligatoire pour : VPN, accès SSH aux serveurs, console AWS, GitLab Admin
- Méthodes acceptées : Duo Push (application mobile), TOTP (Google Authenticator), clé FIDO2
- Exception temporaire : Aucune
- Dernier audit de la politique : 01/02/2025

### Accès aux outils AXA
Les accès aux portails et outils AXA (intranet, ticketing, environnements de recette) sont gérés via le SSO AXA (Azure AD AXA). Le MFA de ces accès est sous la responsabilité et la gestion d'AXA, conformément aux accords contractuels.

Note : Certains portails partenaires tiers (hors périmètre AXA direct) utilisent des accès nominatifs sans MFA — ce point est identifié comme point d'amélioration dans notre roadmap SSI Q2 2025.

--- End of Page 1 ---
