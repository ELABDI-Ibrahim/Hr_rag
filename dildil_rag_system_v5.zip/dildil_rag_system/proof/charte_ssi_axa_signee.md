# CHARTE DE SÉCURITÉ DES SYSTÈMES D'INFORMATION AXA
## Signature Prestataire — Version 3.0 (2022)

**Prestataire :** TECHSOL GROUP SAS
**Date de signature :** 03 mars 2025
**Signataire côté prestataire :** M. Karim BENCHEIKH, RSSI

---

## ENGAGEMENT DU PRESTATAIRE

Je soussigné, M. Karim BENCHEIKH, en qualité de Responsable de la Sécurité des Systèmes d'Information de TECHSOL GROUP SAS, certifie avoir pris connaissance et m'engage à respecter les dispositions de la Charte de Sécurité Informatique AXA dans sa version ci-jointe.

**Version de la charte signée : 3.0 — Juin 2022**

### Engagements pris :
1. Respecter les politiques de sécurité AXA lors des interventions sur le SI AXA
2. Ne pas introduire de logiciels non autorisés sur les postes et systèmes AXA
3. Signaler immédiatement tout incident ou suspicion d'incident de sécurité
4. Former les collaborateurs intervenant chez AXA aux règles de sécurité
5. Respecter les règles de classification et de traitement des données AXA

**Signature électronique :** K. BENCHEIKH (certificat RGS** — valide)
**Date :** 03/03/2025

---

*Note interne : La version 3.2 de la charte (novembre 2024) n'a pas encore été reçue par le prestataire au moment de la signature. Ce document sera mis à jour dès réception de la nouvelle version.*

--- End of Page 1 ---
