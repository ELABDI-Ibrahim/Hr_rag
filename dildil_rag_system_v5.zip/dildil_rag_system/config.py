"""
config.py — Central configuration for AI4DueDil compliance RAG pipeline.

All modules import from here. Values are loaded from .env via python-dotenv.
"""
import os
from dotenv import load_dotenv

load_dotenv()

# ─── LLM ─────────────────────────────────────────────────────────────────────
GROQ_API_KEY: str = os.getenv("GROQ_API_KEY", "")
GROQ_MODEL:   str = os.getenv("GROQ_MODEL",   "llama-3.3-70b-versatile")

# ─── Embeddings ───────────────────────────────────────────────────────────────
EMBEDDING_MODEL: str = os.getenv(
    "EMBEDDING_MODEL",
    "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
)

# ─── Retrieval Tuning ─────────────────────────────────────────────────────────
BM25_TOP_K:    int  = int(os.getenv("BM25_TOP_K",    "10"))
SEMANTIC_TOP_M: int = int(os.getenv("SEMANTIC_TOP_M", "4"))
MIN_TEXT_LENGTH: int = int(os.getenv("MIN_TEXT_LENGTH", "50"))

# ─── OCR ─────────────────────────────────────────────────────────────────────
OCR_LANGUAGES: str = os.getenv("OCR_LANGUAGES", "fra+eng")

# ─── Paths ───────────────────────────────────────────────────────────────────
PROOF_FOLDER:  str = os.getenv("PROOF_FOLDER",  "./proof")
EXCEL_INPUT:   str = os.getenv("EXCEL_INPUT",   "./dildil_input.xlsx")
EXCEL_OUTPUT:  str = os.getenv("EXCEL_OUTPUT",  "./dildil_results.xlsx")
EVAL_OUTPUT:   str = os.getenv("EVAL_OUTPUT",   "./dildil_evaluation.xlsx")

# ─── ChromaDB ────────────────────────────────────────────────────────────────
CHROMA_PERSIST_DIR:   str  = os.getenv("CHROMA_PERSIST_DIR",   "./chroma_db")
CHROMA_COLLECTION_NAME: str = os.getenv("CHROMA_COLLECTION_NAME", "dildil_pages")
RESTRICT_SEARCH_TO_CANDIDATE_PAGES: bool = (
    os.getenv("RESTRICT_SEARCH_TO_CANDIDATE_PAGES", "true").lower() == "true"
)

# ─── MLflow ───────────────────────────────────────────────────────────────────
MLFLOW_TRACKING_URI:    str = os.getenv("MLFLOW_TRACKING_URI",    "")
MLFLOW_EXPERIMENT_NAME: str = os.getenv("MLFLOW_EXPERIMENT_NAME", "dildil_compliance_rag")

# ─── Compliance Labels (canonical) ───────────────────────────────────────────
# These are the three possible compliance statuses used throughout the system.
# The representative's raw input is normalised to one of these.
LABEL_COMPLIANT  = "compliant"
LABEL_PARTIAL    = "partially_compliant"
LABEL_NON        = "non_compliant"
COMPLIANCE_LABELS = [LABEL_COMPLIANT, LABEL_PARTIAL, LABEL_NON]

# ─── Evidence Types ───────────────────────────────────────────────────────────
EVIDENCE_DOCUMENT = "document_required"  # 📄 Hard proof expected (cert, contract…)
EVIDENCE_ORAL     = "oral_implicit"      # 🗣️ Declarative / process-based
EVIDENCE_AMBIGUOUS = "ambiguous"         # ❓ Could go either way

# ─── Weighted Kappa penalty matrix ────────────────────────────────────────────
# Rows = True label, Cols = Predicted label
# Order: [compliant, partially_compliant, non_compliant]
# non_compliant vs compliant → penalty 2 (worst disagreement)
KAPPA_WEIGHTS = [
    [0, 1, 2],
    [1, 0, 1],
    [2, 1, 0],
]


def validate_config() -> None:
    """Raise early if critical config is missing."""
    if not GROQ_API_KEY:
        raise ValueError(
            "GROQ_API_KEY is not set. Please fill in your .env file."
        )
