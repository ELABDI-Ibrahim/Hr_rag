"""
scripts/show_graph.py — Visualise any strategy's LangGraph.

Usage:
    python scripts/show_graph.py --strategy naive_rag
    python scripts/show_graph.py --strategy bm25_hybrid
    python scripts/show_graph.py --strategy reranker
    python scripts/show_graph.py --strategy hyde
    python scripts/show_graph.py --all
    python scripts/show_graph.py --strategy bm25_hybrid --format mermaid
    python scripts/show_graph.py --strategy bm25_hybrid --format png --out graph.png

Outputs:
    ascii   — prints nodes and edges in the terminal (default, no extra deps)
    mermaid — prints Mermaid source, paste at https://mermaid.live
    png     — saves a PNG (requires: pip install playwright + playwright install chromium)

Works without a GROQ_API_KEY — graphs are built with stub injections so no
LLM calls are made at compile time.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))


# ─── Stub injections ──────────────────────────────────────────────────────────

class _StubVS:
    """Duck-type Chroma vectorstore (no actual DB needed)."""
    def similarity_search(self, query, k=4): return []

class _StubCE:
    """Duck-type CrossEncoder (no model load needed)."""
    def predict(self, pairs): return [0.0] * len(pairs)


def _build(name: str):
    """Compile a strategy's LangGraph with stub injections."""
    if name == "naive_rag":
        from strategies.naive_rag.graph import build_graph
        return build_graph(_StubVS())
    if name == "bm25_hybrid":
        from strategies.bm25_hybrid.graph import build_graph
        return build_graph()
    if name == "reranker":
        from strategies.reranker.graph import build_graph
        return build_graph(_StubCE(), corpus_pages=[])
    if name == "hyde":
        from strategies.hyde.graph import build_graph
        return build_graph(_StubVS())
    raise ValueError(f"Unknown strategy '{name}'. Available: naive_rag, bm25_hybrid, reranker, hyde")


# ─── Formatters ───────────────────────────────────────────────────────────────

def _print_ascii(graph, name: str) -> None:
    print(f"\n{'═' * 55}")
    print(f"  {name}")
    print(f"{'═' * 55}")

    dg = graph.get_graph()

    print("\n  Nodes:")
    for node_id in dg.nodes:
        icon = "○" if node_id.startswith("__") else "●"
        print(f"    {icon}  {node_id}")

    print("\n  Edges:")
    for edge in dg.edges:
        tag = "  [conditional]" if getattr(edge, "conditional", False) else ""
        print(f"    {edge.source}  →  {edge.target}{tag}")

    print()


def _print_mermaid(graph, name: str) -> None:
    print(f"\n--- Mermaid for: {name} ---")
    try:
        print(graph.get_graph().draw_mermaid())
    except Exception:
        # Manual Mermaid fallback
        dg = graph.get_graph()
        lines = ["flowchart TD"]
        for node_id in dg.nodes:
            if not node_id.startswith("__"):
                lines.append(f"    {node_id}[{node_id}]")
        for edge in dg.edges:
            if not edge.source.startswith("__") and not edge.target.startswith("__"):
                arrow = "-.->|conditional|" if getattr(edge, "conditional", False) else "-->"
                lines.append(f"    {edge.source} {arrow} {edge.target}")
        print("\n".join(lines))
    print()


def _save_png(graph, name: str, out: str) -> None:
    out_path = Path(out)
    try:
        png_bytes = graph.get_graph().draw_mermaid_png()
        out_path.write_bytes(png_bytes)
        print(f"✅ PNG saved: {out_path}")
    except Exception as e:
        print(
            f"PNG export failed: {e}\n"
            "Install deps with:\n"
            "  pip install playwright && playwright install chromium\n\n"
            "Falling back to Mermaid source:"
        )
        _print_mermaid(graph, name)


# ─── CLI ──────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="Visualise strategy LangGraphs")
    g = parser.add_mutually_exclusive_group(required=True)
    g.add_argument("--strategy", metavar="NAME")
    g.add_argument("--all",      action="store_true")
    parser.add_argument("--format", choices=["ascii", "mermaid", "png"], default="ascii")
    parser.add_argument("--out",    default="graph.png")
    args = parser.parse_args()

    known = ["naive_rag", "bm25_hybrid", "reranker", "hyde"]
    targets = known if args.all else [args.strategy]

    for name in targets:
        try:
            graph = _build(name)
        except ValueError as e:
            print(f"❌ {e}"); continue
        except Exception as e:
            print(f"❌ Build failed for '{name}': {e}"); continue

        if args.format == "ascii":
            _print_ascii(graph, name)
        elif args.format == "mermaid":
            _print_mermaid(graph, name)
        elif args.format == "png":
            out = f"{name}_graph.png" if args.all else args.out
            _save_png(graph, name, out)


if __name__ == "__main__":
    main()
