"""
scripts/manage_chroma.py — Inspect and manage ChromaDB collections.

Usage:
    python scripts/manage_chroma.py --list
    python scripts/manage_chroma.py --info naive_rag_pages
    python scripts/manage_chroma.py --info all
    python scripts/manage_chroma.py --clear naive_rag_pages
    python scripts/manage_chroma.py --clear all
    python scripts/manage_chroma.py --diff naive_rag_pages hyde_pages

Each strategy uses a separate collection so their indexes never collide:
    naive_rag    → naive_rag_pages
    bm25_hybrid  → dildil_pages  (from CHROMA_COLLECTION_NAME in config)
    hyde         → hyde_pages
    reranker     → (no collection — cross-encoder runs in memory)
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import chromadb
from config import CHROMA_PERSIST_DIR

# Known strategy → collection mapping (update if you add a new strategy)
STRATEGY_COLLECTIONS = {
    "naive_rag":   "naive_rag_pages",
    "bm25_hybrid": "dildil_pages",
    "hyde":        "hyde_pages",
    "reranker":    None,   # no collection
}


def _client() -> chromadb.PersistentClient:
    return chromadb.PersistentClient(path=CHROMA_PERSIST_DIR)


def _all_collection_names() -> list[str]:
    return [c.name for c in _client().list_collections()]


# ─── Commands ─────────────────────────────────────────────────────────────────

def cmd_list() -> None:
    """List all collections in the ChromaDB store."""
    names = _all_collection_names()
    if not names:
        print(f"No collections found in {CHROMA_PERSIST_DIR}")
        return

    client = _client()
    print(f"\nChromaDB at: {CHROMA_PERSIST_DIR}\n")
    print(f"{'Collection':<30} {'Pages':>8}  Strategy")
    print("─" * 60)
    for name in sorted(names):
        try:
            col   = client.get_collection(name)
            count = col.count()
        except Exception:
            count = "?"

        # Reverse-lookup strategy name
        strategy = next(
            (s for s, c in STRATEGY_COLLECTIONS.items() if c == name), "—"
        )
        print(f"  {name:<28} {count:>8}  {strategy}")
    print()


def cmd_info(collection_name: str) -> None:
    """Print detailed info about a collection (or all)."""
    if collection_name == "all":
        for name in sorted(_all_collection_names()):
            cmd_info(name)
        return

    client = _client()
    try:
        col = client.get_collection(collection_name)
    except Exception:
        print(f"❌ Collection '{collection_name}' not found")
        return

    count = col.count()
    print(f"\n{'─' * 55}")
    print(f"  Collection : {collection_name}")
    print(f"  Pages      : {count}")

    if count == 0:
        print("  (empty)\n")
        return

    # Sample a few pages
    sample = col.get(limit=min(5, count), include=["metadatas", "documents"])
    print(f"\n  Sample pages ({min(5, count)} of {count}):")
    for i, (doc, meta) in enumerate(
        zip(sample["documents"], sample["metadatas"]), 1
    ):
        src  = meta.get("source_file", "?")
        page = meta.get("page_num", "?")
        text = doc[:80].replace("\n", " ")
        print(f"  [{i}] {src} p.{page} — {text}…")

    # Source file breakdown
    all_meta = col.get(include=["metadatas"])["metadatas"]
    from collections import Counter
    file_counts = Counter(m.get("source_file", "?") for m in all_meta)
    print(f"\n  Source file breakdown ({len(file_counts)} file(s)):")
    for fname, cnt in sorted(file_counts.items(), key=lambda x: -x[1]):
        bar = "█" * min(cnt, 40)
        print(f"    {fname:<40} {bar} {cnt}")
    print()


def cmd_clear(collection_name: str, confirm: bool = False) -> None:
    """Delete a collection (or all). Asks for confirmation unless --yes passed."""
    if collection_name == "all":
        names = _all_collection_names()
        if not names:
            print("Nothing to clear.")
            return
        if not confirm:
            print(f"Will delete ALL collections: {names}")
            ans = input("Type 'yes' to confirm: ").strip().lower()
            if ans != "yes":
                print("Aborted.")
                return
        client = _client()
        for name in names:
            client.delete_collection(name)
            print(f"  ✅ Deleted: {name}")
        return

    client = _client()
    try:
        col   = client.get_collection(collection_name)
        count = col.count()
    except Exception:
        print(f"❌ Collection '{collection_name}' not found")
        return

    if not confirm:
        ans = input(
            f"Delete '{collection_name}' ({count} pages)? Type 'yes' to confirm: "
        ).strip().lower()
        if ans != "yes":
            print("Aborted.")
            return

    client.delete_collection(collection_name)
    print(f"✅ Deleted '{collection_name}' ({count} pages)")
    print("   The next run of the strategy will re-index automatically.")


def cmd_diff(name_a: str, name_b: str) -> None:
    """
    Compare two collections: how many pages they share (same content_id)
    vs. how many are unique to each.
    """
    client = _client()

    def _ids(cname: str) -> set[str]:
        try:
            col = client.get_collection(cname)
            return set(col.get(include=[])["ids"])
        except Exception:
            return set()

    ids_a = _ids(name_a)
    ids_b = _ids(name_b)

    shared    = ids_a & ids_b
    only_a    = ids_a - ids_b
    only_b    = ids_b - ids_a

    print(f"\n  {name_a:<30}  {len(ids_a):>6} pages")
    print(f"  {name_b:<30}  {len(ids_b):>6} pages")
    print(f"  Shared (same content_id)    {len(shared):>6} pages")
    print(f"  Only in {name_a:<21}  {len(only_a):>6} pages")
    print(f"  Only in {name_b:<21}  {len(only_b):>6} pages")

    if ids_a and ids_b:
        jaccard = len(shared) / len(ids_a | ids_b)
        print(f"  Jaccard similarity          {jaccard:.1%}")
    print()


# ─── CLI ──────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Manage AI4DueDil ChromaDB collections",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python scripts/manage_chroma.py --list
  python scripts/manage_chroma.py --info naive_rag_pages
  python scripts/manage_chroma.py --info all
  python scripts/manage_chroma.py --clear naive_rag_pages
  python scripts/manage_chroma.py --clear all --yes
  python scripts/manage_chroma.py --diff naive_rag_pages hyde_pages
        """,
    )
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--list",  action="store_true",   help="List all collections")
    group.add_argument("--info",  metavar="COLLECTION",  help="Show info (or 'all')")
    group.add_argument("--clear", metavar="COLLECTION",  help="Delete collection (or 'all')")
    group.add_argument("--diff",  nargs=2, metavar=("COL_A", "COL_B"),
                       help="Compare two collections")

    parser.add_argument("--yes", action="store_true", help="Skip confirmation for --clear")

    args = parser.parse_args()

    if args.list:
        cmd_list()
    elif args.info:
        cmd_info(args.info)
    elif args.clear:
        cmd_clear(args.clear, confirm=args.yes)
    elif args.diff:
        cmd_diff(args.diff[0], args.diff[1])


if __name__ == "__main__":
    main()
