"""
main.py — Convenience entry point (delegates to runner.py).

For full control use runner.py directly:
    python runner.py --strategy naive_rag
    python runner.py --strategy bm25_hybrid
    python runner.py --all
    python runner.py --compare naive_rag bm25_hybrid
    python runner.py --list

main.py exists so `python main.py` keeps working as a quick default run
(equivalent to `python runner.py --strategy bm25_hybrid`).
"""
import sys
from runner import main

if __name__ == "__main__":
    # Inject default args so runner.py's argparse finds --strategy bm25_hybrid
    # unless the caller already passed something
    if len(sys.argv) == 1:
        sys.argv += ["--strategy", "bm25_hybrid"]
    main()
