"""
utils/strategy_compare.py — Side-by-side evaluation comparison across strategies.

Takes evaluation results from N strategies and writes a multi-sheet
comparison report to Excel.

Sheets:
  "Overview"     — one row per strategy, all KPIs side by side
  "Per Row"      — each exigence × strategy with labels + metrics
  "κ Ranking"    — strategies ranked by weighted Cohen's κ
  "Retrieval"    — retrieval metric comparison (document_required rows only)
  "Latency"      — avg latency per strategy, per evidence type breakdown
  "Confusion"    — confusion matrices for all strategies side by side
"""
from __future__ import annotations

import logging
from typing import Dict, List, Optional

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from utils.evaluation import (
    compute_aggregate_metrics,
    compute_per_row_metrics,
    weighted_cohen_kappa,
    label_f1,
)

logger = logging.getLogger(__name__)

# ─── Styles ───────────────────────────────────────────────────────────────────
_thin   = Side(style="thin", color="CCCCCC")
_border = Border(left=_thin, right=_thin, top=_thin, bottom=_thin)
_H_FONT = Font(name="Calibri", bold=True, size=10, color="FFFFFF")
_H_FILL = PatternFill("solid", start_color="1A3A5C")
_B_FONT = Font(name="Calibri", size=10)
_BOLD   = Font(name="Calibri", bold=True, size=10)

_COMP_FILLS = {
    "compliant":           PatternFill("solid", start_color="C6EFCE"),
    "partially_compliant": PatternFill("solid", start_color="FFEB9C"),
    "non_compliant":       PatternFill("solid", start_color="FFC7CE"),
}
_KAPPA_FILLS = {
    "excellent": PatternFill("solid", start_color="C6EFCE"),  # κ > 0.8
    "good":      PatternFill("solid", start_color="FFEB9C"),  # κ 0.6-0.8
    "poor":      PatternFill("solid", start_color="FFC7CE"),  # κ < 0.6
}
_BEST_FILL = PatternFill("solid", start_color="BDD7EE")  # highlight best value


def _kappa_fill(k: Optional[float]) -> PatternFill:
    if k is None:
        return PatternFill()
    if k > 0.8:
        return _KAPPA_FILLS["excellent"]
    if k > 0.6:
        return _KAPPA_FILLS["good"]
    return _KAPPA_FILLS["poor"]


def _hdr(ws, row: int, col: int, value: str, width: Optional[int] = None) -> None:
    c = ws.cell(row=row, column=col, value=value)
    c.font   = _H_FONT
    c.fill   = _H_FILL
    c.border = _border
    c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    if width:
        ws.column_dimensions[
            openpyxl.utils.get_column_letter(col)
        ].width = width


def _cell(ws, row: int, col: int, value, bold=False, fill=None, align="center") -> None:
    c = ws.cell(row=row, column=col, value=value)
    c.font   = _BOLD if bold else _B_FONT
    c.border = _border
    c.alignment = Alignment(horizontal=align, vertical="center", wrap_text=True)
    if fill:
        c.fill = fill


def _fmt(v: Optional[float], pct: bool = True) -> str:
    if v is None:
        return "N/A"
    return f"{v:.1%}" if pct else f"{v:.4f}"


# ─── Main entry point ─────────────────────────────────────────────────────────

def write_comparison_report(
    output_path: str,
    strategy_results: Dict[str, List[Dict]],
) -> None:
    """
    Write a multi-strategy comparison Excel report.

    Args:
        output_path      : Where to save the .xlsx
        strategy_results : {strategy_name: [result_dict, ...]}
                           Each result_dict is a StrategyResult.to_dict()
    """
    wb = openpyxl.Workbook()

    _write_overview(wb, strategy_results)
    _write_per_row(wb, strategy_results)
    _write_kappa_ranking(wb, strategy_results)
    _write_retrieval(wb, strategy_results)
    _write_latency(wb, strategy_results)
    _write_confusion(wb, strategy_results)

    if "Sheet" in wb.sheetnames:
        del wb["Sheet"]

    wb.save(output_path)
    logger.info(f"Comparison report written to {output_path}")


# ─── Sheet: Overview ─────────────────────────────────────────────────────────

def _write_overview(wb, strategy_results: Dict) -> None:
    ws = wb.create_sheet("Overview")

    strategies = list(strategy_results.keys())
    metrics = [
        ("κ pondéré", "kappa"),
        ("% accord exact", "agreement_pct"),
        ("Macro F1", "macro_f1"),
        ("Exact Match", "exact_match"),
        ("Avg Context Precision", "ctx_prec"),
        ("Avg Context Recall", "ctx_rec"),
        ("Avg Faithfulness", "faithfulness"),
        ("Avg Latence (ms)", "avg_latency"),
        ("N Total", "n_total"),
        ("N Étiquetés", "n_labelled"),
    ]

    # Header row
    _hdr(ws, 1, 1, "Métrique", 38)
    for j, name in enumerate(strategies, 2):
        _hdr(ws, 1, j, name, 22)

    # Compute aggregate metrics for each strategy
    agg_map: Dict[str, Dict] = {}
    for name, results in strategy_results.items():
        per_row = compute_per_row_metrics(results)
        agg     = compute_aggregate_metrics(per_row)
        avg_lat = sum(r.get("latency_ms", 0) for r in results) / max(len(results), 1)

        agg_map[name] = {
            "kappa":        agg["kappa"].get("kappa"),
            "agreement_pct":agg["kappa"].get("agreement_pct"),
            "macro_f1":     agg["label_f1"].get("macro_f1"),
            "exact_match":  agg["label_f1"].get("exact_match"),
            "ctx_prec":     agg["retrieval"].get("avg_context_precision"),
            "ctx_rec":      agg["retrieval"].get("avg_context_recall"),
            "faithfulness": agg["retrieval"].get("avg_faithfulness"),
            "avg_latency":  round(avg_lat, 1),
            "n_total":      agg["n_total"],
            "n_labelled":   agg["n_labelled"],
        }

    for i, (label, key) in enumerate(metrics, 2):
        ws.cell(row=i, column=1, value=label).font = _BOLD
        ws.cell(row=i, column=1).border = _border

        # Find best value for this metric (highlight it)
        vals = [agg_map[s].get(key) for s in strategies]
        numeric = [v for v in vals if v is not None]
        best = max(numeric) if numeric else None
        # For latency: best = min
        if key == "avg_latency" and numeric:
            best = min(numeric)

        for j, name in enumerate(strategies, 2):
            v = agg_map[name].get(key)
            is_best = (v is not None and v == best and len(numeric) > 1)

            if key in ("n_total", "n_labelled", "avg_latency"):
                display = str(v) if v is not None else "N/A"
            elif key == "kappa":
                display = _fmt(v, pct=False)
            else:
                display = _fmt(v, pct=True)

            fill = _BEST_FILL if is_best else _kappa_fill(v) if key == "kappa" else None
            _cell(ws, i, j, display, fill=fill)

    ws.freeze_panes = "B2"


# ─── Sheet: Per Row ───────────────────────────────────────────────────────────

def _write_per_row(wb, strategy_results: Dict) -> None:
    ws = wb.create_sheet("Per Row")

    strategies = list(strategy_results.keys())
    # Use the first strategy to get the exigences list
    first = next(iter(strategy_results.values()))
    exigences = [r["exigence"] for r in first]

    # Build columns: Exigence | Expert Label | [Strategy: Label, Match, Conf] ...
    col = 1
    _hdr(ws, 1, col, "Exigence", 55);       col += 1
    _hdr(ws, 1, col, "Label Expert", 20);   col += 1

    strat_start_cols = {}
    for name in strategies:
        strat_start_cols[name] = col
        _hdr(ws, 1, col,     f"{name}\nLabel IA",  20); col += 1
        _hdr(ws, 1, col,     "Match",               12); col += 1
        _hdr(ws, 1, col,     "Confiance",            12); col += 1

    ws.row_dimensions[1].height = 36

    for i, exigence in enumerate(exigences, 2):
        # Exigence text
        _cell(ws, i, 1, exigence[:100], align="left")

        # Expert label (from first strategy — all have the same)
        human = first[i - 2].get("human_label", "—") or "—"
        _cell(ws, i, 2, human)

        for name, results in strategy_results.items():
            sc = strat_start_cols[name]
            row_data = results[i - 2]
            verdict  = row_data.get("verdict", {})
            ai_label = verdict.get("compliance", "?")
            h_label  = row_data.get("human_label")
            conf     = verdict.get("confidence", 0.0)
            match    = "✅" if (h_label and ai_label == h_label) else ("❌" if h_label else "—")

            _cell(ws, i, sc,     ai_label, fill=_COMP_FILLS.get(ai_label))
            _cell(ws, i, sc + 1, match)
            _cell(ws, i, sc + 2, f"{conf:.0%}")

    ws.freeze_panes = "C2"


# ─── Sheet: κ Ranking ────────────────────────────────────────────────────────

def _write_kappa_ranking(wb, strategy_results: Dict) -> None:
    ws = wb.create_sheet("κ Ranking")

    headers = ["Rang", "Stratégie", "κ pondéré", "Interprétation", "% Accord Exact", "Macro F1"]
    for j, h in enumerate(headers, 1):
        _hdr(ws, 1, j, h, [6, 28, 14, 22, 18, 12][j - 1])

    rows = []
    for name, results in strategy_results.items():
        per_row = compute_per_row_metrics(results)
        agg     = compute_aggregate_metrics(per_row)
        k       = agg["kappa"].get("kappa")
        agree   = agg["kappa"].get("agreement_pct")
        mf1     = agg["label_f1"].get("macro_f1")
        rows.append((name, k, agree, mf1))

    rows.sort(key=lambda r: (r[1] or -999), reverse=True)

    interp = {True: "Excellent (κ > 0.8)", False: None}
    for i, (name, k, agree, mf1) in enumerate(rows, 2):
        if k is not None:
            if k > 0.8:   label = "Excellent"
            elif k > 0.6: label = "Bon"
            elif k > 0.4: label = "Modéré"
            else:         label = "Faible"
        else:
            label = "N/A"

        _cell(ws, i, 1, i - 1, bold=True)
        _cell(ws, i, 2, name,  bold=(i == 2), align="left")   # top strategy is bold
        _cell(ws, i, 3, _fmt(k, pct=False), fill=_kappa_fill(k))
        _cell(ws, i, 4, label)
        _cell(ws, i, 5, _fmt(agree))
        _cell(ws, i, 6, _fmt(mf1))


# ─── Sheet: Retrieval ────────────────────────────────────────────────────────

def _write_retrieval(wb, strategy_results: Dict) -> None:
    ws = wb.create_sheet("Retrieval")

    strategies = list(strategy_results.keys())
    _hdr(ws, 1, 1, "Exigence (document_required uniquement)", 55)
    col = 2
    for name in strategies:
        _hdr(ws, 1, col,     f"{name}\nCtx Prec", 16)
        _hdr(ws, 1, col + 1, "Ctx Rec",           14)
        _hdr(ws, 1, col + 2, "Faith.",             12)
        col += 3

    # Use first strategy to find document_required rows
    first = next(iter(strategy_results.values()))
    doc_indices = [
        i for i, r in enumerate(first)
        if r.get("evidence_type") == "document_required"
    ]

    from utils.evaluation import compute_retrieval_metrics
    for excel_row, idx in enumerate(doc_indices, 2):
        exigence = first[idx]["exigence"]
        _cell(ws, excel_row, 1, exigence[:100], align="left")

        col = 2
        for name, results in strategy_results.items():
            r        = results[idx]
            verdict  = r.get("verdict", {})
            pages    = r.get("retrieved_pages", [])
            notes    = r.get("human_notes", "")
            evidence = verdict.get("evidence", "")
            reasoning= verdict.get("reasoning", "")

            if pages:
                m = compute_retrieval_metrics(pages, reasoning, notes, evidence)
                _cell(ws, excel_row, col,     _fmt(m["context_precision"]))
                _cell(ws, excel_row, col + 1, _fmt(m["context_recall"]))
                _cell(ws, excel_row, col + 2, _fmt(m["faithfulness"]))
            else:
                for c in range(3):
                    _cell(ws, excel_row, col + c, "N/A")
            col += 3

    ws.freeze_panes = "B2"


# ─── Sheet: Latency ──────────────────────────────────────────────────────────

def _write_latency(wb, strategy_results: Dict) -> None:
    ws = wb.create_sheet("Latency")

    strategies = list(strategy_results.keys())
    headers = ["Stratégie", "Moy. globale (ms)", "Médiane (ms)",
               "Min (ms)", "Max (ms)", "N lignes"]
    for j, h in enumerate(headers, 1):
        _hdr(ws, 1, j, h, [28, 20, 14, 12, 12, 10][j - 1])

    for i, name in enumerate(strategies, 2):
        lats = [r.get("latency_ms", 0) for r in strategy_results[name]]
        lats_sorted = sorted(lats)
        n    = len(lats)
        avg  = sum(lats) / n if n else 0
        med  = lats_sorted[n // 2] if n else 0
        mn   = min(lats) if lats else 0
        mx   = max(lats) if lats else 0

        _cell(ws, i, 1, name, align="left")
        _cell(ws, i, 2, round(avg, 1))
        _cell(ws, i, 3, round(med, 1))
        _cell(ws, i, 4, round(mn,  1))
        _cell(ws, i, 5, round(mx,  1))
        _cell(ws, i, 6, n)


# ─── Sheet: Confusion ────────────────────────────────────────────────────────

def _write_confusion(wb, strategy_results: Dict) -> None:
    from config import KAPPA_WEIGHTS
    ws = wb.create_sheet("Confusion")
    labels = ["compliant", "partially_compliant", "non_compliant"]

    col_offset = 1
    for name, results in strategy_results.items():
        preds = [r["verdict"].get("compliance", "") for r in results if r.get("human_label")]
        refs  = [r["human_label"] for r in results if r.get("human_label")]

        if not preds:
            continue

        k = weighted_cohen_kappa(preds, refs)
        confusion = k["confusion"] or [[0]*3 for _ in range(3)]

        # Strategy title
        ws.merge_cells(
            start_row=1, start_column=col_offset,
            end_row=1,   end_column=col_offset + 3
        )
        c = ws.cell(row=1, column=col_offset, value=f"{name}  (κ={k['kappa']})")
        c.font = Font(name="Calibri", bold=True, size=11, color="FFFFFF")
        c.fill = _H_FILL
        c.alignment = Alignment(horizontal="center")

        # Row/col headers
        ws.cell(row=2, column=col_offset, value="Vrai \\ Prédit →").font = _BOLD
        for j, l in enumerate(labels):
            c = ws.cell(row=2, column=col_offset + 1 + j, value=l.replace("_", " "))
            c.font = _H_FONT; c.fill = _H_FILL; c.border = _border
            c.alignment = Alignment(horizontal="center", wrap_text=True)

        for i, rl in enumerate(labels):
            c = ws.cell(row=3 + i, column=col_offset, value=rl.replace("_", " "))
            c.font = _H_FONT; c.fill = _H_FILL; c.border = _border
            for j, val in enumerate(confusion[i]):
                cell = ws.cell(row=3 + i, column=col_offset + 1 + j, value=val)
                cell.alignment = Alignment(horizontal="center")
                cell.border = _border
                if i == j:
                    cell.fill = PatternFill("solid", start_color="C6EFCE")
                elif KAPPA_WEIGHTS[i][j] == 2:
                    cell.fill = PatternFill("solid", start_color="FFC7CE")
                else:
                    cell.fill = PatternFill("solid", start_color="FFEB9C")

        # Column widths
        ws.column_dimensions[openpyxl.utils.get_column_letter(col_offset)].width = 24
        for off in range(1, 4):
            ws.column_dimensions[
                openpyxl.utils.get_column_letter(col_offset + off)
            ].width = 22

        col_offset += 5   # gap of 1 between matrices
