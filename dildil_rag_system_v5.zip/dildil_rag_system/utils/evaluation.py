"""
utils/evaluation.py — AI4DueDil Compliance RAG Evaluation Suite.

Implements the full evaluation framework described in the design spec:

1. Weighted Cohen's Kappa (κ)
   - Compares AI verdict vs. human expert label
   - Ordinal penalty matrix: non_compliant↔compliant worst, partial↔either better
   - Applied ONLY to rows where human_label is set

2. Conditional Retrieval Metrics (RAGAS-style, manual implementation)
   Applied ONLY when evidence_type == document_required:
   - Context Recall    : did we retrieve chunks containing the relevant evidence?
   - Context Precision : are retrieved chunks ranked/relevant (ratio of useful chunks)?
   - Faithfulness      : is the AI reasoning grounded in retrieved content?
   - Context Entity Recall: did we retrieve key facts/entities from the evidence?
   Skipped for oral_implicit rows (no retrieval metrics make sense there).

3. Field-Level F1 (structured output)
   - Strict exact match on compliance label (hard pass/fail)
   - Field F1 across all output fields (compliance, justification_type, confidence tier)
   - Soft match using string similarity for evidence/reasoning quality

4. Summary Report
   - Per-row metrics
   - Aggregate metrics (macro-averaged)
   - Breakdown by evidence_type
   - Agreement heatmap (confusion matrix)

Output: writes a multi-sheet Excel report with:
  Sheet "Per Row"       → per-exigence metrics
  Sheet "Aggregate"     → summary statistics
  Sheet "Confusion"     → κ confusion matrix
  Sheet "Retrieval"     → retrieval metrics for document_required rows only
"""
import logging
from collections import defaultdict
from typing import Dict, List, Optional, Tuple

import openpyxl
import pandas as pd
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from config import COMPLIANCE_LABELS, KAPPA_WEIGHTS

logger = logging.getLogger(__name__)

# ─── Label Encoding ───────────────────────────────────────────────────────────

_LABEL_TO_IDX = {
    "compliant":           0,
    "partially_compliant": 1,
    "non_compliant":       2,
}
_IDX_TO_LABEL = {v: k for k, v in _LABEL_TO_IDX.items()}


def _label_idx(label: Optional[str]) -> Optional[int]:
    return _LABEL_TO_IDX.get(label)


# ─── 1. Weighted Cohen's Kappa ────────────────────────────────────────────────

def weighted_cohen_kappa(
    predictions: List[str],
    references:  List[str],
    weights:     List[List[int]] = KAPPA_WEIGHTS,
) -> Dict:
    """
    Compute weighted Cohen's κ between AI predictions and human reference labels.

    Args:
        predictions: List of AI compliance labels
        references:  List of human expert labels (must align with predictions)
        weights:     3×3 penalty matrix (0=agree, 1=adjacent, 2=opposite)

    Returns:
        {
          kappa        : float   (−1 to 1; >0.8 excellent, 0.6–0.8 good)
          agreement_pct: float   (raw % agreement)
          n_samples    : int
          confusion    : 3×3 list (true×pred counts)
        }
    """
    assert len(predictions) == len(references), "Lengths must match"
    n = len(predictions)
    if n == 0:
        return {"kappa": None, "agreement_pct": None, "n_samples": 0, "confusion": None}

    # Build confusion matrix
    confusion = [[0] * 3 for _ in range(3)]
    valid_pairs = 0
    for pred, ref in zip(predictions, references):
        pi = _label_idx(pred)
        ri = _label_idx(ref)
        if pi is not None and ri is not None:
            confusion[ri][pi] += 1
            valid_pairs += 1

    if valid_pairs == 0:
        return {"kappa": None, "agreement_pct": None, "n_samples": 0, "confusion": confusion}

    # Observed weighted disagreement
    Po_num = 0.0   # weighted agreement numerator
    for i in range(3):
        for j in range(3):
            Po_num += confusion[i][j] * (1.0 - weights[i][j] / 2.0)
    Po = Po_num / valid_pairs

    # Expected weighted agreement (from marginals)
    row_sums = [sum(confusion[i]) for i in range(3)]
    col_sums = [sum(confusion[i][j] for i in range(3)) for j in range(3)]
    Pe_num = 0.0
    for i in range(3):
        for j in range(3):
            Pe_num += row_sums[i] * col_sums[j] * (1.0 - weights[i][j] / 2.0)
    Pe = Pe_num / (valid_pairs ** 2)

    kappa = (Po - Pe) / (1.0 - Pe) if (1.0 - Pe) != 0 else 0.0

    # Raw agreement
    agree = sum(confusion[i][i] for i in range(3))
    agreement_pct = agree / valid_pairs

    return {
        "kappa":         round(kappa, 4),
        "agreement_pct": round(agreement_pct, 4),
        "n_samples":     valid_pairs,
        "confusion":     confusion,
    }


# ─── 2. Label F1 ──────────────────────────────────────────────────────────────

def label_f1(predictions: List[str], references: List[str]) -> Dict:
    """
    Compute per-class Precision, Recall, F1 and macro-averaged F1.

    Returns:
        {
          per_class: {"compliant": {p, r, f1}, "partially_compliant": ..., "non_compliant": ...}
          macro_f1 : float
          exact_match: float  (strict accuracy)
        }
    """
    from collections import Counter

    tp = Counter()
    fp = Counter()
    fn = Counter()

    exact = 0
    valid = 0

    for pred, ref in zip(predictions, references):
        pi = _label_idx(pred)
        ri = _label_idx(ref)
        if pi is None or ri is None:
            continue
        valid += 1
        if pi == ri:
            tp[pi] += 1
            exact  += 1
        else:
            fp[pi] += 1
            fn[ri] += 1

    per_class = {}
    f1_scores = []
    for idx, label in _IDX_TO_LABEL.items():
        p_val = tp[idx] / (tp[idx] + fp[idx]) if (tp[idx] + fp[idx]) > 0 else 0.0
        r_val = tp[idx] / (tp[idx] + fn[idx]) if (tp[idx] + fn[idx]) > 0 else 0.0
        f_val = 2 * p_val * r_val / (p_val + r_val) if (p_val + r_val) > 0 else 0.0
        per_class[label] = {"precision": round(p_val, 4), "recall": round(r_val, 4), "f1": round(f_val, 4)}
        f1_scores.append(f_val)

    return {
        "per_class":   per_class,
        "macro_f1":    round(sum(f1_scores) / len(f1_scores), 4) if f1_scores else 0.0,
        "exact_match": round(exact / valid, 4) if valid > 0 else 0.0,
        "n_valid":     valid,
    }


# ─── 3. Soft Match (string similarity) ────────────────────────────────────────

def _simple_token_overlap(a: str, b: str) -> float:
    """Token-level F1 between two strings (like SQuAD answer F1)."""
    a_toks = set(a.lower().split())
    b_toks = set(b.lower().split())
    if not a_toks or not b_toks:
        return 0.0
    common = a_toks & b_toks
    p = len(common) / len(a_toks)
    r = len(common) / len(b_toks)
    return 2 * p * r / (p + r) if (p + r) > 0 else 0.0


# ─── 4. Retrieval Metrics (RAGAS-style, document_required rows only) ──────────

def _compute_context_precision(retrieved_pages: List[Dict], expected_evidence: str) -> float:
    """
    Context Precision: fraction of retrieved chunks that are relevant to the evidence.
    A chunk is "relevant" if its text has >20% token overlap with the expected_evidence string.
    """
    if not retrieved_pages:
        return 0.0
    relevant = sum(
        1 for p in retrieved_pages
        if _simple_token_overlap(p.get("text", ""), expected_evidence) > 0.20
    )
    return round(relevant / len(retrieved_pages), 4)


def _compute_context_recall(retrieved_pages: List[Dict], expected_evidence: str) -> float:
    """
    Context Recall: coverage of expected evidence tokens across all retrieved chunks.
    Approximates "did we retrieve what we needed?"
    """
    if not expected_evidence.strip():
        return 1.0   # nothing to retrieve → trivially recalled
    retrieved_text = " ".join(p.get("text", "") for p in retrieved_pages)
    return round(_simple_token_overlap(retrieved_text, expected_evidence), 4)


def _compute_faithfulness(reasoning: str, retrieved_pages: List[Dict]) -> float:
    """
    Faithfulness: how grounded is the AI reasoning in the retrieved text?
    Measures token overlap between the reasoning and the retrieved context.
    """
    if not retrieved_pages:
        return 0.0   # reasoning without context = not grounded
    context = " ".join(p.get("text", "") for p in retrieved_pages)
    return round(_simple_token_overlap(reasoning, context), 4)


def compute_retrieval_metrics(
    retrieved_pages:   List[Dict],
    ai_reasoning:      str,
    human_notes:       str,
    ai_evidence:       str,
) -> Dict:
    """
    Compute retrieval-quality metrics for a single document_required row.

    Uses human_notes as a proxy for "expected evidence ground truth".
    """
    context_precision = _compute_context_precision(retrieved_pages, human_notes or ai_evidence)
    context_recall    = _compute_context_recall(retrieved_pages,    human_notes or ai_evidence)
    faithfulness      = _compute_faithfulness(ai_reasoning, retrieved_pages)

    return {
        "context_precision": context_precision,
        "context_recall":    context_recall,
        "faithfulness":      faithfulness,
        "n_chunks_retrieved": len(retrieved_pages),
    }


# ─── 5. Per-Row Metrics ────────────────────────────────────────────────────────

def compute_per_row_metrics(results: List[Dict]) -> List[Dict]:
    """
    Compute per-row metrics for all results.

    Each result dict is expected to contain:
        exigence, verdict, evidence_type, human_label, human_notes,
        retrieved_pages (optional, for document_required rows)

    Returns a list of metric dicts (one per row).
    """
    rows = []
    for r in results:
        verdict       = r.get("verdict", {})
        ai_label      = verdict.get("compliance", "non_compliant")
        human_label   = r.get("human_label")
        evidence_type = r.get("evidence_type", "ambiguous")
        human_notes   = r.get("human_notes", "")
        retrieved     = r.get("retrieved_pages", [])
        reasoning     = verdict.get("reasoning", "")
        ai_evidence   = verdict.get("evidence", "")
        confidence    = verdict.get("confidence", 0.0)

        # ── Agreement with human ──────────────────────────────────────────
        if human_label:
            ai_idx  = _label_idx(ai_label)
            ref_idx = _label_idx(human_label)
            if ai_idx is not None and ref_idx is not None:
                weight_dist = KAPPA_WEIGHTS[ref_idx][ai_idx]
                exact_match = int(ai_idx == ref_idx)
            else:
                weight_dist = None
                exact_match = None
        else:
            weight_dist = None
            exact_match = None

        # ── Retrieval metrics (document_required only) ───────────────────
        if evidence_type == "document_required" and retrieved:
            ret_metrics = compute_retrieval_metrics(
                retrieved_pages=retrieved,
                ai_reasoning=reasoning,
                human_notes=human_notes,
                ai_evidence=ai_evidence,
            )
        else:
            ret_metrics = {
                "context_precision": None,
                "context_recall":    None,
                "faithfulness":      None,
                "n_chunks_retrieved": len(retrieved),
            }

        # ── Reasoning quality (soft match vs human notes) ────────────────
        if human_notes and reasoning:
            reasoning_soft = round(_simple_token_overlap(reasoning, human_notes), 4)
        else:
            reasoning_soft = None

        rows.append({
            "exigence":            r.get("exigence", ""),
            "evidence_type":       evidence_type,
            "rep_tag":             r.get("rep_tag", ""),
            "ai_label":            ai_label,
            "human_label":         human_label,
            "exact_match":         exact_match,
            "weight_distance":     weight_dist,
            "confidence":          confidence,
            "reasoning_soft_match": reasoning_soft,
            **ret_metrics,
        })
    return rows


# ─── 6. Aggregate Metrics ─────────────────────────────────────────────────────

def compute_aggregate_metrics(per_row: List[Dict]) -> Dict:
    """
    Compute aggregate metrics from per-row results.
    Separates document_required and oral_implicit rows.
    """
    labelled = [r for r in per_row if r.get("human_label")]
    doc_rows = [r for r in per_row if r.get("evidence_type") == "document_required"]
    oral_rows = [r for r in per_row if r.get("evidence_type") == "oral_implicit"]

    # ── Weighted Kappa (all labelled rows) ────────────────────────────────
    preds = [r["ai_label"] for r in labelled]
    refs  = [r["human_label"] for r in labelled]
    kappa_result = weighted_cohen_kappa(preds, refs)
    f1_result    = label_f1(preds, refs)

    # ── Retrieval metrics (document rows with valid metrics) ──────────────
    doc_labelled = [r for r in doc_rows if r.get("context_precision") is not None]
    def _mean(vals):
        vals = [v for v in vals if v is not None]
        return round(sum(vals) / len(vals), 4) if vals else None

    ret_agg = {
        "avg_context_precision": _mean([r["context_precision"] for r in doc_labelled]),
        "avg_context_recall":    _mean([r["context_recall"]    for r in doc_labelled]),
        "avg_faithfulness":      _mean([r["faithfulness"]      for r in doc_labelled]),
        "n_document_rows":       len(doc_rows),
    }

    # ── Oral rows: reasoning soft match ───────────────────────────────────
    oral_soft = _mean([r["reasoning_soft_match"] for r in oral_rows if r.get("reasoning_soft_match") is not None])

    # ── Breakdown by evidence type ────────────────────────────────────────
    by_type = defaultdict(list)
    for r in labelled:
        by_type[r["evidence_type"]].append(r)

    type_breakdown = {}
    for ev_type, ev_rows in by_type.items():
        ev_preds = [r["ai_label"] for r in ev_rows]
        ev_refs  = [r["human_label"] for r in ev_rows]
        type_breakdown[ev_type] = {
            "n": len(ev_rows),
            "exact_match": round(sum(r["exact_match"] or 0 for r in ev_rows) / len(ev_rows), 4),
            "kappa": weighted_cohen_kappa(ev_preds, ev_refs)["kappa"],
        }

    return {
        "kappa":            kappa_result,
        "label_f1":         f1_result,
        "retrieval":        ret_agg,
        "oral_reasoning_soft_match": oral_soft,
        "by_evidence_type": type_breakdown,
        "n_total":          len(per_row),
        "n_labelled":       len(labelled),
    }


# ─── 7. Evaluation Report (Excel) ────────────────────────────────────────────

def write_evaluation_report(output_path: str, results: List[Dict]) -> None:
    """
    Compute all metrics and write a multi-sheet Excel evaluation report.

    Sheets:
      "Per Row"    → per-exigence metrics table
      "Aggregate"  → summary KPIs
      "Confusion"  → 3×3 confusion matrix (AI vs Human)
      "Retrieval"  → retrieval metrics for document_required rows
    """
    per_row  = compute_per_row_metrics(results)
    agg      = compute_aggregate_metrics(per_row)

    wb = openpyxl.Workbook()

    _write_per_row_sheet(wb, per_row)
    _write_aggregate_sheet(wb, agg)
    _write_confusion_sheet(wb, agg["kappa"]["confusion"])
    _write_retrieval_sheet(wb, per_row)

    # Remove the default empty sheet
    if "Sheet" in wb.sheetnames:
        del wb["Sheet"]

    wb.save(output_path)
    logger.info(f"Evaluation report written to {output_path}")


# ─── Sheet Writers ────────────────────────────────────────────────────────────

_thin   = Side(style="thin", color="CCCCCC")
_border = Border(left=_thin, right=_thin, top=_thin, bottom=_thin)
_H_FONT = Font(name="Calibri", bold=True, size=10, color="FFFFFF")
_H_FILL = PatternFill("solid", start_color="2F4F7F")
_B_FONT = Font(name="Calibri", size=10)

_COMP_FILLS = {
    "compliant":           PatternFill("solid", start_color="C6EFCE"),
    "partially_compliant": PatternFill("solid", start_color="FFEB9C"),
    "non_compliant":       PatternFill("solid", start_color="FFC7CE"),
}


def _header_row(ws, row: int, labels: List[str]) -> None:
    for j, label in enumerate(labels, 1):
        c = ws.cell(row=row, column=j, value=label)
        c.font = _H_FONT
        c.fill = _H_FILL
        c.border = _border
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def _data_cell(ws, row: int, col: int, value, fill=None) -> None:
    c = ws.cell(row=row, column=col, value=value)
    c.font   = _B_FONT
    c.border = _border
    c.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)
    if fill:
        c.fill = fill


def _write_per_row_sheet(wb, per_row: List[Dict]) -> None:
    ws = wb.create_sheet("Per Row")
    headers = [
        "Exigence", "Type Preuve", "Tag Représentant", "Label IA",
        "Label Expert", "Match Exact", "Distance Pondérée", "Confiance IA",
        "Soft Match Raisonnement", "Context Precision", "Context Recall",
        "Faithfulness", "Chunks Récupérés",
    ]
    _header_row(ws, 1, headers)
    ws.column_dimensions["A"].width = 50
    for col_l, w in zip("BCDEFGHIJKLM", [22, 22, 22, 22, 14, 18, 12, 20, 18, 16, 14, 14]):
        ws.column_dimensions[col_l].width = w

    for i, r in enumerate(per_row, 2):
        ai_l = r.get("ai_label", "")
        fill = _COMP_FILLS.get(ai_l)
        _data_cell(ws, i, 1,  r.get("exigence", "")[:120])
        _data_cell(ws, i, 2,  r.get("evidence_type", ""))
        _data_cell(ws, i, 3,  r.get("rep_tag", ""))
        _data_cell(ws, i, 4,  ai_l,                        fill)
        _data_cell(ws, i, 5,  r.get("human_label", "—"))
        _data_cell(ws, i, 6,  "✅" if r.get("exact_match") == 1 else ("❌" if r.get("exact_match") == 0 else "—"))
        _data_cell(ws, i, 7,  r.get("weight_distance",     "—"))
        _data_cell(ws, i, 8,  f"{r.get('confidence', 0):.0%}")
        _data_cell(ws, i, 9,  _fmt_metric(r.get("reasoning_soft_match")))
        _data_cell(ws, i, 10, _fmt_metric(r.get("context_precision")))
        _data_cell(ws, i, 11, _fmt_metric(r.get("context_recall")))
        _data_cell(ws, i, 12, _fmt_metric(r.get("faithfulness")))
        _data_cell(ws, i, 13, r.get("n_chunks_retrieved", 0))


def _fmt_metric(v) -> str:
    if v is None:
        return "N/A"
    return f"{v:.2%}"


def _write_aggregate_sheet(wb, agg: Dict) -> None:
    ws = wb.create_sheet("Aggregate")
    ws.column_dimensions["A"].width = 45
    ws.column_dimensions["B"].width = 20

    rows = [
        ["=== ACCORD IA vs EXPERT ===", ""],
        ["κ pondéré (tout)", agg["kappa"].get("kappa", "N/A")],
        ["% accord exact", f"{agg['kappa'].get('agreement_pct', 0):.1%}" if agg["kappa"].get("agreement_pct") else "N/A"],
        ["N échantillons étiquetés", agg["kappa"].get("n_samples", 0)],
        ["", ""],
        ["=== LABEL F1 ===", ""],
        ["Macro F1", agg["label_f1"].get("macro_f1", "N/A")],
        ["Exact Match", f"{agg['label_f1'].get('exact_match', 0):.1%}"],
        ["F1 compliant",           agg["label_f1"]["per_class"].get("compliant",           {}).get("f1", "N/A")],
        ["F1 partially_compliant", agg["label_f1"]["per_class"].get("partially_compliant", {}).get("f1", "N/A")],
        ["F1 non_compliant",       agg["label_f1"]["per_class"].get("non_compliant",       {}).get("f1", "N/A")],
        ["", ""],
        ["=== MÉTRIQUES RETRIEVAL (document_required) ===", ""],
        ["Avg Context Precision", _fmt_metric(agg["retrieval"].get("avg_context_precision"))],
        ["Avg Context Recall",    _fmt_metric(agg["retrieval"].get("avg_context_recall"))],
        ["Avg Faithfulness",      _fmt_metric(agg["retrieval"].get("avg_faithfulness"))],
        ["N lignes document",     agg["retrieval"].get("n_document_rows", 0)],
        ["", ""],
        ["=== MÉTRIQUES DÉCLARATIVES (oral_implicit) ===", ""],
        ["Avg Soft Match Raisonnement", _fmt_metric(agg.get("oral_reasoning_soft_match"))],
        ["", ""],
        ["=== PAR TYPE DE PREUVE ===", ""],
    ]

    for ev_type, ev_agg in agg.get("by_evidence_type", {}).items():
        rows.append([f"  {ev_type} — N", ev_agg.get("n", 0)])
        rows.append([f"  {ev_type} — Exact Match", f"{ev_agg.get('exact_match', 0):.1%}"])
        rows.append([f"  {ev_type} — κ", ev_agg.get("kappa", "N/A")])
        rows.append(["", ""])

    _H2_FILL = PatternFill("solid", start_color="1A3A5C")
    for i, (label, value) in enumerate(rows, 1):
        if label.startswith("==="):
            c = ws.cell(row=i, column=1, value=label)
            c.font = Font(name="Calibri", bold=True, size=11, color="FFFFFF")
            c.fill = _H2_FILL
            ws.cell(row=i, column=2, value="").fill = _H2_FILL
        else:
            ws.cell(row=i, column=1, value=label).font = _B_FONT
            ws.cell(row=i, column=2, value=value).font = Font(name="Calibri", bold=True, size=10)


def _write_confusion_sheet(wb, confusion) -> None:
    ws = wb.create_sheet("Confusion")
    if not confusion:
        ws.cell(row=1, column=1, value="Pas de données étiquetées")
        return

    labels = ["compliant", "partially_compliant", "non_compliant"]
    ws.cell(row=1, column=1, value="Vrai \\ Prédit →").font = Font(bold=True)

    # Header row
    for j, l in enumerate(labels, 2):
        c = ws.cell(row=1, column=j, value=l)
        c.font = _H_FONT
        c.fill = _H_FILL
        ws.column_dimensions[chr(ord("A") + j - 1)].width = 24

    for i, row_label in enumerate(labels):
        c = ws.cell(row=i + 2, column=1, value=row_label)
        c.font = Font(name="Calibri", bold=True, size=10)
        c.fill = _H_FILL
        c.font = _H_FONT
        for j, val in enumerate(confusion[i]):
            cell = ws.cell(row=i + 2, column=j + 2, value=val)
            cell.alignment = Alignment(horizontal="center")
            cell.border = _border
            if i == j:
                cell.fill = PatternFill("solid", start_color="C6EFCE")  # diagonal = agreement
            else:
                penalty = KAPPA_WEIGHTS[i][j]
                if penalty == 2:
                    cell.fill = PatternFill("solid", start_color="FFC7CE")
                else:
                    cell.fill = PatternFill("solid", start_color="FFEB9C")

    ws.column_dimensions["A"].width = 28


def _write_retrieval_sheet(wb, per_row: List[Dict]) -> None:
    ws = wb.create_sheet("Retrieval")
    doc_rows = [r for r in per_row if r.get("evidence_type") == "document_required"]
    if not doc_rows:
        ws.cell(row=1, column=1, value="Aucune ligne document_required.")
        return

    headers = ["Exigence", "Context Precision", "Context Recall", "Faithfulness", "Chunks", "Label IA", "Label Expert"]
    _header_row(ws, 1, headers)
    ws.column_dimensions["A"].width = 55
    for l, w in zip("BCDEFG", [20, 18, 16, 10, 18, 18]):
        ws.column_dimensions[l].width = w

    for i, r in enumerate(doc_rows, 2):
        _data_cell(ws, i, 1, r.get("exigence", "")[:100])
        _data_cell(ws, i, 2, _fmt_metric(r.get("context_precision")))
        _data_cell(ws, i, 3, _fmt_metric(r.get("context_recall")))
        _data_cell(ws, i, 4, _fmt_metric(r.get("faithfulness")))
        _data_cell(ws, i, 5, r.get("n_chunks_retrieved", 0))
        _data_cell(ws, i, 6, r.get("ai_label", ""),    _COMP_FILLS.get(r.get("ai_label", "")))
        _data_cell(ws, i, 7, r.get("human_label", "—"))
