"""
utils/excel_handler.py — Read compliance requirements and write AI verdicts
                          for the AI4DueDil due diligence pipeline.

Excel structure (sheet "Exigences"):
─────────────────────────────────────────────────────────────────────────────
  Filled by REPRESENTATIVE (input):
    A  #                    — Row number
    B  Exigence             — Compliance requirement text (RAG query)
    C  Tag                  — compliant | partially compliant | non compliant
    D  Commentaires         — Representative's free-text justification
    E  Preuves              — File names / references (often messy / empty)

  Filled by AI (output):
    F  Statut_IA            — compliant | partially_compliant | non_compliant
    G  Type_Justification   — document | oral | inferred
    H  Confiance_IA         — 0.0 – 1.0
    I  Evidence_IA          — What the AI found
    J  Raisonnement_IA      — Full AI reasoning (2-4 sentences)
    K  Fichiers_Sources     — Comma-separated list of cited files
    L  Type_Preuve_Attendue — document_required | oral_implicit | ambiguous (from Node 1)
    M  Verifie_par          — "AI RAG System"
    N  Date_Verification    — Today's date

  Human expert feedback (for evaluation — filled BEFORE running the AI):
    O  Feedback_Expert      — compliant | partially_compliant | non_compliant
    P  Notes_Expert         — Expert's free-text notes
─────────────────────────────────────────────────────────────────────────────
"""
import logging
from datetime import date
from typing import Dict, List, Optional

import openpyxl
import pandas as pd
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

logger = logging.getLogger(__name__)

# ─── Column indices (1-based) ─────────────────────────────────────────────────
# Input columns (representative)
COL_NUM           = 1   # A  #
COL_EXIGENCE      = 2   # B  Exigence
COL_TAG           = 3   # C  Tag (representative's label)
COL_COMMENTS      = 4   # D  Commentaires
COL_PROOFS        = 5   # E  Preuves (file refs)

# AI output columns
COL_AI_STATUS     = 6   # F  Statut_IA
COL_AI_JUST_TYPE  = 7   # G  Type_Justification
COL_AI_CONFIDENCE = 8   # H  Confiance_IA
COL_AI_EVIDENCE   = 9   # I  Evidence_IA
COL_AI_REASONING  = 10  # J  Raisonnement_IA
COL_AI_SOURCES    = 11  # K  Fichiers_Sources
COL_EVIDENCE_TYPE = 12  # L  Type_Preuve_Attendue
COL_VERIF_BY      = 13  # M  Verifie_par
COL_VERIF_DATE    = 14  # N  Date_Verification

# Human feedback columns (evaluation ground truth)
COL_HUMAN_LABEL   = 15  # O  Feedback_Expert
COL_HUMAN_NOTES   = 16  # P  Notes_Expert

TOTAL_COLS = 16

DATA_START_ROW = 3  # Excel row 3 (row 1 = title, row 2 = headers)

VERIFIER_LABEL = "AI RAG System"

# ─── Styles ───────────────────────────────────────────────────────────────────
_thin   = Side(style="thin", color="CCCCCC")
_border = Border(left=_thin, right=_thin, top=_thin, bottom=_thin)

_FILLS = {
    "compliant":           PatternFill("solid", start_color="C6EFCE"),   # green
    "partially_compliant": PatternFill("solid", start_color="FFEB9C"),   # yellow
    "non_compliant":       PatternFill("solid", start_color="FFC7CE"),   # red
    "neutral":             PatternFill("solid", start_color="F2F2F2"),   # grey
}
_FONTS = {
    "compliant":           Font(name="Calibri", bold=True, size=10, color="276221"),
    "partially_compliant": Font(name="Calibri", bold=True, size=10, color="9C6500"),
    "non_compliant":       Font(name="Calibri", bold=True, size=10, color="9C0006"),
    "neutral":             Font(name="Calibri", size=10, color="444444"),
}
_HEADER_FONT  = Font(name="Calibri", bold=True, size=10, color="FFFFFF")
_HEADER_FILL  = PatternFill("solid", start_color="2F4F7F")
_TITLE_FONT   = Font(name="Calibri", bold=True, size=13, color="FFFFFF")
_TITLE_FILL   = PatternFill("solid", start_color="1A3A5C")
_BODY_FONT    = Font(name="Calibri", size=10)

_HEADER_LABELS = [
    "#", "Exigence", "Tag Prestataire", "Commentaires", "Preuves (Réf.)",
    "Statut IA", "Type Justification", "Confiance IA", "Evidence IA",
    "Raisonnement IA", "Fichiers Sources", "Type Preuve Attendue",
    "Vérifié par", "Date Vérification",
    "Feedback Expert ✍", "Notes Expert",
]

_COL_WIDTHS = [5, 50, 22, 40, 35, 22, 22, 14, 45, 55, 40, 26, 18, 18, 22, 40]


def _status_fill(label: str) -> PatternFill:
    return _FILLS.get(label, _FILLS["neutral"])


def _status_font(label: str) -> Font:
    return _FONTS.get(label, _FONTS["neutral"])


# ─── Input parsing helpers ────────────────────────────────────────────────────

def _parse_proof_refs(raw: str) -> List[str]:
    """
    Parse a messy proof field into a clean list of file references.
    Representative may write: "cert_iso.pdf, voir dossier.pdf" or "N/A" or leave blank.
    """
    if not raw or str(raw).strip().lower() in ("nan", "n/a", "none", ""):
        return []
    # Split on comma, semicolon, or newline
    import re
    parts = re.split(r"[,;\n]+", str(raw))
    refs = []
    for p in parts:
        p = p.strip()
        if p and p.lower() not in ("n/a", "none", ""):
            refs.append(p)
    return refs


def _normalize_tag(tag: str) -> str:
    """Normalise the representative's free-text tag to a canonical label."""
    t = str(tag).lower().strip()
    if "non" in t:
        return "non_compliant"
    if "partial" in t or "partiel" in t:
        return "partially_compliant"
    if "oui" in t or "conforme" in t or "compliant" in t or "yes" in t:
        return "compliant"
    return "partially_compliant"   # safe default


def _normalize_expert(label: str) -> Optional[str]:
    """Normalise the expert's feedback label (returns None if empty)."""
    t = str(label).lower().strip()
    if t in ("nan", "n/a", "none", ""):
        return None
    if "non" in t:
        return "non_compliant"
    if "partial" in t or "partiel" in t:
        return "partially_compliant"
    if "conforme" in t or "compliant" in t or "oui" in t or "yes" in t:
        return "compliant"
    return None


# ─── Reading ──────────────────────────────────────────────────────────────────

def read_compliance_checklist(filepath: str) -> List[Dict]:
    """
    Read the AI4DueDil Excel file and return one dict per exigence row.

    Each dict:
        exigence      : str       — The compliance requirement
        rep_tag       : str       — Normalised representative tag
        rep_tag_raw   : str       — Raw tag as entered
        rep_comments  : str       — Representative's comments
        proof_refs    : List[str] — Parsed proof file references
        human_label   : Optional[str] — Expert's ground-truth label (for eval)
        human_notes   : str       — Expert's notes
        row_index     : int       — Original Excel row number (for write-back)
    """
    df = pd.read_excel(filepath, sheet_name=0, header=1)   # row 2 = headers (0-indexed: 1)

    rows = []
    for i, row in df.iterrows():
        exigence = str(row.get("Exigence", "")).strip()
        if not exigence or exigence.lower() == "nan":
            continue

        tag_raw  = str(row.get("Tag Prestataire",  "")).strip()
        comments = str(row.get("Commentaires",     "")).strip()
        proofs   = str(row.get("Preuves (Réf.)",   "")).strip()
        h_label  = str(row.get("Feedback Expert ✍","")).strip()
        h_notes  = str(row.get("Notes Expert",     "")).strip()

        rows.append({
            "exigence":     exigence,
            "rep_tag_raw":  tag_raw,
            "rep_tag":      _normalize_tag(tag_raw),
            "rep_comments": "" if comments.lower() == "nan" else comments,
            "proof_refs":   _parse_proof_refs(proofs),
            "human_label":  _normalize_expert(h_label),
            "human_notes":  "" if h_notes.lower() == "nan" else h_notes,
            "row_index":    int(i) + DATA_START_ROW,  # Excel row of this data row
        })

    logger.info(f"Read {len(rows)} exigence row(s) from {filepath}")
    return rows


# ─── Writing ──────────────────────────────────────────────────────────────────

def write_results(input_path: str, output_path: str, results: List[Dict]) -> None:
    """
    Write AI verdicts back into the Excel file.

    Fills columns F–N for each data row.
    Columns O–P (human feedback) are intentionally never overwritten.

    Args:
        input_path : Source Excel (template with representative input + human feedback)
        output_path: Output path for the enriched copy
        results    : List of dicts: {exigence, row_index, verdict, evidence_type}
    """
    wb = openpyxl.load_workbook(input_path)
    ws = wb.active
    today = date.today().strftime("%d/%m/%Y")

    for result in results:
        excel_row = result["row_index"]
        verdict   = result.get("verdict", {})
        ev_type   = result.get("evidence_type", "ambiguous")

        compliance   = verdict.get("compliance",         "non_compliant")
        just_type    = verdict.get("justification_type", "inferred")
        confidence   = verdict.get("confidence",         0.0)
        evidence     = verdict.get("evidence",           "")
        reasoning    = verdict.get("reasoning",          "")
        source_files = verdict.get("source_files",       [])

        # Format confidence as percentage string
        conf_str = f"{confidence:.0%}"
        sources_str = ", ".join(source_files) if source_files else "—"

        # Status label (human-readable)
        status_labels = {
            "compliant":           "✅ Conforme",
            "partially_compliant": "⚠️ Partiellement conforme",
            "non_compliant":       "❌ Non conforme",
        }
        status_str = status_labels.get(compliance, compliance)

        _wc(ws, excel_row, COL_AI_STATUS,     status_str,   compliance, wrap=False)
        _wc(ws, excel_row, COL_AI_JUST_TYPE,  just_type,    "neutral",  wrap=False)
        _wc(ws, excel_row, COL_AI_CONFIDENCE, conf_str,     compliance, wrap=False)
        _wc(ws, excel_row, COL_AI_EVIDENCE,   evidence,     "neutral",  wrap=True)
        _wc(ws, excel_row, COL_AI_REASONING,  reasoning,    "neutral",  wrap=True)
        _wc(ws, excel_row, COL_AI_SOURCES,    sources_str,  "neutral",  wrap=True)
        _wc(ws, excel_row, COL_EVIDENCE_TYPE, ev_type,      "neutral",  wrap=False)
        _wc(ws, excel_row, COL_VERIF_BY,      VERIFIER_LABEL, "neutral", wrap=False)
        _wc(ws, excel_row, COL_VERIF_DATE,    today,        "neutral",  wrap=False)

    wb.save(output_path)
    logger.info(f"AI results written to {output_path}")


def _wc(ws, row: int, col: int, value, label_for_style: str, wrap: bool = False) -> None:
    """Write a cell with conditional styling."""
    cell = ws.cell(row=row, column=col)
    cell.value = value
    if label_for_style in _FILLS:
        cell.fill = _status_fill(label_for_style)
        cell.font = _status_font(label_for_style) if col == COL_AI_STATUS else _BODY_FONT
    else:
        cell.fill = _FILLS["neutral"]
        cell.font = _BODY_FONT
    cell.border    = _border
    cell.alignment = Alignment(
        horizontal="left",
        vertical="top",
        wrap_text=wrap,
    )


# ─── Excel Template Creation ──────────────────────────────────────────────────

def create_input_template(output_path: str, sample_rows: Optional[List[Dict]] = None) -> None:
    """
    Create a blank (or pre-filled) AI4DueDil input Excel template.

    The template includes:
      - Styled title row
      - Column headers (A–P)
      - Correct column widths
      - Optional sample data rows (with representative input + expert feedback)

    Args:
        output_path  : Where to save the .xlsx
        sample_rows  : Optional list of dicts with pre-filled data for demo/testing
    """
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Exigences"

    # ── Title row ────────────────────────────────────────────────────────────
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=TOTAL_COLS)
    title_cell = ws.cell(row=1, column=1)
    title_cell.value = "AI4DueDil — Grille de Conformité Prestataires"
    title_cell.font  = _TITLE_FONT
    title_cell.fill  = _TITLE_FILL
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 30

    # ── Header row ───────────────────────────────────────────────────────────
    for col_idx, label in enumerate(_HEADER_LABELS, 1):
        cell = ws.cell(row=2, column=col_idx, value=label)
        cell.font      = _HEADER_FONT
        cell.fill      = _HEADER_FILL
        cell.border    = _border
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[2].height = 40

    # ── Column widths ────────────────────────────────────────────────────────
    col_letters = "ABCDEFGHIJKLMNOP"
    for i, w in enumerate(_COL_WIDTHS):
        ws.column_dimensions[col_letters[i]].width = w

    # ── Freeze panes (keep header visible) ───────────────────────────────────
    ws.freeze_panes = "B3"

    # ── Sample data rows ──────────────────────────────────────────────────────
    if sample_rows:
        for row_num, data in enumerate(sample_rows, DATA_START_ROW):
            ws.row_dimensions[row_num].height = 60
            _write_input_row(ws, row_num, row_num - DATA_START_ROW + 1, data)

    wb.save(output_path)
    logger.info(f"Input template created: {output_path}")


def _write_input_row(ws, excel_row: int, row_num: int, data: Dict) -> None:
    """Write one sample data row into the template."""
    fields = [
        (COL_NUM,        row_num,                           False),
        (COL_EXIGENCE,   data.get("exigence",    ""),       True),
        (COL_TAG,        data.get("rep_tag_raw", ""),       False),
        (COL_COMMENTS,   data.get("rep_comments",""),       True),
        (COL_PROOFS,     data.get("proof_refs_str",""),     True),
        (COL_HUMAN_LABEL,data.get("human_label_raw", ""),  False),
        (COL_HUMAN_NOTES,data.get("human_notes",    ""),   True),
    ]
    for col, value, wrap in fields:
        cell = ws.cell(row=excel_row, column=col, value=value)
        cell.font      = _BODY_FONT
        cell.border    = _border
        cell.alignment = Alignment(horizontal="left", vertical="top", wrap_text=wrap)

    # Highlight human feedback columns differently (light blue)
    _HF_FILL = PatternFill("solid", start_color="DDEEFF")
    for col in (COL_HUMAN_LABEL, COL_HUMAN_NOTES):
        ws.cell(row=excel_row, column=col).fill = _HF_FILL
