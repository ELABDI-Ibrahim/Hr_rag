"""
generate_sample_excel.py — Create dildil_input.xlsx with realistic sample data.

Columns:
  A: #   B: Exigence   C: Tag Prestataire   D: Commentaires   E: Preuves (Réf.)
  F-N: AI output (empty)
  O: Feedback Expert ✍   P: Notes Expert
"""
import sys
sys.path.insert(0, "/home/claude/dildil_rag_system")

from utils.excel_handler import create_input_template

# Realistic AI4DueDil compliance rows (prestataire = tech subcontractor for AXA)
# Each row represents one requirement in the due diligence grid
SAMPLE_ROWS = [
    # ── DOCUMENT REQUIRED rows ─────────────────────────────────────────────
    {
        "exigence":    "Le prestataire dispose d'une certification ISO 27001 en cours de validité couvrant les activités concernées par la prestation.",
        "rep_tag_raw": "Compliant",
        "rep_comments":"Notre certification ISO 27001 a été renouvelée en janvier 2025. Elle couvre l'ensemble de nos activités d'hébergement et de traitement de données.",
        "proof_refs_str": "certificat_iso27001_2025.pdf",
        "human_label_raw": "Compliant",
        "human_notes":  "Certificat ISO 27001 valide jusqu'au 15/01/2026, émis par Bureau Veritas. Périmètre couvre bien les activités de la prestation.",
    },
    {
        "exigence":    "Le prestataire justifie d'une assurance responsabilité civile professionnelle (RCP) souscrite auprès d'un assureur reconnu, avec un plafond de garantie ≥ 2M€.",
        "rep_tag_raw": "Partially Compliant",
        "rep_comments":"Nous avons une RCP avec AXA, plafond 1,5M€. Le renouvellement avec rehaussement à 2M€ est en cours pour avril 2025.",
        "proof_refs_str": "attestation_rcp_2024.pdf, voir dossier_administratif_complet.pdf",
        "human_label_raw": "Partially Compliant",
        "human_notes":  "Attestation RCP fournie mais plafond de 1,5M€ inférieur à l'exigence de 2M€. Engagement de rehaussement sans preuve formelle.",
    },
    {
        "exigence":    "Le prestataire a signé et transmis la Charte de Sécurité Informatique AXA dans sa version en vigueur (v3.2 ou ultérieure).",
        "rep_tag_raw": "Compliant",
        "rep_comments":"La charte a été signée par notre RSSI le 03/03/2025.",
        "proof_refs_str": "charte_ssi_axa_signee.pdf",
        "human_label_raw": "Non Compliant",
        "human_notes":  "Document fourni est la v3.0 (2022). La version en vigueur est la v3.2 (2024). Le prestataire n'a pas la bonne version.",
    },
    {
        "exigence":    "Le prestataire a réalisé un audit de sécurité (pentest ou audit organisationnel) par un tiers indépendant dans les 24 derniers mois.",
        "rep_tag_raw": "Compliant",
        "rep_comments":"Pentest réalisé par Wavestone en septembre 2024. Rapport disponible sous NDA.",
        "proof_refs_str": "rapport_pentest_wavestone_2024.pdf",
        "human_label_raw": "Compliant",
        "human_notes":  "Rapport de pentest Wavestone reçu (sept. 2024). Résultats : 2 vulnérabilités critiques corrigées, 4 moyennes en cours. Plan de remédiation inclus.",
    },
    {
        "exigence":    "Le prestataire a nommé un Délégué à la Protection des Données (DPO) et transmis ses coordonnées.",
        "rep_tag_raw": "Compliant",
        "rep_comments":"Notre DPO est Mme Dupont, joignable à dpo@prestataire.com.",
        "proof_refs_str": "",
        "human_label_raw": "Partially Compliant",
        "human_notes":  "Coordonnées DPO fournies verbalement mais aucun document de nomination (CNIL) transmis. La désignation doit être prouvée.",
    },
    {
        "exigence":    "Le prestataire dispose d'un Plan de Continuité d'Activité (PCA) documenté, testé et validé dans les 12 derniers mois.",
        "rep_tag_raw": "Partially Compliant",
        "rep_comments":"Notre PCA date de 2022 et n'a pas encore été retesté formellement. Un test est prévu en juin 2025.",
        "proof_refs_str": "pca_v2_2022.pdf",
        "human_label_raw": "Non Compliant",
        "human_notes":  "PCA de 2022 fourni mais pas testé depuis > 12 mois. L'exigence est claire sur la validation annuelle. Non conforme.",
    },
    {
        "exigence":    "Le prestataire a fourni la liste exhaustive de ses sous-traitants critiques intervenant dans le cadre de la prestation avec AXA.",
        "rep_tag_raw": "Compliant",
        "rep_comments":"La liste est jointe. Nous faisons appel à AWS (hébergement) et Datadog (monitoring).",
        "proof_refs_str": "liste_sous_traitants.pdf, dossier_administratif_complet.pdf",
        "human_label_raw": "Compliant",
        "human_notes":  "Liste des sous-traitants fournie et conforme. AWS et Datadog identifiés. Clauses de flux vers pays tiers à vérifier séparément.",
    },
    # ── ORAL / IMPLICIT rows ────────────────────────────────────────────────
    {
        "exigence":    "Le prestataire s'engage contractuellement à notifier AXA de tout incident de sécurité significatif dans un délai de 72 heures.",
        "rep_tag_raw": "Compliant",
        "rep_comments":"Nous respectons l'obligation RGPD de notification à 72h. Notre processus interne de gestion des incidents prévoit cette notification.",
        "proof_refs_str": "",
        "human_label_raw": "Partially Compliant",
        "human_notes":  "Engagement verbal cohérent mais l'obligation contractuelle doit figurer dans le contrat de prestation. Non vérifié dans les documents fournis.",
    },
    {
        "exigence":    "Les collaborateurs du prestataire intervenant sur le périmètre AXA ont reçu une sensibilisation à la cybersécurité dans les 12 derniers mois.",
        "rep_tag_raw": "Compliant",
        "rep_comments":"Tous nos collaborateurs suivent une formation en ligne obligatoire sur la cybersécurité chaque année. La dernière session remonte à octobre 2024.",
        "proof_refs_str": "attestation_formation_cyber_2024.pdf",
        "human_label_raw": "Compliant",
        "human_notes":  "Attestation collective de formation fournie (oct. 2024, 45 collaborateurs). Contenu de la formation validé : phishing, mots de passe, RGPD basics.",
    },
    {
        "exigence":    "Le prestataire ne sous-traite aucune partie de la prestation à un tiers sans accord préalable écrit d'AXA.",
        "rep_tag_raw": "Compliant",
        "rep_comments":"Nous ne sous-traitons pas la prestation directe. Les sous-traitants listés (AWS, Datadog) sont des outils d'infrastructure et non de sous-traitance fonctionnelle.",
        "proof_refs_str": "",
        "human_label_raw": "Compliant",
        "human_notes":  "Déclaration cohérente avec la liste de sous-traitants fournie. AWS/Datadog sont bien des outils infra. Aucune délégation fonctionnelle détectée.",
    },
    {
        "exigence":    "Le prestataire justifie d'une expérience d'au moins 3 ans dans des missions similaires auprès de clients du secteur financier ou assurantiel.",
        "rep_tag_raw": "Compliant",
        "rep_comments":"Nous intervenons depuis 2018 pour des grands groupes financiers (Société Générale, BNP Paribas). Références disponibles sur demande.",
        "proof_refs_str": "attestation_client_sg.pdf, lettre_recommandation.pdf",
        "human_label_raw": "Compliant",
        "human_notes":  "Lettres de référence Société Générale (2021-2024) et BNP Paribas (2022-2024) fournies. Expérience sectorielle confirmée.",
    },
    {
        "exigence":    "Les accès aux systèmes et données d'AXA sont protégés par une authentification multi-facteurs (MFA) pour tous les utilisateurs du prestataire.",
        "rep_tag_raw": "Partially Compliant",
        "rep_comments":"Le MFA est activé pour tous nos accès VPN. Pour les accès directs aux outils AXA, nous utilisons les accès fournis par AXA (SSO AXA).",
        "proof_refs_str": "screenshot_mfa_vpn.pdf",
        "human_label_raw": "Partially Compliant",
        "human_notes":  "MFA VPN confirmé (capture écran). SSO AXA géré côté AXA donc hors scope. Mais accès à certains portails partenaires non couverts par MFA.",
    },
    {
        "exigence":    "Le prestataire a accepté et signé les clauses contractuelles standard d'AXA relatives à la protection des données (clauses RGPD + clauses SSI).",
        "rep_tag_raw": "Non Compliant",
        "rep_comments":"Nous n'avons pas encore reçu les clauses contractuelles AXA. Nous attendons le document depuis 3 semaines.",
        "proof_refs_str": "",
        "human_label_raw": "Non Compliant",
        "human_notes":  "Confirmé : les clauses n'ont pas été transmises au prestataire. Blocage côté équipe juridique AXA. Action requise côté AXA.",
    },
    {
        "exigence":    "Le prestataire dispose d'une politique de gestion des vulnérabilités documentée avec des SLA de correction (critique ≤ 48h, haute ≤ 7j).",
        "rep_tag_raw": "Compliant",
        "rep_comments":"Notre politique de gestion des vulnérabilités est documentée dans notre SMSI. SLA : critique 24h, haute 5j, moyenne 30j.",
        "proof_refs_str": "politique_gestion_vuln.pdf, extrait_smsi.pdf",
        "human_label_raw": "Compliant",
        "human_notes":  "Politique fournie et conforme. SLA critique 24h (plus strict qu'exigé). Preuve de suivi via outil Jira Security visible dans le document.",
    },
    {
        "exigence":    "Le prestataire garantit que les données traitées pour le compte d'AXA ne transitent pas hors de l'Espace Économique Européen (EEE) sans mécanisme de transfert conforme au RGPD.",
        "rep_tag_raw": "Compliant",
        "rep_comments":"Toutes nos données sont hébergées sur des serveurs AWS situés en région eu-west-1 (Irlande) et eu-central-1 (Francfort).",
        "proof_refs_str": "architecture_hebergement.pdf",
        "human_label_raw": "Partially Compliant",
        "human_notes":  "Hébergement EEE confirmé pour AWS. Cependant Datadog (monitoring) a des serveurs aux USA. Absence de SCC (clauses contractuelles types) documentée pour ce flux.",
    },
]

create_input_template(
    output_path="/home/claude/dildil_rag_system/dildil_input.xlsx",
    sample_rows=SAMPLE_ROWS,
)
print("✅ Sample Excel created: /home/claude/dildil_rag_system/dildil_input.xlsx")
