# AI4DueDil — Compliance RAG Strategy Lab

Automated compliance verification for AXA France's prestataire due diligence process.
Built as an **experiment lab**: multiple interchangeable RAG strategies share a fixed
input/output contract so you can compare approaches objectively.

---

## Quick start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Configure
cp .env.example .env
# → edit .env and set GROQ_API_KEY

# 3. Create or fill in the input Excel
python generate_sample_excel.py    # creates dildil_input.xlsx with 15 demo rows

# 4. Add your proof documents to proof/
# (PDF and Markdown supported — merged files, 80-page blobs, all handled)

# 5. Run a strategy
python runner.py --strategy naive_rag      # baseline
python runner.py --strategy bm25_hybrid    # full pipeline
python runner.py --strategy reranker       # cross-encoder reranking
python runner.py --strategy hyde           # hypothetical document embeddings

# 6. Run all and compare
python runner.py --all
python runner.py --compare naive_rag bm25_hybrid reranker hyde

# 7. List available strategies
python runner.py --list

# 8. Explore MLflow traces
mlflow ui --backend-store-uri sqlite:///mlflow.db
```

Outputs land in `results/`:
```
results/
  naive_rag_results.xlsx       ← AI verdicts written back to Excel
  naive_rag_eval.xlsx          ← evaluation report (kappa, F1, retrieval metrics)
  bm25_hybrid_results.xlsx
  bm25_hybrid_eval.xlsx
  ...
  comparison_report.xlsx       ← side-by-side when 2+ strategies run
```

---

## Repository layout

```
dildil_rag_system/
│
├── runner.py                       ← unified CLI entry point
├── config.py                       ← all config, loaded from .env
├── generate_sample_excel.py        ← creates sample input Excel
├── requirements.txt
├── .env.example
│
├── strategies/                     ← RAG experiment lab
│   ├── base.py                     ← BaseStrategy + StrategyResult (the contract)
│   ├── registry.py                 ← auto-discovery (no manual registration)
│   │
│   ├── naive_rag/strategy.py       ← baseline: embed all → similarity search
│   ├── bm25_hybrid/strategy.py     ← full pipeline: evidence mining + BM25 + semantic
│   ├── reranker/strategy.py        ← BM25 broad recall + cross-encoder reranking
│   ├── hyde/strategy.py            ← hypothetical document embeddings
│   └── TEMPLATE/strategy.py        ← copy this to add a new strategy
│
├── pipeline/                       ← shared components (used by bm25_hybrid)
│   ├── graph.py                    ← LangGraph 6-node pipeline
│   ├── verdict.py                  ← LLM verdict chains + evidence classification
│   ├── retrieval.py                ← BM25 triage + ChromaDB semantic search
│   └── ingestion.py                ← PDF (PyMuPDF + OCR fallback) + Markdown loading
│
├── utils/
│   ├── excel_handler.py            ← read input / write AI verdicts
│   ├── evaluation.py               ← full evaluation suite (kappa, F1, retrieval)
│   └── strategy_compare.py         ← multi-strategy comparison report
│
└── proof/                          ← prestataire's proof documents (PDF / MD)
```

---

## The strategy plugin contract

Every strategy is one file: `strategies/<name>/strategy.py`.

```python
from strategies.base import BaseStrategy, StrategyResult

class MyStrategy(BaseStrategy):
    NAME        = "my_strategy"   # unique slug, used as CLI arg
    DESCRIPTION = "One line."

    def run(self, checklist, file_corpus) -> List[StrategyResult]:
        results = []
        for row in checklist:
            # ... your retrieval + verdict logic ...
            results.append(StrategyResult(
                exigence        = row["exigence"],
                row_index       = row["row_index"],
                rep_tag         = row["rep_tag"],
                human_label     = row.get("human_label"),
                human_notes     = row.get("human_notes", ""),
                verdict         = { ... },          # see schema below
                evidence_type   = "ambiguous",
                retrieved_pages = [...],
            ))
        return results
```

`StrategyResult.verdict` dict — all keys required:

```python
{
    "compliance":         "compliant" | "partially_compliant" | "non_compliant",
    "justification_type": "document" | "oral" | "inferred",
    "evidence":           str,    # what was found / what supports the label
    "confidence":         float,  # 0.0 to 1.0
    "reasoning":          str,    # 2-4 sentences in French
    "source_files":       List[str],
}
```

The runner, evaluator, and comparison report only ever touch `StrategyResult`.
They never import strategy internals.

### Adding a new strategy (3 steps)

```bash
# 1. Copy the template
cp -r strategies/TEMPLATE strategies/my_strategy

# 2. Edit strategies/my_strategy/strategy.py
#    — set NAME = "my_strategy"
#    — implement run()

# 3. Run it — no other file needs editing
python runner.py --strategy my_strategy
python runner.py --compare naive_rag my_strategy
```

---

## Strategies

### `naive_rag` — baseline

The simplest possible RAG. Embed everything, retrieve by cosine similarity, call the LLM.

```
setup()  → embed ALL proof pages into ChromaDB (content-hash dedup)
run()    → similarity_search(exigence, top_k=4)  ← no pre-filter
         → LLM verdict on top-4 pages
```

**When it wins:** Exigences semantically close to how the proof is written.  
**When it fails:** Lexical gap between the requirement and the document wording.
Long merged PDFs where the relevant page doesn't rank in top-4.

---

### `bm25_hybrid` — full pipeline

The production system. LangGraph with conditional routing based on evidence type.

```
Node 1: evidence_mining      → document_required / oral_implicit / ambiguous
Node 2: keyword_suggestion   → 20-30 French BM25 keywords via LLM
Node 3: bm25_triage          → score all pages, shortlist top-10
Node 4: semantic_search      → ChromaDB restricted to BM25 candidates, top-4
Node 5a: document_verdict    → LLM verdict with retrieved context
Node 5b: oral_verdict        → LLM verdict on rep's declaration only (no retrieval)
```

**When it wins:** Oral requirements (skips meaningless retrieval). Documents that
use different terminology than the exigence (keyword expansion bridges the gap).  
**When it fails:** Over-filtering — if BM25 misses the relevant page in its top-10,
semantic search never sees it. Slowest strategy (+2 LLM calls per row).

---

### `reranker` — BM25 + cross-encoder

Two-stage retrieval. BM25 for high recall, cross-encoder for high precision.

```
Stage 1: BM25 broad recall     → top-20 candidate pages
Stage 2: cross-encoder rerank  → score each (exigence, page) pair jointly
                                  keep top-4
Stage 3: LLM verdict           → same chain as other strategies
```

Model: `cross-encoder/ms-marco-MiniLM-L-6-v2` (local, ~50ms per 20 pairs)

Cross-encoders read query and document together — they catch paraphrase, negation,
and nuanced relevance that cosine similarity misses because bi-encoders encode
each side independently.

**When it wins:** When the relevant proof page uses different wording from the exigence
but a cross-encoder can infer relevance from joint context. No vector DB needed.  
**When it fails:** Slower than naive_rag. No evidence type routing so oral exigences
go through full retrieval.

---

### `hyde` — hypothetical document embeddings

Reference: Gao et al., "Precise Zero-Shot Dense Retrieval without Relevance Labels" (2022)

```
Step 1: LLM generates a hypothetical proof document for this exigence
        e.g. "CERTIFICAT ISO/IEC 27001 — TECHSOL GROUP SAS — valide 2025-01…"
Step 2: Embed the HYPOTHESIS (not the exigence text)
Step 3: Similarity search with the hypothesis embedding vector
Step 4: LLM verdict on the REAL retrieved pages
```

Bi-encoder models are trained on (document, document) pairs. Embedding a natural-language
requirement creates a query vector in a different region of the space than actual
certificates or policies. A hypothetical proof document lives where real ones do —
so the similarity search is more precise.

**When it wins:** Requirements phrased as obligations ("the vendor must have…") that are
far from how the proof is written ("CERTIFICAT certifie que…"). HyDE bridges the gap.  
**When it fails:** +1 LLM call per row so ~2× slower than naive_rag. If the LLM
hallucinates an off-target hypothesis, retrieval degrades gracefully to naive_rag behaviour
(fallback: embed the raw exigence).

---

## Excel schema

### Input (filled by representative before running)

| Col | Name | Description |
|---|---|---|
| A | # | Row number |
| B | **Exigence** | Compliance requirement text |
| C | **Tag Prestataire** | `compliant` / `partially compliant` / `non compliant` |
| D | **Commentaires** | Free-text justification |
| E | **Preuves (Réf.)** | File names / references — often messy, partial, or empty |

### AI output (written by `runner.py`)

| Col | Name | Description |
|---|---|---|
| F | Statut IA | ✅ Conforme / ⚠️ Partiellement / ❌ Non conforme |
| G | Type Justification | `document` / `oral` / `inferred` |
| H | Confiance IA | 0–100% |
| I | Evidence IA | What the AI found |
| J | Raisonnement IA | Full reasoning in French |
| K | Fichiers Sources | Comma-separated list of cited files |
| L | Type Preuve Attendue | `document_required` / `oral_implicit` / `ambiguous` |
| M | Vérifié par | "AI RAG System" |
| N | Date Vérification | Today's date |

### Human expert feedback — **fill this before running to get evaluation**

| Col | Name | Description |
|---|---|---|
| O | **Feedback Expert ✍** | Your ground-truth label |
| P | **Notes Expert** | Your reasoning — used for soft-match evaluation |

> Columns O and P are never overwritten by the pipeline.

---

## Evaluation

### When it runs
Evaluation is automatic for any row with a human label (column O filled).
The output is `results/{strategy}_eval.xlsx`.
Running 2+ strategies also produces `results/comparison_report.xlsx`.

### Metrics

**Weighted Cohen's κ** — AI vs. human agreement with ordinal penalties.
```
True \ Pred   | compliant | partially | non_compliant
compliant     |     0     |     1     |       2
partially     |     1     |     0     |       1
non_compliant |     2     |     1     |       0
```
`compliant ↔ non_compliant` penalised 2× harder than adjacent errors.
κ > 0.8 = excellent, 0.6–0.8 = good, 0.4–0.6 = moderate, < 0.4 = poor.

**Label F1** — per-class precision/recall/F1, macro-averaged.

**Retrieval metrics** (only for `document_required` rows):
- Context Precision — fraction of retrieved chunks relevant to the expected evidence
- Context Recall — coverage of expected evidence in the retrieved chunks
- Faithfulness — how grounded the AI reasoning is in the retrieved context

Retrieval metrics are skipped for `oral_implicit` rows (retrieval doesn't apply).

**Reasoning soft match** — token-overlap between AI reasoning and expert notes
(used for oral rows where experts wrote detailed notes).

### Comparison report sheets

| Sheet | Content |
|---|---|
| Overview | All strategies × all KPIs, best value per row highlighted |
| Per Row | Each exigence × strategy: label, exact match, confidence |
| κ Ranking | Strategies ranked by weighted κ |
| Retrieval | Context precision/recall/faithfulness per strategy per exigence |
| Latency | Avg / median / min / max per strategy |
| Confusion | All confusion matrices side by side |

---

## ChromaDB collections

Each strategy uses its own collection so their indexes never collide:

| Strategy | Collection |
|---|---|
| `naive_rag` | `naive_rag_pages` |
| `bm25_hybrid` | `dildil_pages` (from config) |
| `hyde` | `hyde_pages` |
| `reranker` | no vector DB |

---

## Strategy comparison at a glance

| Strategy | Retrieval | Extra LLM calls | Vector DB | Evidence routing |
|---|---|---|---|---|
| `naive_rag` | embed all → cosine top-4 | 0 | yes | no |
| `bm25_hybrid` | BM25 top-10 → semantic top-4 | +keywords +evidence | yes | yes (oral path) |
| `reranker` | BM25 top-20 → cross-encoder top-4 | 0 | no | no |
| `hyde` | hypothesis → embed → cosine top-4 | +1 per row | yes | no |

**Recommended experiment order:**
1. `naive_rag` — fast baseline, run first
2. `bm25_hybrid` — adds evidence routing and keyword expansion
3. `reranker` — tests whether cross-encoder precision beats bi-encoder cosine
4. `hyde` — tests whether the semantic gap hypothesis holds for your proof folder

The comparison report ranks them by κ automatically.
