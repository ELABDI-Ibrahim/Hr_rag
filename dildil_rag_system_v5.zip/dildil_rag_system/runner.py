"""
runner.py — Unified strategy runner for AI4DueDil.

Usage:
    python runner.py --strategy naive_rag
    python runner.py --strategy bm25_hybrid
    python runner.py --all
    python runner.py --compare naive_rag bm25_hybrid
    python runner.py --list

What it does:
  1. Loads proof corpus and Excel checklist (once)
  2. Resolves the requested strategy(ies) from the registry
  3. Calls strategy.execute(checklist, corpus)
  4. Writes per-strategy results to results/{strategy}_results.xlsx
  5. Runs evaluation → results/{strategy}_eval.xlsx
  6. If --compare (or --all): writes results/comparison_report.xlsx

Output structure:
    results/
        naive_rag_results.xlsx
        naive_rag_eval.xlsx
        bm25_hybrid_results.xlsx
        bm25_hybrid_eval.xlsx
        comparison_report.xlsx   ← only when 2+ strategies run
"""
import argparse
import json
import logging
import sys
from pathlib import Path

import mlflow

from config import (
    EVAL_OUTPUT,
    EXCEL_INPUT,
    MLFLOW_EXPERIMENT_NAME,
    MLFLOW_TRACKING_URI,
    PROOF_FOLDER,
    validate_config,
)
from pipeline.ingestion import load_proof_folder
from strategies.registry import all_strategy_names, get_strategy, list_strategies
from utils.evaluation import write_evaluation_report
from utils.excel_handler import read_compliance_checklist, write_results
from utils.strategy_compare import write_comparison_report

# ─── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  [%(levelname)-8s]  %(name)s — %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)

RESULTS_DIR = Path("results")


def _setup_mlflow() -> None:
    mlflow.set_tracking_uri(MLFLOW_TRACKING_URI or "sqlite:///mlflow.db")
    mlflow.set_experiment(MLFLOW_EXPERIMENT_NAME)
    try:
        mlflow.langchain.autolog()
    except Exception:
        pass


def _run_strategy(
    strategy_name: str,
    checklist: list,
    file_corpus: list,
) -> list:
    """Run a single strategy and return its results as a list of dicts."""
    logger.info(f"\n{'─' * 60}")
    logger.info(f"  Strategy: {strategy_name.upper()}")
    logger.info(f"{'─' * 60}")

    strategy = get_strategy(strategy_name)

    with mlflow.start_run(run_name=f"strategy:{strategy_name}"):
        mlflow.set_tag("strategy", strategy_name)
        results = strategy.execute(checklist, file_corpus)

    return [r.to_dict() for r in results]


def _write_strategy_outputs(
    strategy_name: str,
    results: list,
    checklist: list,
) -> None:
    """Write results and evaluation Excel files for one strategy."""
    RESULTS_DIR.mkdir(exist_ok=True)

    # Results Excel (AI verdicts)
    results_path = str(RESULTS_DIR / f"{strategy_name}_results.xlsx")
    write_results(EXCEL_INPUT, results_path, results)
    logger.info(f"Results written → {results_path}")

    # Evaluation Excel
    eval_path = str(RESULTS_DIR / f"{strategy_name}_eval.xlsx")
    labelled  = [r for r in results if r.get("human_label")]
    if labelled:
        write_evaluation_report(eval_path, results)
        logger.info(f"Evaluation written → {eval_path}")
    else:
        logger.info(
            f"No human labels found — skipping eval for {strategy_name}. "
            f"Fill column O (Feedback Expert ✍) in {EXCEL_INPUT} to enable."
        )


def _print_summary(strategy_name: str, results: list) -> None:
    """Print a quick summary table to stdout."""
    from collections import Counter
    counts = Counter(r["verdict"].get("compliance", "?") for r in results)
    ev_counts = Counter(r.get("evidence_type", "?") for r in results)
    avg_lat = sum(r.get("latency_ms", 0) for r in results) / max(len(results), 1)

    logger.info(f"\n  [{strategy_name}] Summary:")
    logger.info(f"    ✅ Conforme            : {counts.get('compliant', 0)}")
    logger.info(f"    ⚠️  Partiellement conf. : {counts.get('partially_compliant', 0)}")
    logger.info(f"    ❌ Non conforme        : {counts.get('non_compliant', 0)}")
    logger.info(f"    📄 Document requis     : {ev_counts.get('document_required', 0)}")
    logger.info(f"    🗣️  Déclaratif          : {ev_counts.get('oral_implicit', 0)}")
    logger.info(f"    ❓ Ambigu              : {ev_counts.get('ambiguous', 0)}")
    logger.info(f"    ⏱  Latence moy.        : {avg_lat:.0f} ms/exigence")


# ─── CLI ──────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="AI4DueDil Strategy Runner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python runner.py --list
  python runner.py --strategy naive_rag
  python runner.py --strategy bm25_hybrid
  python runner.py --all
  python runner.py --compare naive_rag bm25_hybrid
        """,
    )

    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--strategy",  metavar="NAME",  help="Run a single strategy by name")
    mode.add_argument("--all",       action="store_true", help="Run all registered strategies")
    mode.add_argument("--compare",   nargs="+", metavar="NAME", help="Run & compare specific strategies")
    mode.add_argument("--list",      action="store_true", help="List all available strategies")

    args = parser.parse_args()

    # ── List ──────────────────────────────────────────────────────────────────
    if args.list:
        strategies = list_strategies()
        print("\nAvailable strategies:")
        for s in strategies:
            print(f"  {s['name']:<25} {s['description']}")
        print()
        return

    # ── Validate & setup ──────────────────────────────────────────────────────
    try:
        validate_config()
    except ValueError as e:
        logger.error(str(e))
        sys.exit(1)

    _setup_mlflow()

    logger.info("=" * 60)
    logger.info("  AI4DueDil — Strategy Runner")
    logger.info("=" * 60)

    # ── Load shared resources (once) ──────────────────────────────────────────
    logger.info(f"\n[1/3] Loading proof corpus from: {PROOF_FOLDER}")
    file_corpus = load_proof_folder(PROOF_FOLDER)
    if not file_corpus:
        logger.error("No proof documents found in proof/ folder.")
        sys.exit(1)
    logger.info(f"Corpus: {len(file_corpus)} document(s)")

    logger.info(f"\n[2/3] Reading checklist from: {EXCEL_INPUT}")
    checklist = read_compliance_checklist(EXCEL_INPUT)
    if not checklist:
        logger.error("No exigences found in Excel.")
        sys.exit(1)
    labelled = sum(1 for r in checklist if r.get("human_label"))
    logger.info(f"Checklist: {len(checklist)} exigence(s), {labelled} with expert labels")

    # ── Determine which strategies to run ─────────────────────────────────────
    if args.strategy:
        names_to_run = [args.strategy]
    elif args.all:
        names_to_run = all_strategy_names()
        logger.info(f"Running all strategies: {names_to_run}")
    else:  # --compare
        names_to_run = args.compare

    # ── Run strategies ────────────────────────────────────────────────────────
    logger.info(f"\n[3/3] Running {len(names_to_run)} strategy(ies): {names_to_run}\n")

    all_results: dict = {}  # strategy_name → list[dict]

    for name in names_to_run:
        try:
            results = _run_strategy(name, checklist, file_corpus)
            all_results[name] = results
            _write_strategy_outputs(name, results, checklist)
            _print_summary(name, results)
        except ValueError as e:
            logger.error(str(e))
            available = ", ".join(all_strategy_names())
            logger.error(f"Available strategies: {available}")
            sys.exit(1)
        except Exception as e:
            logger.error(f"Strategy '{name}' failed: {e}", exc_info=True)
            sys.exit(1)

    # ── Comparison report (when 2+ strategies ran) ────────────────────────────
    if len(all_results) >= 2:
        compare_path = str(RESULTS_DIR / "comparison_report.xlsx")
        logger.info(f"\nWriting comparison report → {compare_path}")
        write_comparison_report(compare_path, all_results)
        logger.info("Comparison report ready.")

    logger.info(f"\n{'=' * 60}")
    logger.info(f"  Done. Outputs in: {RESULTS_DIR}/")
    logger.info(f"  MLflow: mlflow ui --backend-store-uri sqlite:///mlflow.db")
    logger.info(f"{'=' * 60}\n")


if __name__ == "__main__":
    main()
