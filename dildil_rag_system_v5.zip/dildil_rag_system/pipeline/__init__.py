"""
pipeline/__init__.py — Public API for the shared pipeline primitives.

Strategy graph files can import from here rather than the sub-modules,
so the internal layout can change without touching strategy code.

    from pipeline import bm25_page_triage, run_document_verdict, ...
"""

# ── Ingestion ─────────────────────────────────────────────────────────────────
from pipeline.ingestion import load_proof_folder, load_file          # noqa: F401

# ── Retrieval ─────────────────────────────────────────────────────────────────
from pipeline.retrieval import (                                      # noqa: F401
    bm25_page_triage,
    index_pages,
    semantic_search,
    get_embeddings,
    get_chroma_client,
    page_content_id,
    build_page_metadata,
)

# ── Verdict (LLM chains) ──────────────────────────────────────────────────────
from pipeline.verdict import (                                        # noqa: F401
    run_document_verdict,
    run_oral_verdict,
    classify_evidence_requirement,
    generate_french_keywords,
    LABEL_COMPLIANT,
    LABEL_PARTIAL,
    LABEL_NON,
)
