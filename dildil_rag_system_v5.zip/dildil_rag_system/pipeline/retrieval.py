"""
pipeline/retrieval.py — Shared retrieval primitives.

These functions are used by multiple strategies and live here
to avoid duplication. Strategy-specific orchestration (LangGraph
graphs, node wiring, state schemas) lives inside each strategy folder.

Public API:
    bm25_page_triage()   — lexical BM25 scoring across a corpus
    index_pages()        — embed pages into a named ChromaDB collection (dedup)
    semantic_search()    — similarity search inside a named ChromaDB collection
    get_embeddings()     — singleton embedding model loader
    get_chroma_client()  — singleton ChromaDB persistent client

Every function that touches ChromaDB accepts an explicit collection_name
so different strategies use isolated collections without collision:
    naive_rag    → "naive_rag_pages"
    bm25_hybrid  → config.CHROMA_COLLECTION_NAME  (default: "dildil_pages")
    hyde         → "hyde_pages"
    reranker     → no ChromaDB (cross-encoder scores pairs in memory)
"""
from __future__ import annotations

import hashlib
import logging
from pathlib import Path
from typing import Dict, List, Optional

import chromadb
import mlflow
from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_huggingface import HuggingFaceEmbeddings
from nltk.tokenize import word_tokenize
from rank_bm25 import BM25Okapi

from config import (
    BM25_TOP_K,
    CHROMA_PERSIST_DIR,
    EMBEDDING_MODEL,
    SEMANTIC_TOP_M,
)

logger = logging.getLogger(__name__)


# ─── Singletons ───────────────────────────────────────────────────────────────

_embeddings:    Optional[HuggingFaceEmbeddings]      = None
_chroma_client: Optional[chromadb.PersistentClient]  = None


def get_embeddings() -> HuggingFaceEmbeddings:
    """Lazy-load and cache the embedding model (loaded once per process)."""
    global _embeddings
    if _embeddings is None:
        logger.info(f"[Retrieval] Loading embedding model: {EMBEDDING_MODEL}")
        _embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)
    return _embeddings


def get_chroma_client() -> chromadb.PersistentClient:
    """Lazy-load and cache the shared ChromaDB persistent client."""
    global _chroma_client
    if _chroma_client is None:
        logger.info(f"[Retrieval] ChromaDB client at: {CHROMA_PERSIST_DIR}")
        _chroma_client = chromadb.PersistentClient(path=CHROMA_PERSIST_DIR)
    return _chroma_client


# ─── Content-hash helpers (public — used by strategy graphs) ─────────────────

def page_content_id(text: str) -> str:
    """sha256(text) — deterministic page ID for dedup."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def build_page_metadata(page: Dict) -> Dict:
    """Metadata dict stored alongside every page embedding in ChromaDB."""
    file_path = page.get("file_path", "")
    return {
        "content_id":  page_content_id(page["text"]),
        "source_file": page.get("source_file", ""),
        "file_path":   file_path,
        "page_num":    page.get("page_num", 0),
        "file_ext":    Path(file_path).suffix.lower() if file_path else "",
    }


def _tokenize(text: str) -> List[str]:
    try:
        return [t for t in word_tokenize(text.lower()) if t.isalnum()]
    except Exception:
        return [t for t in text.lower().split() if t.isalnum()]


# ─── BM25 Page Triage ─────────────────────────────────────────────────────────

@mlflow.trace(name="bm25_page_triage", span_type="RETRIEVER")
def bm25_page_triage(
    query: str,
    file_corpus: List[Dict],
    extra_terms: Optional[List[str]] = None,
    top_k: int = BM25_TOP_K,
) -> List[Dict]:
    """
    Score every page in the corpus with BM25. Return top-k by score.

    Args:
        query:       Base query string (the exigence text).
        file_corpus: Output of ingestion.load_proof_folder().
        extra_terms: Optional extra terms appended to the query
                     (LLM-generated keywords, proof file name hints, rep comments…).
        top_k:       Maximum pages to return.

    Returns:
        List of {text, source_file, file_path, page_num} dicts, score-descending.
    """
    if not file_corpus:
        logger.warning("[BM25] Corpus is empty")
        return []

    all_pages: List[Dict] = []
    for doc in file_corpus:
        for page in doc["pages"]:
            text = page["text"].strip()
            if text:
                all_pages.append({
                    "text":        text,
                    "source_file": doc["file_name"],
                    "file_path":   doc["file_path"],
                    "page_num":    page["page_num"],
                })

    if not all_pages:
        return []

    full_query   = f"{query} {' '.join(extra_terms)}" if extra_terms else query
    query_tokens = _tokenize(full_query)
    tokenized    = [_tokenize(p["text"]) for p in all_pages]

    scores      = BM25Okapi(tokenized).get_scores(query_tokens)
    top_indices = scores.argsort()[::-1][:top_k]
    candidates  = [all_pages[i] for i in top_indices if scores[i] > 0]

    logger.info(
        f"[BM25] {len(candidates)}/{len(all_pages)} pages shortlisted "
        f"[top: {[round(scores[i], 2) for i in top_indices[:3]]}]"
    )
    span = mlflow.get_current_active_span()
    if span:
        span.set_attributes({
            "total_pages": len(all_pages),
            "shortlisted": len(candidates),
            "query_tokens": len(query_tokens),
            "extra_terms": len(extra_terms) if extra_terms else 0,
        })
    return candidates


# ─── ChromaDB Index + Search ──────────────────────────────────────────────────

def index_pages(
    pages: List[Dict],
    collection_name: str,
) -> List[str]:
    """
    Embed pages into a named ChromaDB collection with content-hash dedup.
    Pages already indexed (same sha256 ID) are skipped — embeddings reused.

    Args:
        pages:           {text, source_file, file_path, page_num} dicts.
        collection_name: ChromaDB collection to write to.

    Returns:
        List of content_id strings for ALL pages (existing + newly added).
    """
    client     = get_chroma_client()
    embeddings = get_embeddings()

    documents = [
        Document(page_content=p["text"], metadata=build_page_metadata(p))
        for p in pages
    ]
    all_ids = [d.metadata["content_id"] for d in documents]

    try:
        existing     = client.get_or_create_collection(collection_name).get(ids=all_ids, include=[])
        existing_ids = set(existing["ids"])
    except Exception:
        existing_ids = set()

    new_docs = [d for d in documents if d.metadata["content_id"] not in existing_ids]
    skipped  = len(all_ids) - len(new_docs)

    logger.info(
        f"[Index] '{collection_name}': {skipped} reused, "
        f"embedding {len(new_docs)} new page(s)"
    )

    if new_docs:
        Chroma.from_documents(
            documents=new_docs,
            embedding=embeddings,
            collection_name=collection_name,
            client=client,
            ids=[d.metadata["content_id"] for d in new_docs],
        )
    return all_ids


def semantic_search(
    query: str,
    collection_name: str,
    top_k: int = SEMANTIC_TOP_M,
    restrict_to_ids: Optional[List[str]] = None,
) -> List[Dict]:
    """
    Similarity search inside a named ChromaDB collection.

    Args:
        query:           Query string to embed and search.
        collection_name: Which collection to search.
        top_k:           Number of results to return.
        restrict_to_ids: If set, scope search to only these content_ids
                         (used by bm25_hybrid to search inside BM25 candidates only).

    Returns:
        List of {text, source_file, file_path, page_num, file_ext} dicts.
    """
    embeddings = get_embeddings()
    vs = Chroma(
        collection_name=collection_name,
        embedding_function=embeddings,
        client=get_chroma_client(),
    )

    k = min(top_k, restrict_to_ids and len(restrict_to_ids) or top_k)

    if restrict_to_ids:
        results = vs.similarity_search(
            query, k=k,
            filter={"content_id": {"$in": restrict_to_ids}},
        )
    else:
        results = vs.similarity_search(query, k=k)

    pages = [
        {
            "text":        doc.page_content,
            "source_file": doc.metadata.get("source_file", ""),
            "file_path":   doc.metadata.get("file_path", ""),
            "page_num":    doc.metadata.get("page_num", 0),
            "file_ext":    doc.metadata.get("file_ext", ""),
        }
        for doc in results
    ]
    logger.info(f"[Semantic] '{collection_name}': retrieved {len(pages)} page(s)")
    return pages
