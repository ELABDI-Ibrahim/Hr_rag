"""
pipeline/verdict.py — LLM compliance verdict for AI4DueDil.

Two separate verdict chains depending on evidence type:

  A) document_required  → full RAG context passed to LLM
     Metrics: Context Recall, Context Precision, Faithfulness
     Output : compliance + justification_type="document"

  B) oral_implicit / ambiguous  → representative's tag + comments only
     Metrics: label correctness (Cohen's κ), reasoning quality
     Output : compliance + justification_type="oral" | "inferred"

Output schema (ComplianceVerdict):
    compliance        : compliant | partially_compliant | non_compliant
    justification_type: document | oral | inferred
    evidence          : what was found / what justifies the label
    confidence        : 0.0 – 1.0
    reasoning         : 2-4 sentence explanation
    source_files      : list of cited file names (empty for oral)

Also exposes:
  generate_french_keywords() — used by keyword_suggestion node (Node 2)
  classify_evidence_requirement() — used by evidence_mining node (Node 1)
"""
import logging
from typing import Dict, List, Literal, Optional

import mlflow
from langchain_core.prompts import ChatPromptTemplate
from langchain_groq import ChatGroq
from pydantic import BaseModel, Field

from config import (
    COMPLIANCE_LABELS,
    EVIDENCE_AMBIGUOUS,
    EVIDENCE_DOCUMENT,
    EVIDENCE_ORAL,
    GROQ_API_KEY,
    GROQ_MODEL,
    LABEL_COMPLIANT,
    LABEL_NON,
    LABEL_PARTIAL,
)

logger = logging.getLogger(__name__)


# ─── LLM builder ──────────────────────────────────────────────────────────────

def _build_llm(temperature: float = 0) -> ChatGroq:
    return ChatGroq(api_key=GROQ_API_KEY, model=GROQ_MODEL, temperature=temperature)


# ─── Output Schemas ───────────────────────────────────────────────────────────

class EvidenceRequirement(BaseModel):
    """Evidence type classification returned by the evidence mining node."""

    evidence_type: Literal["document_required", "oral_implicit", "ambiguous"] = Field(
        description=(
            "document_required → a concrete document (certificate, contract, report…) "
            "is normally expected to substantiate this requirement. "
            "oral_implicit → the requirement is verified through a declaration, "
            "process description, or contextual information rather than a hard document. "
            "ambiguous → the requirement could go either way; documents may or may not exist."
        )
    )
    rationale: str = Field(
        description="One sentence explaining why this classification was chosen."
    )


class ComplianceVerdict(BaseModel):
    """Structured compliance verdict for one exigence row."""

    compliance: Literal["compliant", "partially_compliant", "non_compliant"] = Field(
        description=(
            "compliant            → the exigence is fully satisfied. "
            "partially_compliant  → evidence is partial, incomplete, or conditional. "
            "non_compliant        → the exigence is clearly not met."
        )
    )
    justification_type: Literal["document", "oral", "inferred"] = Field(
        description=(
            "document  → conclusion drawn from retrieved document evidence. "
            "oral      → conclusion drawn from the representative's declaration / comments. "
            "inferred  → conclusion drawn by reasoning from context with no hard proof."
        )
    )
    evidence: str = Field(
        description=(
            "What was found (document title, clause, date) OR what declaration "
            "supports the verdict. Be specific: name files, dates, cert numbers."
        )
    )
    confidence: float = Field(
        ge=0.0, le=1.0,
        description=(
            "0.9–1.0 → strong documentary evidence or unambiguous declaration. "
            "0.6–0.8 → partial evidence or inferred from context. "
            "0.0–0.5 → weak, contradictory, or missing evidence."
        )
    )
    reasoning: str = Field(
        description=(
            "2-4 sentences explaining the verdict. Reference specific "
            "details (file names, dates, cert numbers, clause text). "
            "Note any gaps, inconsistencies, or caveats. Respond in French."
        )
    )
    source_files: List[str] = Field(
        default_factory=list,
        description=(
            "List of file names that contain relevant evidence. "
            "Empty list if no documents were retrieved."
        )
    )


# ─── Evidence Requirement Mining ──────────────────────────────────────────────

_EVIDENCE_MINING_PROMPT = ChatPromptTemplate.from_messages([
    (
        "system",
        "Tu es un expert en conformité réglementaire et due diligence de prestataires. "
        "Tu analyses des exigences de conformité pour déterminer si elles nécessitent "
        "une preuve documentaire concrète ou si elles peuvent être vérifiées de façon "
        "déclarative / implicite.",
    ),
    (
        "human",
        """Exigence de conformité : {exigence}

Classifie cette exigence selon les critères suivants :
- document_required : un document concret est normalement attendu (certificat ISO, contrat signé, rapport d'audit, attestation, liste nominative…)
- oral_implicit : la conformité peut être évaluée sur déclaration ou sur la base d'un processus décrit (ex: "les équipes ont reçu une formation", "le prestataire s'engage à…")
- ambiguous : la nature de la preuve attendue est incertaine

Réponds en JSON structuré uniquement.""",
    ),
])


@mlflow.trace(name="classify_evidence_requirement", span_type="LLM")
def classify_evidence_requirement(exigence: str) -> Dict:
    """
    Classify whether the exigence requires a hard document, oral/implicit
    declaration, or is ambiguous.

    Returns a dict with keys: evidence_type, rationale
    Falls back to 'ambiguous' on error.
    """
    try:
        chain = _EVIDENCE_MINING_PROMPT | _build_llm(temperature=0).with_structured_output(
            EvidenceRequirement
        )
        result: EvidenceRequirement = chain.invoke({"exigence": exigence})
        span = mlflow.get_current_active_span()
        if span:
            span.set_attributes({
                "exigence":      exigence[:200],
                "evidence_type": result.evidence_type,
                "rationale":     result.rationale,
            })
        return result.model_dump()
    except Exception as e:
        logger.warning(f"[Evidence Mining] Failed for '{exigence[:60]}': {e}")
        return {"evidence_type": EVIDENCE_AMBIGUOUS, "rationale": f"Classification échouée: {e}"}


# ─── French Keyword Generation ────────────────────────────────────────────────

_KEYWORD_PROMPT = ChatPromptTemplate.from_messages([
    (
        "system",
        "Tu es un expert en conformité, SSI (Sécurité des Systèmes d'Information) "
        "et due diligence de prestataires. "
        "Réponds uniquement avec une liste de mots-clés séparés par des virgules, sans explication.",
    ),
    (
        "human",
        "Liste 20 à 30 mots-clés, expressions typiques ET synonymes que l'on trouverait dans un "
        "document justifiant l'exigence suivante : '{exigence}'. "
        "Inclure : noms de certifications (ISO 27001, SOC 2, RGPD…), termes juridiques, "
        "titres de sections typiques, acronymes et toute variation linguistique. "
        "Ces mots-clés seront utilisés pour un moteur BM25 cherchant dans des PDF de preuve.",
    ),
])


@mlflow.trace(name="generate_french_keywords", span_type="LLM")
def generate_french_keywords(exigence: str) -> List[str]:
    """
    Generate BM25-friendly French keywords for an exigence string.
    Falls back to an empty list on error.
    """
    try:
        chain = _KEYWORD_PROMPT | _build_llm(temperature=0.2)
        response = chain.invoke({"exigence": exigence})
        raw = response.content.strip()
        keywords = [k.strip() for k in raw.split(",") if k.strip()]
        logger.info(
            f"[Keywords] {len(keywords)} keyword(s) for '{exigence[:60]}': "
            f"{keywords[:5]}{'…' if len(keywords) > 5 else ''}"
        )
        span = mlflow.get_current_active_span()
        if span:
            span.set_attributes({
                "exigence":      exigence[:200],
                "keyword_count": len(keywords),
                "keywords":      ", ".join(keywords),
            })
        return keywords
    except Exception as e:
        logger.warning(f"[Keywords] Failed for '{exigence[:60]}': {e}")
        return []


# ─── Verdict Prompts ──────────────────────────────────────────────────────────

# ── A) Document-based verdict ─────────────────────────────────────────────────
_DOCUMENT_VERDICT_PROMPT = ChatPromptTemplate.from_messages([
    (
        "system",
        """Tu es un expert SSI (Sécurité des Systèmes d'Information) chez AXA France chargé de vérifier la conformité des prestataires lors du processus de due diligence.

Ta mission : analyser les extraits de documents fournis ET la réponse du représentant du prestataire pour déterminer si l'exigence est satisfaite.

Règles :
- La conformité COMPLÈTE nécessite une preuve documentaire claire et non expirée.
- La conformité PARTIELLE s'applique si la preuve existe mais est incomplète, ambiguë, expirée, ou ne couvre qu'une partie de l'exigence.
- La NON-CONFORMITÉ s'applique si aucune preuve pertinente n'est trouvée dans les documents, même si le représentant affirme être conforme.
- Méfie-toi des documents hors-sujet, des PDF de 80+ pages sans contenu pertinent, et des preuves génériques non liées à l'exigence.
- Sois factuel. Cite les noms de fichiers, dates, numéros de certification. Réponds en français.""",
    ),
    (
        "human",
        """## Exigence de conformité
{exigence}

## Réponse du représentant du prestataire
Statut déclaré : {rep_tag}
Commentaires   : {rep_comments}
Fichiers de preuve mentionnés : {proof_refs}

## Mots-clés de recherche utilisés
{keywords_section}

## Extraits de documents récupérés
{context}

---
Sur la base des extraits ci-dessus ET de la réponse du représentant, quel est le niveau de conformité réel pour cette exigence ?""",
    ),
])

# ── B) Oral/implicit verdict (no retrieval) ───────────────────────────────────
_ORAL_VERDICT_PROMPT = ChatPromptTemplate.from_messages([
    (
        "system",
        """Tu es un expert SSI chez AXA France. Cette exigence ne nécessite pas de preuve documentaire formelle — elle peut être évaluée sur déclaration ou sur la description d'un processus.

Ta mission : analyser la réponse du représentant du prestataire pour évaluer la plausibilité et la cohérence de sa conformité déclarée.

Règles :
- Évalue la cohérence et la précision de la réponse (vague vs. spécifique).
- Un engagement général sans détail → PARTIEL.
- Une déclaration précise avec des exemples concrets → CONFORME.
- Une réponse évasive ou contradictoire → NON CONFORME.
- justification_type doit être "oral" ou "inferred". Réponds en français.""",
    ),
    (
        "human",
        """## Exigence de conformité
{exigence}

## Réponse du représentant du prestataire
Statut déclaré  : {rep_tag}
Commentaires    : {rep_comments}
Fichiers joints : {proof_refs}

---
Sur la base de cette déclaration uniquement, évalue le niveau de conformité réel.""",
    ),
])


# ─── Context Formatter ────────────────────────────────────────────────────────

def _format_context(retrieved_pages: List[Dict]) -> str:
    if not retrieved_pages:
        return "⚠️  Aucun document pertinent trouvé dans le dossier de preuves."
    blocks = []
    for i, page in enumerate(retrieved_pages, 1):
        blocks.append(
            f"[Extrait {i}] Fichier : {page['source_file']} | Page : {page['page_num']}\n"
            f"{page['text']}"
        )
    sep = "\n\n" + "─" * 60 + "\n\n"
    return "\n\n" + sep.join(blocks)


def _format_keywords(keywords: List[str]) -> str:
    return ", ".join(keywords) if keywords else "(aucun mot-clé)"


def _normalize_tag(tag: str) -> str:
    """Map raw representative tag to canonical label."""
    t = tag.lower().strip()
    if "non" in t:
        return LABEL_NON
    if "partial" in t or "partiel" in t:
        return LABEL_PARTIAL
    if "oui" in t or "conforme" in t or "compliant" in t:
        return LABEL_COMPLIANT
    return LABEL_PARTIAL  # safe default


# ─── Public API ───────────────────────────────────────────────────────────────

def run_document_verdict(
    exigence: str,
    rep_tag: str,
    rep_comments: str,
    proof_refs: List[str],
    retrieved_pages: List[Dict],
    french_keywords: Optional[List[str]] = None,
) -> Dict:
    """
    Run LLM verdict when evidence_type == document_required.
    Uses retrieved document context + representative's input.
    """
    chain = _DOCUMENT_VERDICT_PROMPT | _build_llm().with_structured_output(ComplianceVerdict)
    try:
        verdict: ComplianceVerdict = chain.invoke({
            "exigence":        exigence,
            "rep_tag":         rep_tag,
            "rep_comments":    rep_comments or "(pas de commentaire)",
            "proof_refs":      ", ".join(proof_refs) if proof_refs else "Aucun fichier mentionné",
            "keywords_section": _format_keywords(french_keywords or []),
            "context":         _format_context(retrieved_pages),
        })
        return verdict.model_dump()
    except Exception as e:
        logger.error(f"[DocumentVerdict] Failed: {e}")
        return _error_verdict(e)


def run_oral_verdict(
    exigence: str,
    rep_tag: str,
    rep_comments: str,
    proof_refs: List[str],
) -> Dict:
    """
    Run LLM verdict when evidence_type == oral_implicit.
    Skips retrieval — evaluates the representative's declaration only.
    """
    chain = _ORAL_VERDICT_PROMPT | _build_llm().with_structured_output(ComplianceVerdict)
    try:
        verdict: ComplianceVerdict = chain.invoke({
            "exigence":     exigence,
            "rep_tag":      rep_tag,
            "rep_comments": rep_comments or "(pas de commentaire)",
            "proof_refs":   ", ".join(proof_refs) if proof_refs else "Aucun",
        })
        return verdict.model_dump()
    except Exception as e:
        logger.error(f"[OralVerdict] Failed: {e}")
        return _error_verdict(e)


def _error_verdict(e: Exception) -> Dict:
    return {
        "compliance":         LABEL_NON,
        "justification_type": "inferred",
        "evidence":           f"Erreur lors du verdict: {e}",
        "confidence":         0.0,
        "reasoning":          f"Le verdict n'a pas pu être déterminé en raison d'une erreur: {e}",
        "source_files":       [],
    }
