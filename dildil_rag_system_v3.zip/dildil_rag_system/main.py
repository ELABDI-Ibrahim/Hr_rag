"""
main.py — AI4DueDil Compliance Verification Pipeline entry point.

Usage:
    python main.py [--eval-only]

What it does:
    1. Loads all proof documents from the proof/ folder (once)
    2. Reads the exigence checklist from the AI4DueDil Excel input file
    3. For each exigence, runs the LangGraph compliance pipeline:
           evidence_mining
             ├─ [document/ambiguous] keyword_suggestion → bm25_triage → semantic_search → document_verdict
             └─ [oral_implicit]                                                            oral_verdict
    4. Writes AI verdicts back into the output Excel
    5. Runs the evaluation suite (if human labels are present) → evaluation report

MLflow Tracing:
    Run `mlflow ui --backend-store-uri sqlite:///mlflow.db` to explore traces.
"""
import argparse
import logging
import sys

import mlflow

from config import (
    EVAL_OUTPUT,
    EXCEL_INPUT,
    EXCEL_OUTPUT,
    MLFLOW_EXPERIMENT_NAME,
    MLFLOW_TRACKING_URI,
    PROOF_FOLDER,
    validate_config,
)
from pipeline.graph import build_compliance_graph
from pipeline.ingestion import load_proof_folder
from utils.excel_handler import read_compliance_checklist, write_results
from utils.evaluation import write_evaluation_report

# ─── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  [%(levelname)-8s]  %(name)s — %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)


def _setup_mlflow() -> None:
    mlflow.set_tracking_uri(MLFLOW_TRACKING_URI or "sqlite:///mlflow.db")
    mlflow.set_experiment(MLFLOW_EXPERIMENT_NAME)
    mlflow.langchain.autolog()
    logger.info(
        f"MLflow → experiment: '{MLFLOW_EXPERIMENT_NAME}' "
        f"tracking: '{mlflow.get_tracking_uri()}'"
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="AI4DueDil Compliance RAG Pipeline")
    parser.add_argument("--eval-only", action="store_true",
                        help="Skip pipeline, only regenerate evaluation report from existing output")
    args = parser.parse_args()

    logger.info("=" * 60)
    logger.info("  AI4DueDil — Compliance Verification RAG Pipeline")
    logger.info("=" * 60)

    try:
        validate_config()
    except ValueError as e:
        logger.error(str(e))
        sys.exit(1)

    _setup_mlflow()

    # ── 1. Load proof corpus ──────────────────────────────────────────────────
    logger.info(f"\n[Step 1] Loading proof documents from: {PROOF_FOLDER}")
    file_corpus = load_proof_folder(PROOF_FOLDER)
    if not file_corpus:
        logger.error("No proof documents found. Check that proof/ folder exists and contains PDFs or Markdown files.")
        sys.exit(1)
    logger.info(f"Corpus ready: {len(file_corpus)} document(s)\n")

    # ── 2. Read exigence checklist ────────────────────────────────────────────
    logger.info(f"[Step 2] Reading exigences from: {EXCEL_INPUT}")
    checklist = read_compliance_checklist(EXCEL_INPUT)
    if not checklist:
        logger.error("No exigences found. Check the Excel file.")
        sys.exit(1)
    labelled = sum(1 for r in checklist if r.get("human_label"))
    logger.info(f"Found {len(checklist)} exigence(s) ({labelled} with expert labels for evaluation)\n")

    # ── 3. Build LangGraph pipeline ───────────────────────────────────────────
    logger.info("[Step 3] Compiling LangGraph pipeline...")
    graph = build_compliance_graph()
    logger.info("Pipeline ready\n")

    # ── 4. Run pipeline ───────────────────────────────────────────────────────
    logger.info(f"[Step 4] Processing {len(checklist)} exigence(s)...\n")
    results = []

    for i, row in enumerate(checklist, 1):
        logger.info(f"{'─' * 55}")
        logger.info(f"[{i}/{len(checklist)}] {row['exigence'][:80]}")

        initial_state = {
            "exigence":          row["exigence"],
            "rep_tag":           row["rep_tag"],
            "rep_comments":      row["rep_comments"],
            "proof_refs":        row["proof_refs"],
            "file_corpus":       file_corpus,
            # Filled by graph nodes:
            "evidence_type":     "",
            "evidence_rationale":"",
            "french_keywords":   [],
            "candidate_pages":   [],
            "retrieved_pages":   [],
            "verdict":           {},
        }

        run_name = f"[{i}] {row['exigence'][:50]}"
        with mlflow.start_run(run_name=run_name):
            mlflow.set_tags({
                "exigence":    row["exigence"][:100],
                "rep_tag":     row["rep_tag"],
                "has_proofs":  str(bool(row["proof_refs"])),
                "has_label":   str(bool(row.get("human_label"))),
            })

            final_state = graph.invoke(initial_state)
            verdict    = final_state["verdict"]
            ev_type    = final_state.get("evidence_type", "ambiguous")

            mlflow.set_tags({
                "compliance":    verdict.get("compliance", ""),
                "just_type":     verdict.get("justification_type", ""),
                "evidence_type": ev_type,
            })
            mlflow.log_metric("confidence", verdict.get("confidence", 0.0))

        results.append({
            "exigence":       row["exigence"],
            "row_index":      row["row_index"],
            "rep_tag":        row["rep_tag"],
            "rep_comments":   row["rep_comments"],
            "proof_refs":     row["proof_refs"],
            "human_label":    row.get("human_label"),
            "human_notes":    row.get("human_notes", ""),
            "verdict":        verdict,
            "evidence_type":  ev_type,
            "retrieved_pages": final_state.get("retrieved_pages", []),
        })

    # ── 5. Write AI verdicts to Excel ─────────────────────────────────────────
    logger.info(f"\n{'─' * 55}")
    logger.info(f"[Step 5] Writing AI verdicts to: {EXCEL_OUTPUT}")
    write_results(EXCEL_INPUT, EXCEL_OUTPUT, results)

    # ── 6. Evaluation report ──────────────────────────────────────────────────
    labelled_results = [r for r in results if r.get("human_label")]
    if labelled_results:
        logger.info(f"\n[Step 6] Running evaluation on {len(labelled_results)} labelled rows...")
        write_evaluation_report(EVAL_OUTPUT, results)
        logger.info(f"Evaluation report saved to: {EVAL_OUTPUT}")
    else:
        logger.info("\n[Step 6] No human labels found — skipping evaluation report.")
        logger.info("          Fill column O (Feedback Expert ✍) in the Excel to enable evaluation.")

    # ── Summary ───────────────────────────────────────────────────────────────
    counts = {"compliant": 0, "partially_compliant": 0, "non_compliant": 0}
    ev_counts = {"document_required": 0, "oral_implicit": 0, "ambiguous": 0}
    for r in results:
        c = r["verdict"].get("compliance", "non_compliant")
        counts[c] = counts.get(c, 0) + 1
        ev_counts[r.get("evidence_type", "ambiguous")] = ev_counts.get(r.get("evidence_type", "ambiguous"), 0) + 1

    logger.info(f"\n{'=' * 60}")
    logger.info(f"  ✅ Conforme            : {counts['compliant']}")
    logger.info(f"  ⚠️  Partiellement conf. : {counts['partially_compliant']}")
    logger.info(f"  ❌ Non conforme        : {counts['non_compliant']}")
    logger.info(f"  📄 Document requis     : {ev_counts['document_required']}")
    logger.info(f"  🗣️  Déclaratif          : {ev_counts['oral_implicit']}")
    logger.info(f"  ❓ Ambigu              : {ev_counts['ambiguous']}")
    logger.info(f"  Results  → {EXCEL_OUTPUT}")
    logger.info(f"  Eval     → {EVAL_OUTPUT}")
    logger.info(f"{'=' * 60}\n")


if __name__ == "__main__":
    main()
