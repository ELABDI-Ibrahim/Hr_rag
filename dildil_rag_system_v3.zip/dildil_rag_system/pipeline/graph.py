"""
pipeline/graph.py — AI4DueDil LangGraph compliance verification pipeline.

Graph flow for ONE exigence row:

    START
      │
      ▼
  evidence_mining      Node 1: LLM classifies evidence type
      │                        (document_required | oral_implicit | ambiguous)
      ▼
  [conditional routing]
      │
      ├─── document_required / ambiguous ───►  keyword_suggestion   Node 2
      │                                               │
      │                                        bm25_triage          Node 3
      │                                               │
      │                                        semantic_search      Node 4
      │                                               │
      │                                        document_verdict     Node 5a
      │                                               │
      └─── oral_implicit ───────────────────►  oral_verdict         Node 5b
                                                       │
                                                     END

The graph is compiled once and reused for every Excel row.
"""
import logging
from typing import Any, Dict, List, Optional

from langgraph.graph import END, StateGraph
from typing_extensions import TypedDict

from config import (
    BM25_TOP_K,
    EVIDENCE_AMBIGUOUS,
    EVIDENCE_DOCUMENT,
    EVIDENCE_ORAL,
    SEMANTIC_TOP_M,
)
from pipeline.retrieval import bm25_page_triage, semantic_page_search
from pipeline.verdict import (
    classify_evidence_requirement,
    generate_french_keywords,
    run_document_verdict,
    run_oral_verdict,
)

logger = logging.getLogger(__name__)


# ─── State Schema ─────────────────────────────────────────────────────────────

class PipelineState(TypedDict):
    """Shared state threaded through every graph node."""

    # ── Inputs from Excel row ────────────────────────────────────────────────
    exigence:     str         # The compliance requirement text
    rep_tag:      str         # Representative's compliance tag (raw)
    rep_comments: str         # Representative's free-text comments
    proof_refs:   List[str]   # File names mentioned by representative (may be empty)
    file_corpus:  List[Dict]  # All loaded proof documents

    # ── Node 1 output ────────────────────────────────────────────────────────
    evidence_type: str        # document_required | oral_implicit | ambiguous
    evidence_rationale: str   # One-sentence rationale from LLM

    # ── Node 2 output (only for document/ambiguous path) ─────────────────────
    french_keywords: List[str]

    # ── Node 3 output ────────────────────────────────────────────────────────
    candidate_pages: List[Dict]

    # ── Node 4 output ────────────────────────────────────────────────────────
    retrieved_pages: List[Dict]

    # ── Node 5 output ────────────────────────────────────────────────────────
    verdict: Dict   # compliance, justification_type, evidence, confidence, reasoning, source_files


# ─── Node 1 — Evidence Mining ─────────────────────────────────────────────────

def evidence_mining_node(state: PipelineState) -> Dict[str, Any]:
    """
    Node 1 — Classify what kind of proof is expected for this exigence.
    Result routes the graph either through the full RAG path or the oral path.
    """
    logger.info(f"[Node 1 / Evidence] Classifying: '{state['exigence'][:80]}'")
    result = classify_evidence_requirement(state["exigence"])
    logger.info(
        f"[Node 1 / Evidence] → {result['evidence_type']} | {result['rationale']}"
    )
    return {
        "evidence_type":      result["evidence_type"],
        "evidence_rationale": result["rationale"],
    }


# ─── Node 2 — Keyword Suggestion ─────────────────────────────────────────────

def keyword_suggestion_node(state: PipelineState) -> Dict[str, Any]:
    """Node 2 — Generate BM25 keywords for the exigence (document path only)."""
    logger.info(f"[Node 2 / Keywords] Expanding: '{state['exigence'][:60]}'")
    keywords = generate_french_keywords(state["exigence"])
    logger.info(f"[Node 2 / Keywords] Generated {len(keywords)} keyword(s)")
    return {"french_keywords": keywords}


# ─── Node 3 — BM25 Triage ────────────────────────────────────────────────────

def bm25_triage_node(state: PipelineState) -> Dict[str, Any]:
    """Node 3 — BM25 page triage across the entire proof corpus."""
    query    = state["exigence"]
    keywords = state.get("french_keywords", [])

    # Boost query with any proof file names the representative mentioned
    # (even if mapping is loose, the file names often contain hint terms)
    proof_hint = " ".join(state.get("proof_refs", []))
    enriched_query = f"{query} {proof_hint}".strip()

    logger.info(
        f"[Node 3 / BM25] Query: '{enriched_query[:60]}' + {len(keywords)} keywords"
    )
    candidates = bm25_page_triage(
        exigence=enriched_query,
        file_corpus=state["file_corpus"],
        french_keywords=keywords,
        top_k=BM25_TOP_K,
    )
    if not candidates:
        logger.warning("[Node 3 / BM25] No candidate pages found")
    return {"candidate_pages": candidates}


# ─── Node 4 — Semantic Search ─────────────────────────────────────────────────

def semantic_search_node(state: PipelineState) -> Dict[str, Any]:
    """Node 4 — Embed BM25 candidates and run restricted semantic search."""
    n = len(state.get("candidate_pages", []))
    logger.info(f"[Node 4 / Semantic] Searching {n} BM25 candidate page(s)")
    pages = semantic_page_search(
        exigence=state["exigence"],
        candidate_pages=state.get("candidate_pages", []),
        top_m=SEMANTIC_TOP_M,
    )
    return {"retrieved_pages": pages}


# ─── Node 5a — Document Verdict ───────────────────────────────────────────────

def document_verdict_node(state: PipelineState) -> Dict[str, Any]:
    """
    Node 5a — LLM verdict using retrieved document context.
    Used for document_required and ambiguous evidence types.
    """
    n_pages = len(state.get("retrieved_pages", []))
    logger.info(
        f"[Node 5a / DocumentVerdict] '{state['exigence'][:60]}' "
        f"({n_pages} page(s) retrieved)"
    )
    verdict = run_document_verdict(
        exigence=state["exigence"],
        rep_tag=state.get("rep_tag", ""),
        rep_comments=state.get("rep_comments", ""),
        proof_refs=state.get("proof_refs", []),
        retrieved_pages=state.get("retrieved_pages", []),
        french_keywords=state.get("french_keywords", []),
    )
    _log_verdict(verdict)
    return {"verdict": verdict}


# ─── Node 5b — Oral Verdict ───────────────────────────────────────────────────

def oral_verdict_node(state: PipelineState) -> Dict[str, Any]:
    """
    Node 5b — LLM verdict based on representative's declaration only.
    Used for oral_implicit evidence type (no retrieval metrics apply).
    """
    logger.info(
        f"[Node 5b / OralVerdict] '{state['exigence'][:60]}' "
        f"(declarative path — no retrieval)"
    )
    verdict = run_oral_verdict(
        exigence=state["exigence"],
        rep_tag=state.get("rep_tag", ""),
        rep_comments=state.get("rep_comments", ""),
        proof_refs=state.get("proof_refs", []),
    )
    _log_verdict(verdict)
    return {"verdict": verdict}


def _log_verdict(verdict: Dict) -> None:
    icons = {
        "compliant":           "✅",
        "partially_compliant": "⚠️",
        "non_compliant":       "❌",
    }
    icon = icons.get(verdict.get("compliance", ""), "?")
    logger.info(
        f"  {icon} {verdict.get('compliance', '').upper()} "
        f"[conf={verdict.get('confidence', 0):.2f}] "
        f"[{verdict.get('justification_type', '')}] "
        f"— {verdict.get('reasoning', '')[:80]}"
    )


# ─── Routing Function ─────────────────────────────────────────────────────────

def route_after_evidence_mining(state: PipelineState) -> str:
    """
    Conditional edge after Node 1.
    document_required | ambiguous → keyword_suggestion (full RAG path)
    oral_implicit                 → oral_verdict (skip retrieval)
    """
    ev = state.get("evidence_type", "ambiguous")
    if ev == EVIDENCE_ORAL:
        logger.info("[Router] oral_implicit → skipping retrieval → oral_verdict")
        return "oral_verdict"
    logger.info(f"[Router] {ev} → starting full RAG path")
    return "keyword_suggestion"


# ─── Graph Builder ────────────────────────────────────────────────────────────

def build_compliance_graph():
    """
    Assemble and compile the AI4DueDil compliance verification LangGraph.

    Returns a compiled LangGraph runnable.
    Call .invoke(initial_state) to process one exigence row.
    """
    graph = StateGraph(PipelineState)

    # Register nodes
    graph.add_node("evidence_mining",    evidence_mining_node)
    graph.add_node("keyword_suggestion", keyword_suggestion_node)
    graph.add_node("bm25_triage",        bm25_triage_node)
    graph.add_node("semantic_search",    semantic_search_node)
    graph.add_node("document_verdict",   document_verdict_node)
    graph.add_node("oral_verdict",       oral_verdict_node)

    # Entry point
    graph.set_entry_point("evidence_mining")

    # Conditional routing after evidence mining
    graph.add_conditional_edges(
        "evidence_mining",
        route_after_evidence_mining,
        {
            "keyword_suggestion": "keyword_suggestion",
            "oral_verdict":       "oral_verdict",
        },
    )

    # Document/ambiguous path
    graph.add_edge("keyword_suggestion", "bm25_triage")
    graph.add_edge("bm25_triage",        "semantic_search")
    graph.add_edge("semantic_search",    "document_verdict")
    graph.add_edge("document_verdict",   END)

    # Oral path
    graph.add_edge("oral_verdict", END)

    return graph.compile()
