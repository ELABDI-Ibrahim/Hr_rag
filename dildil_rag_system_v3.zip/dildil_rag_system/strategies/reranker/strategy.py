"""
strategies/reranker/strategy.py — BM25 + Cross-Encoder Reranker strategy.

Pipeline:
  1. BM25 broad recall  → top-20 candidate pages (lexical, high recall)
  2. Cross-encoder reranking → re-score all 20 with a bi-encoder model,
     keep top-4 (precise semantic relevance)
  3. LLM verdict on the reranked top-4

Why this is interesting to compare against naive_rag and bm25_hybrid:
  - naive_rag:    single-stage embedding similarity (fast, often imprecise)
  - bm25_hybrid:  BM25 → semantic via separate embed + ChromaDB (two models,
                  restricted search)
  - reranker:     BM25 → cross-encoder (one scoring model, no vector DB needed
                  for the rerank step — cross-encoders score pairs directly
                  so they catch nuance that bi-encoders miss)

The cross-encoder model (ms-marco-MiniLM-L-6-v2) is much slower than
bi-encoder similarity but much more accurate for passage relevance.
The BM25 pre-filter keeps it tractable: score 20 pairs instead of all pages.

Expected behaviour vs baselines:
  - Should outperform naive_rag on context precision (fewer irrelevant chunks)
  - May outperform bm25_hybrid on oral/ambiguous rows where keyword expansion
    doesn't help much — cross-encoder captures paraphrase better
  - Slower than naive_rag but faster than bm25_hybrid (no embedding step for
    the final top-k, cross-encoder runs locally on small candidate set)
"""
from __future__ import annotations

import logging
import time
from typing import Dict, List, Optional, Tuple

from strategies.base import BaseStrategy, StrategyResult

logger = logging.getLogger(__name__)

# ── Tuning constants ──────────────────────────────────────────────────────────
BM25_RECALL_K   = 20   # broad BM25 first pass
RERANK_KEEP     = 4    # cross-encoder reranked final top-k
CROSS_ENC_MODEL = "cross-encoder/ms-marco-MiniLM-L-6-v2"


class RerankerStrategy(BaseStrategy):
    """
    Two-stage retrieval: BM25 broad recall → cross-encoder reranking.

    Stage 1 — BM25 (high recall, low precision):
        Score all pages against (exigence + rep_comments) query.
        Keep top-20. This is cheap and ensures the relevant page is in the
        candidate set even if the query wording diverges from the document.

    Stage 2 — Cross-encoder (high precision, slow):
        Score each of the 20 (query, page) pairs directly.
        Cross-encoders read both texts jointly so they capture semantic
        overlap that bag-of-words and bi-encoder similarity miss.
        Keep top-4 for the LLM.

    Stage 3 — LLM verdict (same as all other strategies).
    """

    NAME        = "reranker"
    DESCRIPTION = (
        "BM25 broad recall (top-20) → cross-encoder reranking → top-4 to LLM. "
        "No vector DB — cross-encoder scores (query, passage) pairs directly."
    )

    def __init__(self) -> None:
        self._cross_encoder = None
        self._corpus_pages: List[Dict] = []

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def setup(self, file_corpus: List[Dict]) -> None:
        """
        Load the cross-encoder model and flatten corpus pages once.
        The cross-encoder is loaded lazily here so the import only runs
        if this strategy is actually selected.
        """
        logger.info(f"[Reranker] Loading cross-encoder: {CROSS_ENC_MODEL}")
        try:
            from sentence_transformers import CrossEncoder
            self._cross_encoder = CrossEncoder(CROSS_ENC_MODEL)
            logger.info("[Reranker] Cross-encoder ready")
        except ImportError:
            raise ImportError(
                "sentence-transformers is required for the reranker strategy. "
                "Run: pip install sentence-transformers"
            )

        # Flatten corpus into a single list of page dicts (same shape as BM25 triage output)
        self._corpus_pages = []
        for file_doc in file_corpus:
            for page in file_doc["pages"]:
                text = page["text"].strip()
                if not text:
                    continue
                self._corpus_pages.append({
                    "text":        text,
                    "source_file": file_doc["file_name"],
                    "file_path":   file_doc["file_path"],
                    "page_num":    page["page_num"],
                })
        logger.info(f"[Reranker] Corpus flattened: {len(self._corpus_pages)} pages")

    def teardown(self) -> None:
        self._cross_encoder = None
        self._corpus_pages  = []

    # ── Core strategy ─────────────────────────────────────────────────────────

    def run(
        self,
        checklist:   List[Dict],
        file_corpus: List[Dict],
    ) -> List[StrategyResult]:
        if self._cross_encoder is None:
            self.setup(file_corpus)

        results = []
        for row in checklist:
            exigence = row["exigence"]
            logger.info(f"[Reranker] → '{exigence[:70]}'")

            # ── Stage 1: BM25 broad recall ────────────────────────────────
            bm25_candidates = self._bm25_recall(row)
            logger.info(f"[Reranker]   BM25 candidates: {len(bm25_candidates)}")

            # ── Stage 2: Cross-encoder reranking ──────────────────────────
            reranked = self._rerank(exigence, bm25_candidates)
            logger.info(f"[Reranker]   After reranking: {len(reranked)} pages")

            # ── Stage 3: LLM verdict ──────────────────────────────────────
            verdict = self._verdict(row, reranked)

            results.append(StrategyResult(
                exigence        = exigence,
                row_index       = row["row_index"],
                rep_tag         = row["rep_tag"],
                human_label     = row.get("human_label"),
                human_notes     = row.get("human_notes", ""),
                verdict         = verdict,
                evidence_type   = "ambiguous",  # reranker doesn't classify evidence type
                retrieved_pages = reranked,
            ))

        return results

    # ── Private helpers ───────────────────────────────────────────────────────

    def _bm25_recall(self, row: Dict) -> List[Dict]:
        """BM25 stage: score all corpus pages, return top-BM25_RECALL_K."""
        from nltk.tokenize import word_tokenize
        from rank_bm25 import BM25Okapi

        # Enrich query: exigence + rep comments + any proof refs mentioned
        # (more signal than exigence alone for BM25)
        parts = [row["exigence"]]
        if row.get("rep_comments"):
            parts.append(row["rep_comments"])
        if row.get("proof_refs"):
            parts.extend(row["proof_refs"])
        query = " ".join(parts)

        def tokenize(text: str) -> List[str]:
            try:
                return [t for t in word_tokenize(text.lower()) if t.isalnum()]
            except Exception:
                return text.lower().split()

        tokenized_corpus = [tokenize(p["text"]) for p in self._corpus_pages]
        bm25 = BM25Okapi(tokenized_corpus)
        scores = bm25.get_scores(tokenize(query))

        top_indices = scores.argsort()[::-1][:BM25_RECALL_K]
        return [self._corpus_pages[i] for i in top_indices if scores[i] > 0]

    def _rerank(self, query: str, candidates: List[Dict]) -> List[Dict]:
        """
        Cross-encoder reranking: score every (query, page_text) pair,
        sort descending, return top-RERANK_KEEP pages.
        """
        if not candidates:
            return []

        # Build input pairs for the cross-encoder
        pairs = [[query, p["text"]] for p in candidates]

        try:
            scores = self._cross_encoder.predict(pairs)
        except Exception as e:
            logger.warning(f"[Reranker] Cross-encoder scoring failed: {e} — falling back to BM25 order")
            return candidates[:RERANK_KEEP]

        # Zip scores with pages, sort by score descending, keep top-k
        scored = sorted(zip(scores, candidates), key=lambda x: x[0], reverse=True)
        top_pages = [page for _, page in scored[:RERANK_KEEP]]

        logger.info(
            f"[Reranker]   Top-4 scores: "
            f"{[round(float(s), 3) for s, _ in scored[:4]]}"
        )
        return top_pages

    def _verdict(self, row: Dict, retrieved_pages: List[Dict]) -> Dict:
        """Shared LLM document verdict (same chain as naive_rag and bm25_hybrid)."""
        from config import LABEL_NON
        from pipeline.verdict import run_document_verdict
        try:
            return run_document_verdict(
                exigence        = row["exigence"],
                rep_tag         = row.get("rep_tag", ""),
                rep_comments    = row.get("rep_comments", ""),
                proof_refs      = row.get("proof_refs", []),
                retrieved_pages = retrieved_pages,
                french_keywords = [],
            )
        except Exception as e:
            logger.error(f"[Reranker] Verdict failed: {e}")
            return {
                "compliance":         LABEL_NON,
                "justification_type": "inferred",
                "evidence":           f"Erreur: {e}",
                "confidence":         0.0,
                "reasoning":          f"Verdict non déterminé: {e}",
                "source_files":       [],
            }

    # ── Override execute() to run setup once ──────────────────────────────────

    def execute(self, checklist: List[Dict], file_corpus: List[Dict]):
        self.setup(file_corpus)
        results = []
        for row in checklist:
            t0     = time.perf_counter()
            result = self.run([row], file_corpus)[0]
            result.strategy_name = self.NAME
            result.latency_ms    = round((time.perf_counter() - t0) * 1000, 1)
            results.append(result)
        self.teardown()
        return results
