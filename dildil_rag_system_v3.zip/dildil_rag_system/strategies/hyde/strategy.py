"""
strategies/hyde/strategy.py — HyDE (Hypothetical Document Embeddings) strategy.

Reference: Gao et al., "Precise Zero-Shot Dense Retrieval without Relevance Labels" (2022)
           https://arxiv.org/abs/2212.10496

The core insight:
  Standard RAG embeds the *question* and searches for *answers*.
  The embedding space is trained on (document, document) pairs — not
  (question, document) pairs — so there's an inherent asymmetry.

  HyDE bridges this: instead of embedding the exigence directly,
  ask the LLM to *hallucinate* a hypothetical document that *would*
  satisfy the exigence, then embed THAT document as the query vector.

  The hypothetical document lives in the same region of embedding space
  as real documents, so similarity search is more precise.

Pipeline for this use case:
  1. Generate a hypothetical proof document for this exigence
     (e.g. "ISO 27001 certificate mentioning TECHSOL GROUP SAS…")
  2. Embed the hypothetical document
  3. Similarity search with that embedding against all proof pages
  4. LLM verdict on the retrieved pages

Why compare this against naive_rag:
  naive_rag embeds "Le prestataire dispose d'une certification ISO 27001…"
  hyde embeds    "CERTIFICAT ISO/IEC 27001 — société XYZ — valide jusqu'au…"
  The second query is much closer to how a real certificate is written,
  so the similarity search should return more precise results.

Caveat: HyDE adds one extra LLM call per row (hypothesis generation),
so it will be slower. The latency comparison in the report makes this visible.
"""
from __future__ import annotations

import hashlib
import logging
import time
from typing import Dict, List, Optional

import chromadb
from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from langchain_groq import ChatGroq
from langchain_huggingface import HuggingFaceEmbeddings

from config import (
    CHROMA_PERSIST_DIR,
    EMBEDDING_MODEL,
    GROQ_API_KEY,
    GROQ_MODEL,
    LABEL_NON,
)
from pipeline.verdict import run_document_verdict
from strategies.base import BaseStrategy, StrategyResult

logger = logging.getLogger(__name__)

# ── Constants ─────────────────────────────────────────────────────────────────
COLLECTION_NAME = "hyde_pages"   # dedicated collection, separate from other strategies
TOP_K           = 4              # pages to retrieve after HyDE search

# ── Hypothesis generation prompt ──────────────────────────────────────────────
_HYPOTHESIS_PROMPT = ChatPromptTemplate.from_messages([
    (
        "system",
        "Tu es un expert en conformité et due diligence prestataires. "
        "Génère un extrait de document de preuve réaliste qui satisferait pleinement "
        "l'exigence donnée. "
        "Le document doit ressembler à un vrai document officiel (certificat, attestation, "
        "rapport, politique interne, etc.). "
        "Inclure : dates plausibles, noms d'organismes, numéros de référence fictifs, "
        "formulations typiques du type de document. "
        "IMPORTANT : génère UNIQUEMENT le texte du document, sans explications ni préambule. "
        "Longueur : 150-250 mots maximum.",
    ),
    (
        "human",
        "Exigence de conformité : {exigence}\n\n"
        "Commentaire du prestataire : {rep_comments}\n\n"
        "Génère un extrait de document de preuve qui satisferait cette exigence.",
    ),
])


class HyDEStrategy(BaseStrategy):
    """
    Hypothetical Document Embeddings (HyDE) strategy.

    For each exigence:
      1. LLM generates a hypothetical proof document
      2. The hypothetical text is embedded (not the exigence itself)
      3. Similarity search using the hypothetical embedding
      4. LLM verdict on the real retrieved pages

    The hypothesis lives in the same embedding space as real documents
    so the query vector is more aligned with how proof documents are written.
    """

    NAME        = "hyde"
    DESCRIPTION = (
        "HyDE: LLM generates a hypothetical proof document, embeds it as the "
        "query vector → similarity search → LLM verdict. No BM25."
    )

    def __init__(self) -> None:
        self._embeddings:  Optional[HuggingFaceEmbeddings] = None
        self._vectorstore: Optional[Chroma]                = None
        self._client:      Optional[chromadb.PersistentClient] = None
        self._llm = None

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def setup(self, file_corpus: List[Dict]) -> None:
        """
        Embed all proof pages into a dedicated ChromaDB collection (with dedup).
        Also initialise the hypothesis-generation LLM chain.
        """
        logger.info(f"[HyDE] Setting up — embedding proof pages into '{COLLECTION_NAME}'")

        self._embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)
        self._client     = chromadb.PersistentClient(path=CHROMA_PERSIST_DIR)
        self._llm        = ChatGroq(api_key=GROQ_API_KEY, model=GROQ_MODEL, temperature=0.3)

        # Flatten & deduplicate
        all_pages = []
        for file_doc in file_corpus:
            for page in file_doc["pages"]:
                text = page["text"].strip()
                if text:
                    all_pages.append({
                        "text":        text,
                        "source_file": file_doc["file_name"],
                        "file_path":   file_doc["file_path"],
                        "page_num":    page["page_num"],
                    })

        logger.info(f"[HyDE] {len(all_pages)} pages to index")

        documents = []
        doc_ids   = []
        for p in all_pages:
            cid = hashlib.sha256(p["text"].encode()).hexdigest()
            doc_ids.append(cid)
            documents.append(Document(
                page_content=p["text"],
                metadata={
                    "content_id":  cid,
                    "source_file": p["source_file"],
                    "file_path":   p["file_path"],
                    "page_num":    p["page_num"],
                },
            ))

        try:
            existing = self._client.get_or_create_collection(COLLECTION_NAME).get(
                ids=doc_ids, include=[]
            )
            existing_ids = set(existing["ids"])
        except Exception:
            existing_ids = set()

        new_docs = [d for d in documents if d.metadata["content_id"] not in existing_ids]
        new_ids  = [d.metadata["content_id"] for d in new_docs]

        logger.info(
            f"[HyDE] {len(existing_ids)} already indexed, "
            f"embedding {len(new_docs)} new page(s)"
        )

        if new_docs:
            Chroma.from_documents(
                documents=new_docs,
                embedding=self._embeddings,
                collection_name=COLLECTION_NAME,
                client=self._client,
                ids=new_ids,
            )

        self._vectorstore = Chroma(
            collection_name=COLLECTION_NAME,
            embedding_function=self._embeddings,
            client=self._client,
        )
        logger.info("[HyDE] Setup complete")

    def teardown(self) -> None:
        self._vectorstore = None
        self._embeddings  = None
        self._client      = None
        self._llm         = None

    # ── Core strategy ─────────────────────────────────────────────────────────

    def run(
        self,
        checklist:   List[Dict],
        file_corpus: List[Dict],
    ) -> List[StrategyResult]:
        if self._vectorstore is None:
            self.setup(file_corpus)

        results = []
        for row in checklist:
            exigence = row["exigence"]
            logger.info(f"[HyDE] → '{exigence[:70]}'")

            # ── Step 1: Generate hypothetical document ────────────────────
            hypothesis = self._generate_hypothesis(row)
            logger.info(f"[HyDE]   Hypothesis ({len(hypothesis)} chars): '{hypothesis[:80]}…'")

            # ── Step 2: Embed hypothesis and search ───────────────────────
            retrieved = self._hyde_search(hypothesis)
            logger.info(f"[HyDE]   Retrieved {len(retrieved)} page(s)")

            # ── Step 3: LLM verdict on real retrieved pages ───────────────
            verdict = self._verdict(row, retrieved)

            results.append(StrategyResult(
                exigence        = exigence,
                row_index       = row["row_index"],
                rep_tag         = row["rep_tag"],
                human_label     = row.get("human_label"),
                human_notes     = row.get("human_notes", ""),
                verdict         = verdict,
                evidence_type   = "ambiguous",
                retrieved_pages = retrieved,
            ))

        return results

    # ── Private helpers ───────────────────────────────────────────────────────

    def _generate_hypothesis(self, row: Dict) -> str:
        """
        Ask the LLM to hallucinate a plausible proof document for this exigence.
        Falls back to the raw exigence text on failure (degrades to naive_rag behaviour).
        """
        try:
            chain    = _HYPOTHESIS_PROMPT | self._llm
            response = chain.invoke({
                "exigence":     row["exigence"],
                "rep_comments": row.get("rep_comments", "(aucun commentaire)"),
            })
            hypothesis = response.content.strip()
            if len(hypothesis) < 30:
                raise ValueError(f"Hypothesis too short ({len(hypothesis)} chars)")
            return hypothesis
        except Exception as e:
            logger.warning(
                f"[HyDE] Hypothesis generation failed: {e} "
                f"— falling back to raw exigence text"
            )
            return row["exigence"]  # graceful degradation → same as naive_rag

    def _hyde_search(self, hypothesis_text: str) -> List[Dict]:
        """
        Embed the hypothetical document and run similarity search.
        The hypothesis is NOT stored in ChromaDB — it's only used as a query vector.
        """
        docs = self._vectorstore.similarity_search(hypothesis_text, k=TOP_K)
        return [
            {
                "text":        doc.page_content,
                "source_file": doc.metadata.get("source_file", ""),
                "file_path":   doc.metadata.get("file_path", ""),
                "page_num":    doc.metadata.get("page_num", 0),
                "file_ext":    "",
            }
            for doc in docs
        ]

    def _verdict(self, row: Dict, retrieved_pages: List[Dict]) -> Dict:
        try:
            return run_document_verdict(
                exigence        = row["exigence"],
                rep_tag         = row.get("rep_tag", ""),
                rep_comments    = row.get("rep_comments", ""),
                proof_refs      = row.get("proof_refs", []),
                retrieved_pages = retrieved_pages,
                french_keywords = [],
            )
        except Exception as e:
            logger.error(f"[HyDE] Verdict failed: {e}")
            return {
                "compliance":         LABEL_NON,
                "justification_type": "inferred",
                "evidence":           f"Erreur: {e}",
                "confidence":         0.0,
                "reasoning":          f"Verdict non déterminé: {e}",
                "source_files":       [],
            }

    # ── Override execute() to run setup once ──────────────────────────────────

    def execute(self, checklist: List[Dict], file_corpus: List[Dict]):
        self.setup(file_corpus)
        results = []
        for row in checklist:
            t0     = time.perf_counter()
            result = self.run([row], file_corpus)[0]
            result.strategy_name = self.NAME
            result.latency_ms    = round((time.perf_counter() - t0) * 1000, 1)
            results.append(result)
        self.teardown()
        return results
