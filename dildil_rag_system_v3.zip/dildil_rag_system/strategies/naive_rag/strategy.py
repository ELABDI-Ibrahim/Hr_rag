"""
strategies/naive_rag/strategy.py — Naive RAG baseline strategy.

The simplest possible approach:
  1. Embed ALL pages from ALL proof documents into ChromaDB (done once in setup())
  2. For each exigence: similarity_search(exigence_text, top_k=4)
  3. Pass the top-k pages directly to the LLM verdict

No BM25, no keyword expansion, no evidence mining, no conditional routing.
Every exigence goes through the same linear path.

This is the baseline to beat. Everything else in the strategies/ folder
should be compared against this.

Verdict output is identical to the full pipeline (same ComplianceVerdict schema)
so the evaluation layer treats it identically.
"""
from __future__ import annotations

import hashlib
import logging
from typing import Dict, List, Optional

import chromadb
from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_huggingface import HuggingFaceEmbeddings

from config import (
    CHROMA_PERSIST_DIR,
    EMBEDDING_MODEL,
    GROQ_API_KEY,
    GROQ_MODEL,
    LABEL_NON,
)
from pipeline.verdict import run_document_verdict
from strategies.base import BaseStrategy, StrategyResult

logger = logging.getLogger(__name__)

# ── Constants ─────────────────────────────────────────────────────────────────
COLLECTION_NAME = "naive_rag_pages"   # separate from the hybrid pipeline collection
TOP_K = 4                             # pages retrieved per exigence


class NaiveRAG(BaseStrategy):
    """
    Baseline RAG: embed everything, retrieve by similarity, call the LLM.

    No pre-filtering, no keyword expansion, no evidence mining.
    Uses a dedicated ChromaDB collection (naive_rag_pages) so it
    doesn't pollute or depend on the hybrid pipeline's collection.
    """

    NAME        = "naive_rag"
    DESCRIPTION = "Baseline: embed all proof pages → similarity search → LLM verdict. No BM25, no evidence mining."

    def __init__(self) -> None:
        self._embeddings: Optional[HuggingFaceEmbeddings] = None
        self._vectorstore: Optional[Chroma]               = None
        self._client: Optional[chromadb.PersistentClient] = None

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def setup(self, file_corpus: List[Dict]) -> None:
        """
        Bulk-embed all proof pages into ChromaDB — called once before run().
        Uses content-hash dedup so re-running is fast (only new pages embedded).
        """
        logger.info(f"[NaiveRAG] Setting up — embedding all proof pages into '{COLLECTION_NAME}'")

        self._embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)
        self._client     = chromadb.PersistentClient(path=CHROMA_PERSIST_DIR)

        # Flatten corpus into page dicts
        all_pages = []
        for file_doc in file_corpus:
            for page in file_doc["pages"]:
                text = page["text"].strip()
                if not text:
                    continue
                all_pages.append({
                    "text":        text,
                    "source_file": file_doc["file_name"],
                    "file_path":   file_doc["file_path"],
                    "page_num":    page["page_num"],
                })

        logger.info(f"[NaiveRAG] {len(all_pages)} pages across {len(file_corpus)} document(s)")

        # Build LangChain Documents with content-hash IDs (dedup)
        documents = []
        doc_ids   = []
        for p in all_pages:
            content_id = hashlib.sha256(p["text"].encode()).hexdigest()
            doc_ids.append(content_id)
            documents.append(Document(
                page_content=p["text"],
                metadata={
                    "content_id":  content_id,
                    "source_file": p["source_file"],
                    "file_path":   p["file_path"],
                    "page_num":    p["page_num"],
                },
            ))

        # Check which IDs are already indexed
        try:
            existing = self._client.get_or_create_collection(COLLECTION_NAME).get(
                ids=doc_ids, include=[]
            )
            existing_ids = set(existing["ids"])
        except Exception:
            existing_ids = set()

        new_docs = [d for d in documents if d.metadata["content_id"] not in existing_ids]
        new_ids  = [d.metadata["content_id"] for d in new_docs]

        logger.info(
            f"[NaiveRAG] {len(existing_ids)} page(s) already indexed, "
            f"embedding {len(new_docs)} new page(s)"
        )

        if new_docs:
            Chroma.from_documents(
                documents=new_docs,
                embedding=self._embeddings,
                collection_name=COLLECTION_NAME,
                client=self._client,
                ids=new_ids,
            )
            logger.info(f"[NaiveRAG] Indexed {len(new_docs)} new page(s)")

        # Open the vectorstore for querying
        self._vectorstore = Chroma(
            collection_name=COLLECTION_NAME,
            embedding_function=self._embeddings,
            client=self._client,
        )
        logger.info("[NaiveRAG] Setup complete — vectorstore ready")

    def teardown(self) -> None:
        self._vectorstore = None
        self._embeddings  = None
        self._client      = None

    # ── Core strategy ─────────────────────────────────────────────────────────

    def run(
        self,
        checklist:   List[Dict],
        file_corpus: List[Dict],
    ) -> List[StrategyResult]:
        """
        For each exigence:
          1. Similarity search top-k pages (no filtering)
          2. Pass directly to LLM document verdict
          3. Wrap in StrategyResult

        setup() must have been called first (runner does this).
        """
        if self._vectorstore is None:
            raise RuntimeError(
                "NaiveRAG.setup() must be called before run(). "
                "Use runner.py — it calls setup() automatically."
            )

        results = []
        for row in checklist:
            exigence = row["exigence"]
            logger.info(f"[NaiveRAG] → '{exigence[:70]}'")

            # ── Step 1: Pure similarity search (no BM25 pre-filter) ──────────
            retrieved = self._similarity_search(exigence)
            logger.info(f"[NaiveRAG]   Retrieved {len(retrieved)} page(s)")

            # ── Step 2: LLM verdict ──────────────────────────────────────────
            verdict = self._verdict(row, retrieved)

            # ── Step 3: Wrap ─────────────────────────────────────────────────
            results.append(StrategyResult(
                exigence        = exigence,
                row_index       = row["row_index"],
                rep_tag         = row["rep_tag"],
                human_label     = row.get("human_label"),
                human_notes     = row.get("human_notes", ""),
                verdict         = verdict,
                evidence_type   = "ambiguous",   # naive RAG doesn't classify evidence type
                retrieved_pages = retrieved,
            ))

        return results

    # ── Private helpers ───────────────────────────────────────────────────────

    def _similarity_search(self, query: str) -> List[Dict]:
        """Run similarity search over the full collection — no filters."""
        docs = self._vectorstore.similarity_search(query, k=TOP_K)
        return [
            {
                "text":        doc.page_content,
                "source_file": doc.metadata.get("source_file", ""),
                "file_path":   doc.metadata.get("file_path", ""),
                "page_num":    doc.metadata.get("page_num", 0),
                "file_ext":    "",
            }
            for doc in docs
        ]

    def _verdict(self, row: Dict, retrieved_pages: List[Dict]) -> Dict:
        """Call the shared document verdict LLM chain."""
        try:
            return run_document_verdict(
                exigence        = row["exigence"],
                rep_tag         = row.get("rep_tag", ""),
                rep_comments    = row.get("rep_comments", ""),
                proof_refs      = row.get("proof_refs", []),
                retrieved_pages = retrieved_pages,
                french_keywords = [],   # naive RAG: no keyword expansion
            )
        except Exception as e:
            logger.error(f"[NaiveRAG] Verdict failed: {e}")
            return {
                "compliance":         LABEL_NON,
                "justification_type": "inferred",
                "evidence":           f"Erreur: {e}",
                "confidence":         0.0,
                "reasoning":          f"Le verdict n'a pas pu être déterminé: {e}",
                "source_files":       [],
            }

    # ── Override execute() to run setup once for all rows ─────────────────────

    def execute(self, checklist: List[Dict], file_corpus: List[Dict]):
        """Override to run setup() once before processing all rows."""
        from strategies.base import StrategyResult
        import time

        self.setup(file_corpus)
        results = []
        for row in checklist:
            t0     = time.perf_counter()
            result = self.run([row], file_corpus)[0]
            result.strategy_name = self.NAME
            result.latency_ms    = round((time.perf_counter() - t0) * 1000, 1)
            results.append(result)

        self.teardown()
        return results
