"""
strategies/TEMPLATE/strategy.py — Copy this to add a new strategy.

Steps:
  1. Copy this folder: cp -r strategies/TEMPLATE strategies/my_strategy
  2. Rename the class and set NAME / DESCRIPTION
  3. Implement run()
  4. Run: python runner.py --strategy my_strategy

The runner, evaluator, and comparison report will work automatically.
No other file needs editing.
"""
from __future__ import annotations

import logging
from typing import Dict, List

from strategies.base import BaseStrategy, StrategyResult

logger = logging.getLogger(__name__)


class TemplateStrategy(BaseStrategy):
    """
    Replace this docstring with a short description of your strategy.
    """

    NAME        = "template"          # ← change this (must be unique, no spaces)
    DESCRIPTION = "Template strategy. Replace with your description."

    def __init__(self) -> None:
        # Initialise any state here (models, indexes, etc.)
        pass

    def setup(self, file_corpus: List[Dict]) -> None:
        """
        Optional. Called once before run() by execute().
        Use for expensive one-time setup: bulk embedding, index building, etc.

        Args:
            file_corpus: list of {file_path, file_name, pages, full_text}
        """
        pass

    def run(
        self,
        checklist:   List[Dict],
        file_corpus: List[Dict],
    ) -> List[StrategyResult]:
        """
        Process all checklist rows. Return one StrategyResult per row.

        Args:
            checklist:   list of dicts from read_compliance_checklist()
                         Keys: exigence, rep_tag, rep_comments, proof_refs,
                               human_label, human_notes, row_index
            file_corpus: list of dicts from load_proof_folder()
                         Keys: file_path, file_name, pages, full_text

        Returns:
            List[StrategyResult] — same order as checklist
        """
        results = []

        for row in checklist:
            # ── Your retrieval logic here ────────────────────────────────────
            retrieved_pages: List[Dict] = []
            # Example: retrieved_pages = my_retriever.search(row["exigence"])

            # ── Your verdict logic here ──────────────────────────────────────
            verdict: Dict = {
                "compliance":         "non_compliant",   # compliant | partially_compliant | non_compliant
                "justification_type": "inferred",        # document | oral | inferred
                "evidence":           "Not implemented",
                "confidence":         0.0,
                "reasoning":          "Template strategy — implement run() to add logic.",
                "source_files":       [],
            }

            # ── Wrap in StrategyResult ───────────────────────────────────────
            results.append(StrategyResult(
                exigence        = row["exigence"],
                row_index       = row["row_index"],
                rep_tag         = row["rep_tag"],
                human_label     = row.get("human_label"),
                human_notes     = row.get("human_notes", ""),
                verdict         = verdict,
                evidence_type   = "ambiguous",  # or "document_required" | "oral_implicit"
                retrieved_pages = retrieved_pages,
            ))

        return results
