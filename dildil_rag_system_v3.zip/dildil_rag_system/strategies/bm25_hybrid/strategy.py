"""
strategies/bm25_hybrid/strategy.py — Full AI4DueDil pipeline as a strategy.

Wraps the existing LangGraph pipeline (evidence_mining → keyword_suggestion →
BM25 → semantic_search → document/oral verdict) into the BaseStrategy interface.

This is the "production" strategy. naive_rag is the baseline.
"""
from __future__ import annotations

import logging
import time
from typing import Dict, List

import mlflow

from config import BM25_TOP_K, SEMANTIC_TOP_M
from pipeline.graph import build_compliance_graph
from strategies.base import BaseStrategy, StrategyResult

logger = logging.getLogger(__name__)


class BM25HybridStrategy(BaseStrategy):
    """
    Full hybrid pipeline:
      Node 1: evidence mining (document_required / oral / ambiguous)
      Node 2: French keyword expansion
      Node 3: BM25 page triage (top-K pages)
      Node 4: ChromaDB semantic search (restricted to BM25 candidates)
      Node 5a/b: LLM verdict (document-based or oral-based depending on evidence type)
    """

    NAME        = "bm25_hybrid"
    DESCRIPTION = (
        "Full pipeline: evidence mining → BM25 triage → semantic search → "
        "conditional verdict (document or oral path)."
    )

    def __init__(self) -> None:
        self._graph = None

    def setup(self, file_corpus: List[Dict]) -> None:
        logger.info("[BM25Hybrid] Compiling LangGraph pipeline...")
        self._graph = build_compliance_graph()
        logger.info("[BM25Hybrid] Pipeline ready")

    def run(
        self,
        checklist:   List[Dict],
        file_corpus: List[Dict],
    ) -> List[StrategyResult]:
        if self._graph is None:
            self.setup(file_corpus)

        results = []
        for row in checklist:
            logger.info(f"[BM25Hybrid] → '{row['exigence'][:70]}'")

            initial_state = {
                "exigence":           row["exigence"],
                "rep_tag":            row.get("rep_tag", ""),
                "rep_comments":       row.get("rep_comments", ""),
                "proof_refs":         row.get("proof_refs", []),
                "file_corpus":        file_corpus,
                "evidence_type":      "",
                "evidence_rationale": "",
                "french_keywords":    [],
                "candidate_pages":    [],
                "retrieved_pages":    [],
                "verdict":            {},
            }

            with mlflow.start_run(
                run_name=f"[bm25_hybrid] {row['exigence'][:50]}",
                nested=True,
            ):
                final_state = self._graph.invoke(initial_state)

            results.append(StrategyResult(
                exigence        = row["exigence"],
                row_index       = row["row_index"],
                rep_tag         = row.get("rep_tag", ""),
                human_label     = row.get("human_label"),
                human_notes     = row.get("human_notes", ""),
                verdict         = final_state["verdict"],
                evidence_type   = final_state.get("evidence_type", "ambiguous"),
                retrieved_pages = final_state.get("retrieved_pages", []),
            ))

        return results

    def execute(self, checklist: List[Dict], file_corpus: List[Dict]):
        """Override to call setup() once, then process all rows."""
        self.setup(file_corpus)
        results = []
        for row in checklist:
            t0     = time.perf_counter()
            result = self.run([row], file_corpus)[0]
            result.strategy_name = self.NAME
            result.latency_ms    = round((time.perf_counter() - t0) * 1000, 1)
            results.append(result)
        return results
